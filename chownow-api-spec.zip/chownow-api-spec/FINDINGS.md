# FINDINGS

What works end-to-end, what's inferred, and what got blocked. Captured 2026-10-15.

## Architecture, at a glance

1. **Two orthogonal APIs**, not one.
   - **Partner API** (`openapi.chownow.com/v1`): documented, OAuth2 client-credentials, published at `developer.chownow.com`, intended for POS/aggregator integrators.
   - **Private web API** (`api.chownow.com/api/`): undocumented, cookie-session, powers the browser SPA and native apps. Everything a diner can do goes through here.
   - They do not share schemas: Partner uses RFC 9457 Problem Details; private uses `{errors: [{code, message, reason}]}`.
2. **The order page is a React SPA served from a different origin** (`direct.chownow.com`) and embedded inside a Next.js shell at `www.chownow.com/order/<brand>/locations/<loc>`. The `window.chownow.com` shell is Next.js 4.81.0 (Turbopack); the SPA bundle is `direct.chownow.com/static/js/main.<hash>.js` + `vendor.<hash>.js` + lazy chunks.
3. **Three channel identities** carried in `X-CN-App-Info`: `Marketplace-Web`, `Yelp-Web`, `Direct-Web`. The channel changes which `meta` injections the SPA adds to write bodies — notably `meta.marketplace: {id: "2", x_id: null}` for Marketplace-Web.
4. **Cart is 100% client-side.** No cart XHR fires from the SPA. Server contact resumes at `POST /api/order/validate` (the "quote") when the user starts checkout, exactly like the Partner API's `POST /v1/quotes`.
5. **Payments.** Stripe for cards and Apple/Google Pay. The marketplace-level publishable key is in `/api/web/manifest`; the per-restaurant membership key (also Stripe) is on `GET /api/restaurant/{id}.membership.processor_key`. Apple Pay merchant id is `merchant.com.stripe.chownow`. `payment_processor_id` on the restaurant payload is numeric; `"3"` = Stripe. Observed only Stripe in this capture.
6. **Fraud.** Sift Science is loaded on every order page. Expect a `sift_session_id` field in order submissions.
7. **Anti-bot.** Cloudflare in front of both `www.chownow.com` and `api.chownow.com`. During this capture window the API did not challenge plain `curl` requests on anonymous reads. Expect `curl-impersonate`/`tls-client` to become necessary under volume or for write endpoints.
8. **Scheduling model.** Fulfillment slots are a 96-entry 0/1 array per day (15 min precision), rendered client-side from `GET /api/restaurant/{id}.order_ahead.days[*]`. Scheduled orders carry a `YYYYMMDDHHMM` string, not ISO 8601.

## Verified endpoint inventory (anonymous reads replayed via `curl`)

| Method | Path                                                | Replayed status | Example in `examples/`                                                                 |
| ------ | --------------------------------------------------- | --------------- | -------------------------------------------------------------------------------------- |
| GET    | `/api/`                                             | 501             | `*_GET_api_chownow_com_api/`                                                           |
| GET    | `/api/web/manifest`                                 | 200             | `*_GET_api_chownow_com_api_web_manifest/`                                              |
| GET    | `/api/restaurant/35`                                | 200             | `*_GET_api_chownow_com_api_restaurant_35/`                                             |
| GET    | `/api/restaurant/35/menu`                           | 200             | `*_GET_api_chownow_com_api_restaurant_35_menu/`                                        |
| GET    | `/api/restaurant?pf=1&aggs=cuisines&u_lat&u_lon&limit` | 200           | `*_api_restaurant_pf_1_aggs_cuisines_u_lat_34_...`                                     |
| GET    | `/api/restaurant/facets?u_lat&u_lon&facets=...`     | 200             | `*_api_restaurant_facets_u_lat_34_...`                                                 |
| GET    | `/api/company/32/restaurants`                       | 200             | `*_api_company_32_restaurants/`                                                        |
| GET    | `/api/company/32/restaurants?location=lat,lng`      | 200 (same body) | `*_api_company_32_restaurants_location_37_95_122_55/`                                  |
| GET    | `/api/customer/me` (anonymous)                      | 404             | `*_api_customer_me/`                                                                   |
| GET    | `/api/customer` (anonymous, GET)                    | 500             | `*_api_customer/`                                                                      |
| GET    | `/api/order/validate` (GET, no body)                | 404             | `*_api_order_validate/`                                                                |
| GET    | `/api/order/1` (anonymous)                          | 404             | `*_api_order_1/`                                                                       |

## Observed endpoints (seen in traffic or confirmed via CORS OPTIONS 200)

| Observation method       | Endpoints                                                                                         |
| ------------------------ | ------------------------------------------------------------------------------------------------- |
| Live XHR (performance API) | `GET /api/restaurant/{id}`, `GET /api/restaurant/{id}/menu`, `GET /api/customer/me`, `GET /api/web/manifest`, `GET /api/company/{id}/restaurants`, `GET /api/restaurant?pf=1&...`, `GET /api/restaurant/facets?...` |
| OPTIONS preflight = 200  | `/api/customer`, `/api/customer/signin`, `/api/customer/signup`, `/api/customer/exists`, `/api/customer/validate`, `/api/customer/forgot-password`, `/api/customer/reset-password`, `/api/customer/password`, `/api/customer/session`, `/api/customer/sso`, `/api/customer/google`, `/api/customer/apple`, `/api/customer/magic-link`, `/api/customer/addresses`, `/api/order`, `/api/order/submit`, `/api/order/create` |
| OPTIONS preflight = 403  | `/api/customer/login` — path exists but CORS forbids cross-origin writes. Legacy; use `signin`. |
| OPTIONS preflight = 404  | `/api/auth/*`, `/api/login`, `/api/signin`, `/api/signup`, `/api/session`, `/api/address`, `/api/promo`, `/api/guest`, `/api/fulfillment_times` — these aliases do **not** exist. |

## Inferred endpoints (bundle literals, not yet replayed)

Pulled from `main.93c065e7.js` via `scripts/mine_paths.py` / `mine_api_calls.py` / `mine_v3.py`:

- `GET /api/restaurant/{id}/menu/{menu_id}` — snapshot menu by version
- `POST /api/restaurant/{id}/item-recommendations` (v5.0)
- `GET /api/restaurant/{id}/catering`
- `POST /api/restaurant/{id}/catering-inquiry`
- `GET /api/yelp/{company_id}/restaurant`
- `POST /api/yelp/validate`
- `GET /api/yelp/opportunity/{id}`
- `GET /api/history/{order_id}`
- `POST /api/order/{id}/reorder`
- `POST /api/order/{id}/adjust`
- `POST /api/customer/logout`
- `PUT /api/customer/{id}/contact-info`
- `POST /api/customer/{id}/billing-card`
- `DELETE /api/customer/{id}/billing-card/{card_id}`
- `PUT /api/customer/{id}/rewards-consent`
- `POST /api/customer/{id}/membership`
- `POST /api/customer/{id}/favorites`
- `GET /api/customer/me/restaurant/{id}/recently-ordered`

## What this spec does NOT cover

- **Mobile API** (`X-CN-App-Info: Diner-iOS/*` or `Diner-Android/*`). The ChowNow native apps almost certainly call the same `api.chownow.com/api/` surface — probably with a slightly different channel header and possibly a bearer token — but no mobile capture was done in this environment. See [`UNKNOWNS.md`](UNKNOWNS.md#mobile-apis).
- **Restaurant-side admin API** (`portal.chownow.com`). The restaurant admin surface is a different app at a different host; outside the diner-flow scope the operator asked for.
- **Yelp partner API** (`openapi.chownow.com/v1` Yelp opportunities). Yelp Food Ordering is a documented Partner API feature; the `/api/yelp/*` paths captured here are the diner-flow siblings on the private API.
- **Authenticated write-path bodies** (`/customer/signin`, `/customer/signup`, `/order`, `/order/submit`, address CRUD, favorites). The bodies above are inferred from bundle + naming + sibling signatures; `scripts/replay.py` only replays verified anonymous reads.

## Confidence summary

After the follow-up pass:

| Confidence                 | Count | Scope                                                                 |
| -------------------------- | ----- | --------------------------------------------------------------------- |
| `[VERIFIED by replay]`     | 28    | Discovery, menu, manifest, error-shape probes, `/customer/exists`, OIDC discovery, autocomplete, authed /customer/me, /customer/me/orders, /customer/me/rewards, /customer/me/restaurant/{id}/recently-ordered, POST /customer (signup), POST /customer/login (signin), PUT /customer/{id}, PUT /customer/me/billing-card (schema), PUT /customer/me/favorites (schema), POST /customer/me/membership (schema), POST /customer/logout, POST /order/validate (full body + response), POST /order (schema), /customer/exists auth behavior, pf no-op, Partner JWKS. |
| `[OBSERVED]`               | ~14   | Yelp handoff endpoints, PUT /customer/{magic-link, google, apple, sso, forgot-password, reset-password, password, session, validate} (confirmed as authed-wrapper paths but body shapes beyond `is_optout` not captured). |
| `[INFERRED]`               | ~6    | /restaurant/{id}/catering, /restaurant/{id}/catering-inquiry, /restaurant/{id}/menu/{menu_id} snapshot, /history/{order_id}, /order/{id}/reorder, /order/{id}/adjust. |

Total unique endpoints identified: **~60** on the private web surface (several earlier "endpoints" turned out to be CORS-wildcard false positives and were removed), **9** on the Partner API (from docs + live OIDC discovery).

## Closures in the follow-up pass (2026-10-15, after move to the user's folder)

- **UNKNOWN #3 — `pf` query param**: replay-tested with `pf=0`, `pf=1`, `pf=2`, and `pf` omitted at the same `(u_lat, u_lon)` → **identical response** (`total: 439`, same first-5 ids). The parameter is a no-op in the current API; the SPA still sends `pf=1`. Closed.
- **UNKNOWN #6 — Partner OIDC discovery**: fetched `/.well-known/openid-configuration` and `/oauth2/jwks` from both `auth.developer.chownow.com` and `auth.sandbox.developer.chownow.com`. Issuer `https://auth.developer.chownow.com`, four grant types (`authorization_code`, `client_credentials`, `refresh_token`, device code), RS256 id tokens, Ory-Hydra-shaped. Closed. See [`endpoints/partner-api.md`](endpoints/partner-api.md#authentication).
- **UNKNOWN #7 — `/customer/exists` shape**: `GET /customer/exists?email=...` with an authed session; anonymous → 401; authed with mismatched email → 403 `20900 "User and account id mismatch"`. Closed. See [`endpoints/private-web-api.md`](endpoints/private-web-api.md#4-authentication).
- **UNKNOWN #2 — Mobile apps**: iOS and Android apps identified from the Apple App Site Association + Android assetlinks. iOS bundle `com.ChowNow.Marketplace` (iTunes `1210943577`, v1.74.0 as of 2026-10-05); Android `com.chownow.discover` (SHA256 cert `CA:27:AC:EC:...`). **DEX analysis still deferred** — APK download blocked across every public mirror by Cloudflare. See [`endpoints/mobile.md`](endpoints/mobile.md).
- **UNKNOWN #1 — auth + order write-path bodies**: Closed by **progressive validator walk**. The server's JSON Schema validator (`jsonschema` on Bottle) returns `{code:"10101", field:"<missing field>"}` on each 400, which lets us walk the schema one field at a time without ever needing a real-form submission. See `scripts/validator_walk.py`. **New verified bodies**:
  - `POST /api/customer/login` — the real signin endpoint, discriminates on `{email,password}` vs `{fb_token}`.
  - `POST /api/customer` — real signup; required = `email, password, first_name, last_name`.
  - `PUT /api/customer/{id}` — profile update (NOT `/me` — that returns 20900).
  - `POST /api/order/validate` — body is **FLAT** (`fulfill_method, items, menu_id, promo_code, restaurant_id, special_instructions, tip, when`); `when` is `YYYYMMDDHHMM`, "ASAP" is **rejected**; `tip` is a number not an object. Response includes 30+ fee/tax fields.
  - `POST /api/order` — same body as `/order/validate` plus auth; aliases `/order/submit` + `/order/create` exist.
  - `PUT /api/customer/me/billing-card` — fields `address, cvv, exp_month, exp_year, number, type`.
  - `PUT /api/customer/me/favorites` — fields `favorited_id, favorited_type: "restaurant"`.
  - `POST /api/customer/me/membership` — fields `payment_method_id, plan_id, restaurant_id`.
  - `POST /api/customer/logout` — returns `{status:"ok"}` + cookie delete.
  - `GET /api/customer/me/orders` — DRF-paginated `{count, next, previous, results}`.
  - `GET /api/customer/me/rewards` — simple `{rewards:[]}`.
  - `GET /api/customer/me/restaurant/{id}/recently-ordered` — mini-menu `{id, menu_categories:[{"id":"recently_ordered_items","items":[...]}], ...}`.

- **Session cookie model** closed: anon `session=<uuid>; Max-Age=1800`; authed `session=<uuid>; Max-Age=2592000` (30 days). Logout returns `Max-Age=-1`. Scoped to `api.chownow.com` (no explicit Domain).
- **Error-code catalog** closed: codes `10101/10201/10202/10204/10207/12004/20105/20900/32003/401/404/500/501` all documented. See new [`ERRORS.md`](ERRORS.md).
- **`/api/customer/*` namespace is a CORS wildcard** (even nonsense sub-paths preflight 200) — correcting an earlier over-enumeration.

## Backend hints (new)

- **Partner API**: emits `application/problem+json` on 404 → RFC 9457 natively, as the docs claim.
- **Private API**: emits HTML 405 pages that match **Python Bottle**'s default error template on method mismatch. Suggests the private API is (at least in part) a Python/Bottle service. Combined with the Elasticsearch-shaped `aggregations.cuisines[].doc_count` on discovery, backend stack is probably Python + Elasticsearch for search + a Stripe + Sift adapter layer.

## What the SPA bundle gave up

- Full request-options builder (channel detection, meta injection, Accept-version header, GET/POST/PUT/PATCH/DELETE options construction).
- The marketplaceObnBypass channel allowlist (`["google_cn_marketplace"]`) and the default channel `cn_website`. The 21-code array first reported here as that allowlist is actually the handled order-validation error list; see [`ERRORS.md`](ERRORS.md) and [UNKNOWNS #4](UNKNOWNS.md#4-the-cn_channel-parameter-closed-2026-10-16).
- The default API version `3.0` and the version-5.0 feature flag for `item-recommendations`.
- The Stripe publishable key (also returned by `/api/web/manifest` so not strictly "mined").
- Sentry DSN (`1476807` / `e4ffdff121ec415eb1d9c162b0b21333`), LaunchDarkly client-id (`61f8128467ed48159707693c`), mParticle plan (`chownow_marketplace` v2), app version (`5.211.0`).
- Mantine UI tokens — purely cosmetic, included only because it hints at the SPA's component library.
