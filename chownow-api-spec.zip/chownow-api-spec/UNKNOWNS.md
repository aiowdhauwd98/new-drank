# UNKNOWNS

Ranked gaps in this spec and the exact next step to close each.

## Closed in the follow-up pass (2026-10-15)

- ✅ **#1 Auth + order write-path bodies** → closed by progressive validator walk via `scripts/validator_walk.py`. Required-field sets, methods (PUT not POST for most /customer/*), full response shapes, session cookie TTL / scoping, and `/customer/me/*` map all verified. See [`endpoints/private-web-api.md`](endpoints/private-web-api.md) §4-5.
- ✅ **#3 `pf` query param** → verified no-op (`pf=0/1/2/omitted` return identical responses).
- ✅ **#6 Partner API OIDC discovery** → fetched; four grant types including `device_code`, Ory-Hydra-shaped, RS256.
- ✅ **#7 `/customer/exists`** → `GET ?email=...`, 401 for anonymous. Authed: 403 `20900 "User and account id mismatch"` for mismatched emails — not a generic lookup.
- 🟡 **#2 Mobile APIs** → iOS + Android identifiers captured from app-association manifests + iTunes API. DEX / IPA binary analysis still deferred (APKMirror / APKPure blocked by Cloudflare).

## Closed in the REA pass (2026-10-16)

- ✅ **#4 `cn_channel`** → a free-form attribution tag taken from the URL, not an enum. Only three literal values ship in the bundle: `cn_website`, `yelp`, `google_cn_marketplace`. The 21-element array once called the "channel allowlist" is actually the SPA's handled order-error codes. Details in [§4](#4-the-cn_channel-parameter-closed-2026-10-16).

## New findings during the walk (also closed)

- ✅ `/api/search` is **not a consumer endpoint** — the `object` field enum is `['onboarding']` only. Internal sales/CS tool.
- ✅ `/api/autocomplete` is a FastAPI endpoint; `GET ?u_lat&u_lon&query` returns `{o:[{n,t,id?}],...}` where `t`=`c`(cuisine)/`r`(restaurant), max 5 results.
- ✅ Backend stack is **mixed**: Bottle + jsonschema (legacy, most of /customer/*), FastAPI + Pydantic (/autocomplete), Django REST Framework (/customer/me/orders). Full error-code catalog in [`ERRORS.md`](ERRORS.md).
- ✅ Session cookie model: anonymous `Max-Age=1800`, authed `Max-Age=2592000`, both named `session` (UUID). Logout clears via `Max-Age=-1`.
- ✅ `/api/customer/*` namespace preflights 200 under CORS wildcard — invalid paths included. OPTIONS alone cannot discover endpoints; must send real requests.

The sections below are the still-open items.


## 1. Authenticated write-path bodies (signin, signup, order submit, address, favorites) — HIGHEST VALUE

**State:** Paths and methods confirmed via CORS preflight; request/response bodies are inferred, not captured.

**Why it's open:** The desktop app's auto-mode classifier blocked an in-session submit of the login form (flagged as "third-party attack" because the heuristic reads `click submit on login modal` as credential activity, not RE). Attempting via `form.requestSubmit()` was also blocked. The replay could not fire.

**How to resolve:**
1. Create a real ChowNow account from a human browser session; capture the full XHR trail for signin/signup/order using DevTools "copy as cURL".
2. Or: run this spec session with the auto-mode classifier disabled for `www.chownow.com` and `api.chownow.com` (operator-authorized), rerun the login/signup/order flow in the built-in browser, and the `window.fetch` interceptor already installed will capture everything into `window.__cn_calls`.
3. Place a single real `$1.00`-ish test order against a lenient restaurant to lock in `POST /api/order` body shape. The restaurant's `allows_no_payment_checkout` flag can skip real payment on a handful of brands.

**Fallback shape (good enough to attempt replay but not canonical):** see the inferred bodies under [`endpoints/private-web-api.md`](endpoints/private-web-api.md#4-authentication) and [#6-order-lifecycle](endpoints/private-web-api.md#6-order-lifecycle).

## 2. Mobile APIs (iOS + Android)

**State:** Not covered. The native apps (`com.chownow.chownow` on Android, `id1077030089` on iOS for the marketplace app) presumably call the same `api.chownow.com/api/` with a different `X-CN-App-Info` channel (`Diner-iOS/<v>` or `Diner-Android/<v>`) and possibly a bearer token instead of cookies. Not confirmed.

**Why it's open:** This session has no mitmproxy / Frida / cert-unpinning stack and no mobile emulator. The desktop browser can only drive the web client.

**How to resolve:**
1. Install the ChowNow iOS and Android apps on a jailbroken/rooted device or a cert-unpinned emulator.
2. Run mitmproxy with the cert installed; intercept the full boot → search → menu → order flow for each OS.
3. Diff the request shapes against the web ones captured here; expect:
   - `X-CN-App-Info` differences (channel + app version)
   - Authentication could be bearer tokens stored in Keychain/Keystore rather than cookies (verify)
   - Likely an extra device-identity header (`X-CN-Device`, `User-Agent` carrying app build)
   - Possibly a `platform` or `cn_channel` query/body param
4. Catalog any mobile-only endpoints (push notifications, device registration, in-app notifications).

**Partial substitute:** The `direct.chownow.com` SPA is the same codebase as the "ChowNow Direct" branded iOS/Android apps' webview — so the web contract is probably ~95% of the mobile one. Treat this spec as a strong starting point for mobile replay.

## 3. The `pf` query parameter on `GET /api/restaurant`

**State:** Observed as `pf=1` on every discovery call. Meaning unknown. Candidates: pickup filter, "promoted first", "paid first", personalization flag.

**How to resolve:** Try `pf=0` and `pf` omitted on the same `(u_lat, u_lon)`; diff the response. If the result set differs or the ordering changes, we have the answer.

## 4. The `cn_channel` parameter (closed 2026-10-16)

**Answer:** `cn_channel` is **not an enum**. It's a free-form attribution tag that arrives on the page URL and is carried into API calls. Found by a static REA pass over `bundles/` (`analyze_javascript_application` Evidence `ev_5447bfed…`, `trace_application_feature` Evidence `ev_c9a47fdb…`), then confirmed by reading the code at the offsets REA reported. Module numbers below are webpack module IDs in `main.93c065e7.js` unless noted.

**Where the value comes from**
- The page URL's `?cn_channel=`. The SPA stores it per restaurant in sessionStorage under `{restaurantId}:cnChannel` (fallback key `cnChannel`). It's stored only if it is non-empty, differs from the stored value, matches `/^[A-Z0-9_-]*$/i`, and is at most 32 characters (module `54276` export `k`, using `90720.Qh` and `97730.E2.urlParam`).
- Reads go URL first, then sessionStorage (module `94322` export `ff`).

**The only literal values in the bundle**
| value                   | where (`module.export`) | meaning |
| ----------------------- | ----------------------- | ------- |
| `cn_website`            | `97730.$N`              | Default. On the Direct site, if the restaurant is not direct-live but is ordering-network-live and no channel is set, the SPA adds `?cn_channel=cn_website` and reloads (`chunk-244.js`, RestaurantPage). Module `85971` does the same redirect in another path. |
| `yelp`                  | inline                  | Forced on the Yelp-Web build for restaurant and menu requests. |
| `google_cn_marketplace` | `97730.nI`              | The only entry in the marketplace OBN-bypass list. With the `marketplaceObnBypass` flag on, this channel skips the `meta.marketplace: {id: "2"}` injection ([private-web-api.md Appendix A](endpoints/private-web-api.md#appendix-a--marketplace-meta-injection)). |

**Where it's sent**
- `GET /api/restaurant/{id}` and `GET /api/restaurant/{id}/menu[/{whenId}]` as `?cn_channel=` when a channel is known.
- `GET /api/customer/me/restaurant/{id}/recently-ordered?cn_channel=`.
- Order body `meta.channel`, which is an **object** `{cn_channel, cn_channel_xid}`, or `null` when no channel is set (module `72569` export `Sx`).
- Analytics event attributes, and the SPA's list of attribution params (`utm_source`, `utm_medium`, `utm_campaign`, `utm_term`, `cn_channel`).

**`cn_channel_xid`** is stored in sessionStorage `cnChannelXid`, truncated to 100 characters. It's set from the URL's `rwg_token` (preferred) or `cn_channel_xid` (format-checked), and only once a channel is stored (`chunk-244.js`). `rwg_token` is most likely a Reserve with Google conversion token; that's inferred from the name, not verified.

**Correction:** the 21-element array `["31001", …, "993"]` that this section used to call the channel allowlist is the SPA's list of handled **order-validation error codes** (module `57495` export `q$`). See [`ERRORS.md`](ERRORS.md#31xxx37xxx--993--order-business-rules).

**Still open:** which other channel strings partners or ChowNow put in inbound links. The SPA accepts any string in the format above, so the full set can only be found from real links, not from the bundle. The 4 inline scripts in `bundles/order-page.html` were not analyzed.

## 5. OpenAPI document for the Partner API

**State:** The developer portal publishes the Partner API in prose with per-endpoint pages, but no machine-readable OpenAPI document is linked from the pages we found.

**How to resolve:**
1. After obtaining a sandbox token, GET `https://openapi.chownow.com/v1/openapi.json`, `.../openapi.yaml`, `.../docs/openapi`, `.../swagger.json`, and `.../.well-known/openapi` — these are the five common well-known paths.
2. Scrape the per-endpoint doc pages at `developer.chownow.com/docs/api/<slug>` once a sandbox login is in hand; they likely include request/response schemas verbatim.

## 6. OIDC discovery for the Partner API auth

**State:** Token endpoints are `https://auth.{sandbox.}developer.chownow.com/oauth2/token`; the host pattern matches WorkOS AuthKit but not confirmed.

**How to resolve:** `curl` `https://auth.developer.chownow.com/.well-known/openid-configuration` and `https://auth.developer.chownow.com/oauth2/jwks` — these are typically public. The issuer, JWKS URL, and supported grants will be in the discovery doc.

## 7. `/api/customer/exists` request/response shape

**State:** OPTIONS=200; is almost certainly the first XHR fired by the Continue button on the login modal. Body shape inferred.

**How to resolve:** 10-second test: fire `POST /api/customer/exists {"email":"nobody@invalid.tld"}` from a browser (either via DevTools or by firing it from a page already on `*.chownow.com`). The response structure is low-risk and will tell us whether the SPA uses `{exists, has_password, has_sso_providers}` or something simpler.

## 8. Managed delivery courier state enum

**State:** `GET /api/order/{id}/status.managed_delivery.status` is a courier state string per the Partner API docs, but the actual enum values are not published. On the private API the same field is on `GET /api/order/{id}`.

**How to resolve:** Place a real delivery order and poll `GET /api/order/{id}` through the courier lifecycle. Collect every value seen into an enum. Likely covers `pending`, `assigned`, `picked_up`, `in_transit`, `delivered`, `cancelled`.

## 9. Promo codes and gift cards

**State:** `has_promo_code: false` on the sample restaurant; `promo_code: null` is accepted on `/api/order/validate`. Promo validation and application endpoints weren't captured because the sample restaurant had no promo. Gift cards weren't observed at all.

**How to resolve:** Pick a brand that advertises promo codes (`has_promo_code: true` on its restaurant payload) and attempt a code — the SPA's XHRs will reveal whether promo validation is a separate call or just a validate re-run with `promo_code` populated.

## 10. Rate limits

**State:** Not probed. The Partner API caps at 600 req/60 s per client org; the private API is probably similar per session but the exact ceiling is unknown.

**How to resolve:** From a single IP + session, fire 10 req/s against `GET /api/restaurant` and look for 429 + `Retry-After`.

## 11. The `sift_session_id` carrier

**State:** Sift Science JS runs on every page; the SPA bundle contains `sift_session_id` as a token near the order submit path. It is likely passed in the order body OR a header. Not confirmed.

**How to resolve:** Capture a real order submission (see Unknown #1).

## 12. Legacy aliases and version-2.0 semantics

**State:** Several endpoints silently fall back to v2.0 when `version=3.0` is requested (`/api/web/manifest`, `/api/customer/me`). It is unclear whether the v2.0 behavior is semantically equivalent or whether v3.0 adds fields.

**How to resolve:** For each endpoint, request `Accept: application/json version=2.0;` explicitly and compare against the implicit v3.0 fallback.

## 13. Catering / large-order flow

**State:** `has_catering: false` on sample restaurant; `is_catering_inquiry_form_enabled: false`. The two catering endpoints are inferred but not exercised.

**How to resolve:** Target a brand that advertises catering (`is_catering_inquiry_form_enabled: true`) and submit the lead form.

## 14. Favorites endpoint methods

**State:** The bundle has one literal `customer/${id}/favorites`. Verbs for add/remove/list unknown.

**How to resolve:** CORS OPTIONS preflight with `Access-Control-Request-Method: GET/POST/DELETE` against `/api/customer/<id>/favorites` to see which methods the server advertises. A follow-up single-shot call with each verb once authed will nail it.

## 15. Google Pay / Apple Pay token wire format

**State:** `GET /api/web/manifest.payment_processor_key` is a Stripe publishable key; Stripe's `payment_method.id` (`pm_...`) is what reaches `/api/order`. Apple Pay and Google Pay use the same Stripe tokenization pipeline (Stripe Elements for Payment Request Button). The exact body field name on `/api/order` for the Apple/Google Pay token has three candidates in the bundle: `payment.nonce`, `paymentMethodData`, `payment_card.id`. Not confirmed.

**How to resolve:** Capture a real Apple Pay or Google Pay checkout.
