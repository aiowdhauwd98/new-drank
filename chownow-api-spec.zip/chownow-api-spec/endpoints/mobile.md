# Mobile apps

What's known about ChowNow's native iOS and Android marketplace apps, derived from public app-association manifests and the iTunes lookup API. **No DEX or binary analysis was done** — see [`../UNKNOWNS.md`](../UNKNOWNS.md) #2 for the resolution path. The apps are webview wrappers around the same SPA that powers `direct.chownow.com`, so expect the private API surface documented in [`private-web-api.md`](./private-web-api.md) to be identical.

Captured 2026-10-15.

## iOS — ChowNow: Local Food Ordering

Pulled from `www.chownow.com/.well-known/apple-app-site-association` and the iTunes Store lookup API:

| Field                              | Value                                                        |
| ---------------------------------- | ------------------------------------------------------------ |
| App ID (teamID + bundle)           | `B5A97UB9Q7.com.ChowNow.Marketplace`                         |
| Team ID                            | `B5A97UB9Q7`                                                 |
| Bundle ID                          | `com.ChowNow.Marketplace`                                    |
| Display name                       | `ChowNow: Local Food Ordering`                               |
| App Store `trackId`                | `1210943577`                                                 |
| Version                            | `1.74.0`                                                     |
| Latest release                     | `2026-10-05`                                                 |
| Minimum iOS                        | `15.0`                                                       |
| Install size                       | 81,054,720 bytes (~77 MB)                                    |
| Seller                             | ChowNow, LLC                                                 |
| Primary genre                      | Food & Drink                                                 |
| Content rating                     | 4+                                                           |

### Deep-link paths

The iOS app registers itself for these URL patterns on `chownow.com`:

```json
{
  "applinks": {
    "details": [
      { "appID": "B5A97UB9Q7.com.ChowNow.Marketplace",
        "paths": ["/order/*/locations/*", "/"] }
    ]
  },
  "webcredentials": {
    "apps": ["B5A97UB9Q7.com.ChowNow.Marketplace"]
  }
}
```

- Order deep links (`/order/{brand}/locations/{location}`) and the root (`/`) open the native app.
- `webcredentials` enables Keychain shared-password autofill between `www.chownow.com` and the app.

### Per-restaurant Direct apps

Separate from the marketplace app, every ChowNow Direct restaurant can ship its own iOS build. Example seen in `GET /api/restaurant/35`:

```
"ios_app_store_id": "1522389157"            # Woodlands Market - Kentfield
```

These are branded webview wrappers around `direct.chownow.com`, with per-restaurant icon and theming (`ordering_theme`). Expect `X-CN-App-Info: Direct-iOS/<v>` on the API calls those builds make.

## Android — ChowNow (marketplace)

Pulled from `www.chownow.com/.well-known/assetlinks.json`:

| Field                        | Value                                                                                                 |
| ---------------------------- | ----------------------------------------------------------------------------------------------------- |
| Package name                 | `com.chownow.discover`                                                                                |
| SHA256 cert fingerprint      | `CA:27:AC:EC:C6:28:71:83:7D:B1:B3:23:A4:3D:75:00:60:6F:53:5B:74:EF:A9:8B:4F:78:0E:FC:80:40:49:E7` |
| Delegation permissions       | `delegate_permission/common.handle_all_urls`, `delegate_permission/common.get_login_creds`            |

Note: the iOS bundle is `com.ChowNow.Marketplace` (CamelCase, "Marketplace"), the Android package is `com.chownow.discover` (lowercase, "discover"). Different naming at the two platforms for the same product. The `handle_all_urls` delegation means **every** chownow.com URL opens the app when installed; `get_login_creds` enables Credential Manager password sharing between the website and the app.

Full manifest content:

```json
[
  {
    "relation": ["delegate_permission/common.handle_all_urls"],
    "target": {
      "namespace": "android_app",
      "package_name": "com.chownow.discover",
      "sha256_cert_fingerprints": ["CA:27:AC:EC:C6:28:71:83:7D:B1:B3:23:A4:3D:75:00:60:6F:53:5B:74:EF:A9:8B:4F:78:0E:FC:80:40:49:E7"]
    }
  },
  { "relation": ["delegate_permission/common.get_login_creds"],
    "target": { "namespace": "web", "site": "https://www.chownow.com" } },
  { "relation": ["delegate_permission/common.get_login_creds"],
    "target": {
      "namespace": "android_app",
      "package_name": "com.chownow.discover",
      "sha256_cert_fingerprints": ["CA:27:AC:EC:C6:28:71:83:7D:B1:B3:23:A4:3D:75:00:60:6F:53:5B:74:EF:A9:8B:4F:78:0E:FC:80:40:49:E7"]
    } }
]
```

### Per-restaurant Direct apps

Same pattern as iOS. Example from `GET /api/restaurant/35`:

```
"android_app_url": "https://play.google.com/store/apps/details?id=com.chownow.woodlandsmarketca"
```

Each Direct restaurant gets its own `com.chownow.<brandslug>` package.

## API surface

**Expected to be identical to the private web API** at `api.chownow.com/api/`, since the native apps are React Native (iOS/Android) with the same codebase as the SPA, OR webviews around `direct.chownow.com`. The visible differences would be:

- `X-CN-App-Info` channel suffix — probably `Diner-iOS/<app-version>` and `Diner-Android/<app-version>` (verify).
- Session carrier — likely still cookie-based for the webview path; possibly a bearer-token model on native code paths if any.
- An extra device identifier header or body field (candidates seen in bundle: `cn_device_id`, `Sift-Session-Id`).
- A per-app push-notification registration endpoint (not reachable from the web).

### How to confirm

See [`../UNKNOWNS.md`](../UNKNOWNS.md) #2. Short version:

1. Install `com.ChowNow.Marketplace` on a jailbroken iOS device, OR `com.chownow.discover` on a rooted Android device (or cert-unpinned emulator).
2. mitmproxy with the system CA installed on the device.
3. Drive boot → search → menu → cart → checkout → order on both platforms.
4. Diff against the web captures in `../examples/`. Expect ≥95% overlap.

### What we tried

- APK download from APKMirror, APKPure, APKMonk, APKPure.net — Cloudflare / 403 across the board for automated clients. The APKMirror catalog page itself (`https://www.apkmirror.com/apk/chownow-inc/chownow-local-food-ordering/`) is reachable but download links are gated.
- Static strings analysis of the public SPA bundle (`direct.chownow.com/static/js/main.<hash>.js`) — see [`../bundles/`](../bundles/). The same bundle probably ships inside the Direct apps' webview, so the endpoint list already in the web spec covers that path.
