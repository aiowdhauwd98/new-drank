# ChowNow Private Web API — `api.chownow.com/api/`

The private API that powers `www.chownow.com`, every `direct.chownow.com`-hosted ordering SPA, and the Yelp Food Ordering surface. **Different host, different auth, different error schema from the Partner API** at `openapi.chownow.com/v1`. If you came looking for the officially-documented integrator API, see [`partner-api.md`](partner-api.md) instead.

## Legend

- `[VERIFIED by replay]` — fired via `curl`/`httpx` against the live host and got the documented response.
- `[OBSERVED]` — path + method confirmed from the SPA's own XHR (either via the installed `fetch` interceptor, `performance.getEntriesByType('resource')`, or a CORS **OPTIONS** preflight returning 200).
- `[INFERRED]` — path extracted from the minified SPA bundle (string literal, `useQuery`/`useMutation` call site, or React route constant) but **not yet** replayed. Methods are sometimes guesses with reasoning stated in the row.

Captured 2026-10-15, SPA v5.211.0.

---

## 0. Base + shared contract

| Property                 | Value                                                               |
| ------------------------ | ------------------------------------------------------------------- |
| Base URL                 | `https://api.chownow.com/api/`                                      |
| Edge                     | Cloudflare                                                          |
| Transport                | HTTPS; HTTP/1.1 and HTTP/2                                          |
| Session carrier          | Cookie set by `POST /api/customer/signin` (+ magic-link / SSO)      |
| Request `credentials`    | Always `include` from the SPA (`fetch(url, { credentials: 'include' })`)|
| CSRF                     | None observed on the private API (session cookie + SameSite is the only defense) |
| Content type (write)     | `application/json; charset=UTF-8`                                   |

### Required request headers (write and read)

```
Accept:            application/json version=3.0;
Content-Type:      application/json; charset=UTF-8
X-CN-App-Info:     Marketplace-Web/5.211.0        <-- or Direct-Web/5.211.0, Yelp-Web/5.211.0
Origin:            https://www.chownow.com         <-- or the direct brand host, or https://yelp.com
```

`Accept` carries the API version. Observed values: `2.0`, `3.0`, `5.0`. If the requested version does not exist for the resource, the server **silently falls back to its default (currently 2.0)** and includes a top-level `warnings: ["Reverting to default API version: 2.0"]` and `version: "2.0"` in the response.

`X-CN-App-Info` is read by the server to tag the request's channel. On write bodies with `channel = Marketplace-Web` the request builder injects `meta.marketplace: {id: "2", x_id: null}` into the body. If you replay without this, writes still succeed, but the backend will not record the marketplace channel.

### Shared response envelope (version 3.0 and up)

Successful read responses are the resource object itself with a trailing `"version": "3.0"` key. The `warnings` list is present only when something is off (version fallback, deprecated field, …).

### Shared error schema

**This is NOT RFC 9457.** The private API uses:

```json
{ "errors": [ { "code": "<string>", "message": "<string>", "reason": "<string>", "field": "<string|null>", "value": "<any>" } ] }
```

Full error-code catalog (every code encountered in replay) lives in [`../ERRORS.md`](../ERRORS.md). High-level families:

- `100xx` — JSON Schema validation (`10101` required, `10201` enum, `10202` type, `10204` minLength, `10207` additionalProperties).
- `120xx` — operation validation (`12004` invalid value).
- `200xx` — identity/account (`20105` FB SSO fail, `20900` user/account mismatch).
- `3xxxx` — order business rules (`32003` below minimum).
- `401`/`404`/`500`/`501` — stock HTTP mirrored into `code`.

Backend hints the errors leak: **Bottle + jsonschema** for most of the surface (legacy), **FastAPI/Pydantic** on `/autocomplete` (newer), **Django REST Framework** on `/customer/me/orders` (newer).

Compare to the Partner API, which uses the richer RFC 9457 Problem Details with a `code` enum (`ITEM_UNAVAILABLE`, `MENU_EXPIRED`, …). Private API error codes are shallower.

### Rate limits

Not disclosed, no `X-RateLimit-*` headers observed in captures. The Partner API caps at 600 req / 60 s per client org; expect something comparable here per session. Honor `Retry-After` on 429 if returned.

---

## 1. Bootstrap

### `GET /api/web/manifest` — client bootstrap configuration — **[VERIFIED by replay]**

Called once on first boot. Response is a flat object of URLs, legal links, the Stripe publishable key, and the aggregate ChowNow savings number used for marketing copy.

```http
GET /api/web/manifest
Accept: application/json version=3.0;
X-CN-App-Info: Marketplace-Web/5.211.0
```

Response `200`:

```json
{
  "ccpa_url": "https://chownow-requests.my.onetrust.com/webform/.../b16058fc-...",
  "chownow_marketing_privacy_url": "https://iterable.com/trust/privacy-policy/",
  "payment_processor_key": "pk_live_1rHqZgeuWfzjo9nCVWMdRsbZUztUaNhhlxt4wHymS1kVK5MDf8dLcyjojGR487uMuZSeZyjKIraWRqrTKSoLfNzr000Bs7zTqEF",
  "terms_of_service_url": "https://get.chownow.com/terms-of-service",
  "privacy_policy_url": "https://get.chownow.com/privacy-policy",
  "aggregate_restaurant_savings": {
    "dollar_amount": 640000000,
    "description": "Diners like you saved restaurants $640M since 2011."
  },
  "request_account_deletion_url": "https://chownow-requests.my.onetrust.com/webform/.../b16058fc-...",
  "customer_service_phone": "18887072469",
  "rewards_terms_url": "https://get.chownow.com/legal/restaurant-rewards/",
  "warnings": ["Reverting to default API version: 2.0"],
  "version": "2.0"
}
```

Note the version fallback: this endpoint does not implement v3.0 and silently serves v2.0 with the warning.

The `payment_processor_key` is a **Stripe publishable key** used as the fallback / marketplace-level Stripe key. Per-restaurant membership checkouts also return their own `membership.processor_key` on `GET /api/restaurant/{id}` (same key in this capture; may differ for other brands).

Full captured example: [`examples/20261015T225754Z_GET_api_chownow_com_api_web_manifest/`](../examples/20261015T225754Z_GET_api_chownow_com_api_web_manifest/).

---

## 2. Discovery (marketplace search)

### `GET /api/restaurant` — list / search restaurants near a point — **[VERIFIED by replay]**

The marketplace list behind `www.chownow.com/search?loc=<city>` and the "Find More Restaurants" link on brand pages.

```
GET /api/restaurant
    ?pf=1
    &aggs=cuisines
    &u_lat=<latitude>
    &u_lon=<longitude>
    &limit=<n>
    &offset=<n>
    [&tags=<csv>]
```

| Param     | Required | Example                 | Notes                                                                     |
| --------- | -------- | ----------------------- | ------------------------------------------------------------------------- |
| `u_lat`   | yes      | `34.0549076`            | Latitude of the user's selected address (Google Geocoder gives this).     |
| `u_lon`   | yes      | `-118.242643`           | Longitude.                                                                |
| `pf`      | no       | `1`                     | **Replay-verified no-op** (2026-10-15): `pf=0`, `pf=1`, `pf=2`, and `pf` omitted all return the identical response (same `total: 439`, same first-5 ids). Likely legacy or server-side telemetry only — the SPA still sends `pf=1`. |
| `aggs`    | optional | `cuisines`              | CSV of aggregations to include. Only `cuisines` observed; backend is Elasticsearch-shaped. |
| `limit`   | optional | `30`                    | Page size.                                                                |
| `offset`  | optional | `30`                    | Pagination cursor (also surfaced as part of the `next` string).           |
| `tags`    | optional | `is_new`                | Filter by a facet tag. Values from `/api/restaurant/facets` (see below).  |

Response `200`:

```json
{
  "next":   "/api/restaurant?pf=1&aggs=cuisines&u_lat=...&u_lon=...&limit=30&offset=30",
  "prev":   null,
  "limit":  30,
  "offset": 0,
  "total":  439,
  "aggregations": {
    "cuisines": [
      { "key": "Mexican",            "doc_count": 45 },
      { "key": "Breakfast & Brunch", "doc_count": 44 },
      ...
    ]
  },
  "restaurants": [
    {
      "distance": 0.1662849973647333,
      "id": "59287",
      "address": {
        "id": "194894848",
        "address_string": "201 N Los Angeles St\nLos Angeles CA 90012",
        "formatted_address": "201 N Los Angeles St, Los Angeles CA 90012",
        "place_formatted_address": "201 N Los Angeles St, Los Angeles, CA 90012",
        "street_address1": "201 N Los Angeles St",
        "street_address2": null,
        "zip": "90012", "state": "CA", "city": "Los Angeles",
        "country": "USA", "country_alpha2": "US",
        "is_google_place": false, "name": null,
        "latitude": 34.0525627, "longitude": -118.2419891,
        "geo": "34.0525627,-118.2419891"
      },
      "order_ahead": { "is_pickup_ahead_available": true, "is_delivery_ahead_available": true, "is_curbside_ahead_available": false },
      "cuisines": ["Mediterranean"],
      "primary_cuisine": null,
      "phone": "2133469400",
      "name": "California Pita - Los Angeles",
      "restaurant_company_id": "368",
      "short_name": "California Pita",
      "is_delivery_available": false,
      "next_delivery_time": "202610160730",
      "is_pickup_available": false,
      "next_pickup_time":   "202610160730",
      "is_curbside_available": false,
      "next_curbside_time": null,
      "media": { "cover_image_url": "https://menuimages.chownowcdn.com/image-resizing?image=00e6fd4e-...&left=0&top=0&right=0&bottom=15" },
      "has_automatic_discount": false,
      "default_automatic_discount_label": "Promo Available",
      "low_cost_delivery_label": "Low Delivery Fee",
      "has_low_cost_delivery": true,
      "is_favorite": false
    }
    // 29 more
  ],
  "version": "3.0"
}
```

Notes:

- `restaurants[].id` is the **location** id. `restaurants[].restaurant_company_id` is the **brand/company** id. The web URL for the result is `/order/{restaurant_company_id}/locations/{id}`.
- `next_delivery_time` / `next_pickup_time` are `YYYYMMDDHHMM` local time strings (no separator), **not** ISO 8601.
- `distance` is miles.
- Pagination: follow `next` as-is (it's already a relative URL).

Full captured example: [`examples/20261015T230500Z_GET_api_chownow_com_api_restaurant_pf_1_aggs_cuisines_u_lat_34_0549076_u_lon_118_242643_limit_30/`](../examples/20261015T230500Z_GET_api_chownow_com_api_restaurant_pf_1_aggs_cuisines_u_lat_34_0549076_u_lon_118_242643_limit_30/).

### `GET /api/restaurant/facets` — facet counts for a point — **[VERIFIED by replay]**

Returns the subset of the near-point restaurant list that satisfies each binary facet tag. Powers the horizontal carousels on the search page ("Saved Spots", "New on ChowNow", "Low delivery fee", …).

```
GET /api/restaurant/facets
    ?u_lat=<lat>&u_lon=<lon>
    &facets=is_favorite,is_new,low_cost_delivery
```

Response `200`:

```json
{
  "facets": [
    {
      "tag": "is_favorite", "name": "Saved Spots",
      "restaurants": [], "total": 0,
      "next": null, "prev": null, "action": null
    },
    {
      "tag": "is_new", "name": "New on ChowNow",
      "restaurants": [ { "distance": 0.99..., "id": "65129", "address": {...}, ... } ],
      "total": N,
      "next": "/api/restaurant?u_lat=...&u_lon=...&tags=is_new",
      "prev": null, "action": null
    },
    ...
  ]
}
```

Each facet's `next` link is a URL into `/api/restaurant?tags=<tag>` — i.e., the two endpoints compose naturally.

### `GET /api/company/{company_id}/restaurants` — brand metadata — **[VERIFIED by replay]**

Despite the plural name, this is **brand-level info**, not a list of locations.

Response `200`:

```json
{
  "id": "32",
  "name": "Woodlands Market",
  "address": { "country_alpha2": "US" },
  "delivery_only": false,
  "has_catering": false,
  "ios_app_store_id": "1522389157",
  "android_app_url": "https://play.google.com/store/apps/details?id=com.chownow.woodlandsmarketca",
  "ordering_theme": { "light": { "surface_color": { "value": "#D9D8D7", "label": "Vanilla" } }, "dark": { ... } },
  ...
}
```

A `?location=<lat>,<lng>` query param was observed in client bundles but **does not alter the response** in testing — same payload returned. Suspected deprecation.

### `GET /api/yelp/{company_id}/restaurant` — Yelp handoff variant — **[INFERRED]**

String literal in the bundle under the Yelp-Web channel path. Only called when `X-CN-App-Info: Yelp-Web/*`. Likely returns the same shape as `GET /api/restaurant/{id}` but with Yelp-specific merchandising fields.

### `GET /api/yelp/opportunity/{id}` — Yelp opportunity context — **[INFERRED]**

Associated with a Yelp Food Ordering "opportunity_token" that flows through the body meta on writes:
```js
...t?.opportunity_token}}},delete m.opportunity_token
```
Pattern: the Yelp handoff carries an opportunity token in the URL; the SPA strips it from body meta before send.

### `POST /api/yelp/validate` — Yelp-channel order validation — **[INFERRED]**

Yelp-specific sibling of `POST /api/order/validate`. Confirmed as a string literal, verb inferred from context (it's a mutation-shaped React Query call).

---

## 3. Restaurant & menu

### `GET /api/restaurant/{location_id}` — restaurant detail — **[VERIFIED by replay]**

The main per-restaurant payload. Note **`location_id`**, not brand/company id. 15.3 KB for Woodlands Market Kentfield.

Response `200` (abbreviated — full example on disk):

```json
{
  "id": "35",
  "company_id": "32",
  "name": "Woodlands Market - Kentfield",
  "short_name": "Woodlands Market - Kentfield",
  "phone": "4154578160",
  "address": {
    "id": 844,
    "street_address1": "735 College Ave.",
    "street_address2": "", "city": "Kentfield", "state": "CA", "zip": "94904",
    "country": "USA", "country_alpha2": "US",
    "geo": "37.9523048,-122.5500870",
    "latitude": 37.9523048, "longitude": -122.550087,
    "formatted_address": "735 College Ave., Kentfield CA 94904",
    "place_formatted_address": "735 College Ave., Kentfield, CA 94904",
    "is_google_place": false, "name": null, "address_string": "..."
  },
  "allows_no_payment_checkout": false,
  "allows_order_for_now": true,
  "force_managed_delivery": false,

  "fulfillment": {
    "curbside": null,
    "pickup": {
      "customizations": null, "max_order_amt": null, "min_order_amt": 0.50,
      "order_ahead": { "min_lead_time": 30, "max_lead_time": null, "precision": null },
      "tip": { "allows_tip": false, "suggested_rates": [10, 15, 18, 20], "default_rate": null },
      "is_available_now": true, "next_available_time": null,
      "hours":         [ { "date": "2026-10-15", "dow": "thursday", "ranges": [{"from":"07:00","to":"20:30","label":null}] }, ... ],
      "display_hours": [ { "dow": "Sunday", "day_id": 1, "ranges": [{"to":"20:30","from":"07:00","label":null}] }, ... ],
      "estimated_fulfillment_time": null
    },
    "delivery": {
      "customizations": null,
      "delivery_ranges": [
        { "id": "96543", "allows_tip": true, "delivery_charge": 100.00,
          "delivery_charge_type": "managed_fee_customer_contribution_percent",
          "managed_delivery_id": "99",
          "max_order_amt": 500.00, "min_order_amt": 7.98, "service_type": null }
      ],
      "managed_delivery_id": "99",
      "order_ahead": { "min_lead_time": 30, "max_lead_time": null, "precision": null },
      "tip": { "allows_tip": false, "suggested_rates": [10, 15, 18, 20], "default_rate": null },
      "is_available_now": true, "next_available_time": null,
      "hours": [...], "display_hours": [...], "estimated_fulfillment_time": null
    },
    "dine_in": null
  },

  "order_ahead": {
    "is_pickup_ahead_available": true,
    "is_delivery_ahead_available": true,
    "is_curbside_ahead_available": false,
    "is_dine_in_ahead_available": false,
    "min_lead_time": 30, "max_lead_time": null, "precision": 15, "num_days": 7,
    "current_time_index": 66,
    "days": [
      { "date": "2026-10-15", "dow": "thursday",
        "pickup":   [0,0,...,1,1,1,1,1,...], "pickup_index_ranges":   [{"from":66,"to":81}],
        "delivery": [0,0,...,1,1,1,1,1,...], "delivery_index_ranges": [{"from":66,"to":81}],
        "curbside": [0,0,...],              "curbside_index_ranges": [] },
      ...
    ]
  },

  "large_order": { "min_lead_time": 60, "amount": 50.00 },
  "has_promo_code": false,
  "has_dine_in_promo_code": false,

  "payment_processor_id": "3",
  "tax_rate": 8.250, "tax_type": null,
  "fees": { "service": { "charge_type": null, "amount": null, "min_order": null },
            "forced_gratuity": { "charge_type": "amount", "amount": null, "min_order": 0.00 } },
  "misc_fee": { "unit": "dollar", "rate": null, "min_order": 0.00, "label": "Gratuity" },
  "min_delivery_fee": "7.98+",

  "has_catering": false, "is_catering_inquiry_form_enabled": false, "catering_url": null,
  "has_low_cost_delivery": false, "low_cost_delivery_label": null,
  "has_automatic_discount": true,
  "available_discounts": [
    { "id": "127489", "type": "automatic",
      "short_description": "Get 10% off",
      "long_description":  "Get 10% off orders. One-time use only.",
      "description":       "10% off ,\nall day every day,\nfor a limited time only,\nonce per customer" }
  ],
  "redeemed_discounts": [],

  "membership": {
    "processor_key": "pk_live_1rHqZgeuWfzjo9nCVWMdRsbZUztUaNhhlxt4wHymS1kVK5MDf8dLcyjojGR487uMuZSeZyjKIraWRqrTKSoLfNzr000Bs7zTqEF",
    "is_enabled": false, "plans": []
  },

  "rewards": null,

  "is_live": true,
  "is_busy": false,
  "is_post_pay": false,
  "is_menu_preview_enabled": false,
  "is_multi_location": true,
  "is_favorite": false,

  "ios_app_store_id": "1522389157",
  "android_app_url": "https://play.google.com/store/apps/details?id=com.chownow.woodlandsmarketca",
  "native_app_versions": { "android_order_direct": null, "ios_order_direct": null, "tablet": "9.0.3" },
  "native_app_banner_type": "branded",
  "display_chownow_app_banner": false,

  "website_url": "www.woodlandsmarket.com",
  "primary_cuisine": "American (Traditional)",
  "cuisines": ["American (Traditional)", "American (New)", "Deli", "Sandwiches"],
  "delivery_only": false,

  "ordering_theme": { "light": { "surface_color": {"value":"#D9D8D7","label":"Vanilla"} }, "dark": {...} },
  "fee_descriptions": [],
  "closures": [],
  "google_place_actions_data": null,

  "transactional_ads": { "marketplace": true, "direct": true, "obn": true },
  "is_discover_live": true, "is_direct_live": true, "is_ordering_network_live": true,

  "media": {
    "cover_image_url": "https://menuimages.chownowcdn.com/image-resizing?image=d26e9465-...jpg&left=0&top=0&right=0&bottom=52",
    "logo_image_url":  "https://menuimages.chownowcdn.com/image-resizing?image=3388d1f0-...jpg&left=0&top=0&right=0&bottom=0"
  },
  "locale_name": "Kentfield",
  "delivery_only_maps": [],

  "display_properties": {
    "enable_special_instructions": true,
    "marketing_consent": { "enabled": false },
    "menu_disclaimer": "",
    "sanitation_compliance": null,
    "special_instructions_text": "Please note any add-on requests must be added to cart. Some special instructions may not be honored",
    "allows_order_single_use_items": true,
    "order_single_use_items_label": "Include utensils, condiments, etc."
  },

  "version": "3.0"
}
```

Design notes worth stealing / knowing:

- **Fulfillment slot grid.** `order_ahead.days[].{pickup,delivery,curbside}` is a 96-entry 0/1 array per day — one slot per 15 minutes (24 h × 4). `precision` names the slot width in minutes. `current_time_index` tells you where "now" is in today's array. `pickup_index_ranges: [{from,to}]` is just the run-length encoding of consecutive 1s. The client renders a scheduler straight off this.
- **Delivery charge model.** `delivery_ranges` is an array because a restaurant can have multiple tiers of distance- or dollar-based delivery pricing. `delivery_charge_type: "managed_fee_customer_contribution_percent"` is the single value observed; the backend has a `managed_delivery_id` (`99` here) linking to a courier integration record. `min_order_amt` / `max_order_amt` gate orders.
- **Payment processor.** `payment_processor_id: "3"` is a numeric enum; `"3"` corresponds to Stripe based on the Stripe-shaped `pk_live_...` publishable key returned alongside it on `membership.processor_key` and on `/api/web/manifest`. Expect other integer ids for other PSPs on brands that use them.
- **Discount model.** `available_discounts[].type: "automatic"` means it is applied without a code. `has_promo_code: false` tells the UI not to show a promo input. `redeemed_discounts` populates after validate/placement.
- **Ad surfaces.** `transactional_ads: {marketplace, direct, obn}` are three independent booleans gating Rokt and in-flow upsell ads; `obn` is the Order Better Network.

### `GET /api/restaurant/{location_id}/menu` — current menu — **[VERIFIED by replay]**

52.8 KB for the sample restaurant. The response's `id` field is the **menu version id**; it is of the form `<company_id>_<yyyymmddhhmm>` and rotates on every menu edit — the server treats menus as immutable snapshots. You must pass this `menu_id` into order validate/place for them to accept your cart (same contract as the Partner API's `menu_id` + `MENU_EXPIRED`).

Response `200`:

```json
{
  "id": "121704_202610151951",
  "menu_categories": [
    {
      "id": "0", "name": "Popular Items",
      "items": [
        {
          "id": "M_404635_3111147",
          "name": "Sandwich with Meat",
          "description": "Includes your choice of bread, meat, and condiments. ...",
          "is_meta": true,
          "meta_item_details": {
            "serving_size_group": {
              "child_ids": ["3111147_3723854","3111147_6672357","3111147_6678792", ...]
            }
          }
        },
        ...
      ]
    },
    ...
  ]
}
```

- `menu_categories[]` — ordered sections ("Popular Items", "Build Your Own Sandwich", "Specialty Sandwiches", …).
- `items[]` — each with `id`, `name`, `description`, pricing, availability flags, and `meta_item_details` when the item has a size/variant family. `is_meta: true` items are grouping items whose `child_ids` are the real orderable items.
- Modifier/option groups and item-level price are deeper in the payload — see the full example on disk.
- Item ids use the pattern `M_<company_id>_<item_id>`.

Full captured example: [`examples/20261015T230305Z_GET_api_chownow_com_api_restaurant_35_menu/`](../examples/20261015T230305Z_GET_api_chownow_com_api_restaurant_35_menu/).

### `GET /api/restaurant/{location_id}/menu/{menu_id}` — specific menu version — **[INFERRED]**

Fetching an immutable menu snapshot by id. Used when the client is working with a quote that references an older `menu_id` and needs to render it without re-pricing.

### `POST /api/restaurant/{location_id}/item-recommendations` — recommendations — **[OBSERVED]** (v5.0)

```http
POST /api/restaurant/35/item-recommendations
Accept: application/json version=5.0;
X-CN-App-Info: Marketplace-Web/5.211.0
Content-Type: application/json; charset=UTF-8

{ "menu_id": "121704_202610151951",
  "selected_item_ids": ["M_404635_3111147"],
  "requested_time": "202610161200"   // optional, YYYYMMDDHHMM
}
```

Returns a short list of upsell items. 4-second client-side timeout; the SPA fires a Sentry breadcrumb (`eventName: wK.up...`) on timeout and silently drops the recommendation UI.

### `GET /api/restaurant/{location_id}/catering` — catering details — **[INFERRED]**
### `POST /api/restaurant/{location_id}/catering-inquiry` — catering lead form — **[INFERRED]**

Both exist as string literals; the inquiry endpoint is `is_catering_inquiry_form_enabled: true` on brand metadata (false for Woodlands Market).

---

## 4. Authentication

Email+password + Facebook SSO, under `POST /api/customer/login`. Google/Apple SSO + magic-link + forgot/reset variants under `PUT /api/customer/<action>` (each shares a wrapper that validates `is_optout: boolean` before dispatching to the sub-handler).

**CORS caveat:** OPTIONS preflight is a **wildcard** under `/api/customer/*` — `/api/customer/foobar-does-not-exist` returns 200 to a CORS preflight. So the OPTIONS=200 technique alone over-estimates the endpoint set. The real existence/method shape for each row below was verified by actually sending the request. See [`../ERRORS.md`](../ERRORS.md) for the full error-code catalog captured during this phase.

### Session cookies

- **Anonymous session**: `Set-Cookie: session=<uuid>; HttpOnly; Max-Age=1800; Path=/; SameSite=Lax; Secure` — minted on **every call to a protected endpoint** (restaurant detail, discovery, order/validate). 30-minute TTL. Scoped to `api.chownow.com` (no `Domain` attribute → defaults to the request host).
- **Authenticated session**: `Max-Age=2592000` (30 days). Same cookie name (`session`), replaces the anonymous one on `POST /api/customer/login`.
- **Logout** returns `Set-Cookie: session=""; expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=-1` — standard delete.

Carrying the anonymous session cookie through to the authed endpoints does NOT elevate it. These endpoints key off the server-side session state, not the cookie value. The 30-minute vs 30-day TTL difference is the clearest observable signal of "upgraded" state.

### `GET /api/customer/exists?email=<email>` — email existence check — **[VERIFIED by replay (401 anonymous)]**

Called first when the user hits "Continue" on the login/signup modal with just an email. Routes between "show password step" (account exists) and "show full signup form" (account doesn't).

```http
GET /api/customer/exists?email=user%40example.com
Accept: application/json version=3.0;
X-CN-App-Info: Marketplace-Web/5.211.0
Origin: https://www.chownow.com
```

Replay confirmed on 2026-10-15:

- **It is `GET`, not `POST`.** OPTIONS preflight returned 200 for POST (CORS allowance), but `POST /api/customer/exists` returns `405 Method Not Allowed` with the Bottle framework HTML 405 page.
- **Email travels as a query param**, not a body — `?email=<url-encoded>`.
- **Anonymous callers get `401`** with the standard JSON error:
  ```json
  { "errors": [ { "code": "401", "message": "Authorization required.", "reason": "API logic validation" } ] }
  ```
  So the login modal must set an anonymous session cookie on page load that satisfies this before the Continue button is wired up. Treat as a session-required endpoint even though it is the first step of login.

Likely authed response `200` (shape still inferred):

```json
{ "exists": true,  "has_password": true,  "has_sso_providers": ["google"] }
```

### `POST /api/customer/login` — the real signin endpoint — **[VERIFIED by replay]**

**Despite the name, this is the current canonical signin endpoint, not a legacy alias.** It accepts a discriminated body:

```http
POST /api/customer/login
Accept: application/json version=3.0;
Content-Type: application/json; charset=UTF-8
X-CN-App-Info: Marketplace-Web/5.211.0
Origin: https://www.chownow.com

{ "email": "user@example.com", "password": "..." }
```

OR, Facebook SSO path on the same endpoint:

```json
{ "fb_token": "<Facebook user access token>" }
```

Verified response `200` (payload = Customer schema; see §5 below):

```json
{ "id": "69538988", "first_name": "...", "last_name": "...", "is_optout": false,
  "email": "user@example.com",
  "billing":  { "cards": [] }, "delivery": { "addresses": [] },
  "curbside": null, "lifetime_restaurant_savings": null,
  "active_marketplace_order_id": null,
  "memberships": [], "rewards": [],
  "warnings": ["Reverting to default API version: 2.0"], "version": "2.0" }
```

Sets the authed session cookie:

```
Set-Cookie: session=<uuid>; HttpOnly; Max-Age=2592000; Path=/; SameSite=Lax; Secure
```

An invalid Facebook token returns `{"code":"20105","message":"Account creation via Facebook failed"}`. An empty body returns `{"code":"10101","field":"fb_token"}` — the dispatcher checks for `fb_token` first and falls through to the email/password handler when it's absent.

The sibling path `PUT /api/customer/signin` **also exists** but is **not** the login endpoint — it is a stale alias that only validates the `is_optout` wrapper then 401s. Treat as deprecated.

### `POST /api/customer` — account creation (signup) — **[VERIFIED by replay — creates a real account]**

The real signup endpoint. **Not** `/customer/signup` (which 405s on POST and 401s on PUT after the `is_optout` wrapper).

```http
POST /api/customer
Accept: application/json version=3.0;
Content-Type: application/json; charset=UTF-8
X-CN-App-Info: Marketplace-Web/5.211.0

{ "email": "user@example.com",
  "password": "StrongP@ssw0rd!",
  "first_name": "...",
  "last_name": "..." }
```

Verified required set (via progressive validator walk): **email, password, first_name, last_name**. Phone + marketing_consent are optional. On success returns `201 Created`, the full Customer object, AND sets the authed 30-day session cookie.

#### No email verification — security note

**ChowNow does not gate account functionality on email ownership.** The `201 Created` response is immediately followed by an authed session cookie with 30-day Max-Age; `GET /customer/me` returns the user record on the very next request, and subsequent `POST /customer/login` with the same credentials re-authenticates with no intervening OTP / confirm-link / verify step.

Verified during replay 2026-10-15: a signup against a disposable `*@mailinator.com` address produced a fully usable account before any email was clicked. The mailinator inbox did receive a welcome email, but clicking the link in it is a soft nudge, not a gate. There is no observed call to `/customer/verify-email`, `/customer/confirm`, or an equivalent.

Implication: the signin flow (email + password) cannot assume the account's `email` claim represents a real, verified mailbox. For a payment-attached service that's a trust gap on the diner side; the restaurant takes payment risk through the processor, not through the account identity.

### `PUT /api/customer/{id}` — update profile — **[VERIFIED by replay]**

**Note the path uses the user's numeric id, NOT `/me`.** `PUT /api/customer/me` returns `403 20900 "User and account id mismatch"` — the server treats `me` as a literal path segment and compares against the session user_id.

```http
PUT /api/customer/69538988
{ "is_optout": true }
```

Returns 200 with the full updated Customer object. Required: `is_optout: boolean` (cross-cutting wrapper applied to all PUT /customer/* routes). Everything else is optional.

### `PUT /api/customer/{magic-link, google, apple, sso, forgot-password, reset-password, password, session, validate}` — **[OBSERVED as `is_optout`-wrapper paths]**

Each of these paths, when hit with `PUT {"is_optout": false}` and nothing else, returns `401 "Authorization required."` from an anonymous session. So the SPA calls them from an authed state, not from the login modal.

That rules out my earlier guess that these are pre-auth SSO completion endpoints. The actual Google/Apple/magic-link completion probably goes through the same `POST /api/customer/login` dispatcher (which already discriminates by body shape). These `PUT` paths are more likely post-authentication operations — link an SSO identity to an existing account, verify a reset token, etc.

Body shapes beyond `is_optout` were not captured. **The `/api/customer/*` namespace preflights 200 for every path including nonsense ones** (`/customer/foobar-does-not-exist` preflights 200 too), so OPTIONS alone cannot distinguish real endpoints from the CORS wildcard.

### `POST /api/customer/logout` — sign out — **[VERIFIED by replay]**

```http
POST /api/customer/logout
Cookie: session=<authed>
```

Response `200`:

```json
{ "status": "ok", "version": "2.0", "warnings": ["Reverting to default API version: 2.0"] }
```

Response sets `Set-Cookie: session=""; expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=-1` — standard cookie delete. The session is invalidated server-side as well.

---

## 5. Customer profile and saved resources

### `GET /api/customer/me` — current user — **[VERIFIED by replay (anonymous → 404)]**

```http
GET /api/customer/me
```

Response `200` (authenticated):

```json
{
  "id": "...", "email": "...", "first_name": "...", "last_name": "...",
  "phone": "...", "marketing_consent": false,
  "created": "...", "updated": "...",
  ...
}
```

Response `404` (anonymous):

```json
{"warnings": ["Reverting to default API version: 2.0"], "version": "2.0"}
```

Note the server does **not** 401 on anonymous — it 404s. Treat 404 on this endpoint as "no session." Also noteworthy: this endpoint does not implement v3.0 and silently falls back to v2.0.

### `GET /api/customer/me/restaurant/{restaurant_id}/recently-ordered` — recent orders at this restaurant — **[OBSERVED]** (v5.0)

```
GET /api/customer/me/restaurant/35/recently-ordered
    ?requested_time=202610161200   // optional, YYYYMMDDHHMM
    &cn_channel=cn_website          // optional; free-form attribution tag, see UNKNOWNS #4
    &is_catering=true               // optional
```

Returns the current user's recent items at that restaurant for the "Order again" row.

### `GET /api/customer/me/orders` — authed order history — **[VERIFIED by replay]**

**DRF-paginated** (indicates a newer FastAPI/DRF service, not the Bottle layer):

```http
GET /api/customer/me/orders
Cookie: session=<authed>
```

Response `200`:

```json
{ "count": 0, "next": null, "previous": null, "results": [],
  "warnings": ["Reverting to default API version: 2.0"], "version": "2.0" }
```

### `GET /api/customer/me/rewards` — authed rewards balance — **[VERIFIED by replay]**

```json
{ "rewards": [], "warnings": ["Reverting to default API version: 2.0"], "version": "2.0" }
```

### `PUT /api/customer/me/billing-card` — add card — **[VERIFIED by replay (schema walk)]**

```http
PUT /api/customer/me/billing-card
Cookie: session=<authed>

{
  "is_optout": false,
  "address":   "<string>",
  "cvv":       "<string>",
  "exp_month": <integer>,       // numeric MONTH, not "MM/YY"
  "exp_year":  <integer>,       // numeric YEAR
  "number":    "<string>",      // card PAN OR Stripe payment-method id — pending binary check
  "type":      "<string>"       // e.g. "visa", "mastercard" (enum not yet leaked)
}
```

Verified required set via progressive validator walk: `address, cvv, exp_month, exp_year, number, type`, each on top of the cross-cutting `is_optout`.

A sibling `POST /api/customer/me/billing-card` also preflights 200 and returns a schema error (as opposed to 405) — probably an alias.

The field names are **not** Stripe-shaped (`token`, `nonce`, `payment_method`); they look like **raw card details**. One of three things is true:
1. The server accepts raw card fields and tokenizes server-side (PCI-SAQ-D posture),
2. The field `number` actually carries the Stripe `pm_...` id with the other fields filled for display, or
3. The old Bottle endpoint predates Stripe Elements and the real card flow runs through a parallel newer endpoint.

The Partner API documentation (same company) says payment nonces are Stripe `pm_...` strings. Likely answer: the `number` field is **repurposed** to accept a Stripe PaymentMethod id. Confirm this during a real card-add replay.

### `DELETE /api/customer/me/billing-card/{card_id}` — remove card — **[OBSERVED (`DELETE /customer/me/billing-card` with no id → 500)]**

### `PUT /api/customer/me/favorites` — add favorite — **[VERIFIED by replay (schema walk)]**

```http
PUT /api/customer/me/favorites
Cookie: session=<authed>

{
  "is_optout":      false,
  "favorited_id":   "35",
  "favorited_type": "restaurant"   // enum: ONLY "restaurant" allowed (confirmed by 10201 error leak)
}
```

A sibling `DELETE /api/customer/me/favorites` with the same body shape also preflights and returns a schema validation path (not 405). Pair-use for add/remove.

### `POST /api/customer/me/membership` — enroll in a restaurant's membership — **[VERIFIED by replay (schema walk)]**

```http
POST /api/customer/me/membership
Cookie: session=<authed>

{
  "is_optout":          false,
  "payment_method_id":  "<string>",   // Stripe pm_... (uses the restaurant's `membership.processor_key`)
  "plan_id":            "<string>",
  "restaurant_id":      "<string>"
}
```

Verified required set: `payment_method_id, plan_id, restaurant_id` on top of `is_optout`. The restaurant's `membership.plans[]` lists available `plan_id` values; `membership.is_enabled: true` gates whether this endpoint accepts.

### `PUT /api/customer/{id}/rewards-consent` — opt in/out of per-restaurant rewards — **[OBSERVED (bundle literal, exact method confirmed)]**

```http
PUT /api/customer/{id}/rewards-consent
{ "restaurant_id": "35", "opted_in": true }
```

### Paths that preflight 200 but return 404 to the real request

Enumerated and confirmed non-existent despite CORS OPTIONS returning 200 (the `/customer/*` namespace is a CORS wildcard):

- `/customer/me/addresses` (plural)
- `/customer/me/billing-cards` (plural)
- `/customer/me/memberships` (plural)
- `/customer/me/credit`
- `/customer/me/account`
- `/customer/me/preferences`
- `/customer/me/notifications`

Address management is likely handled through `PUT /customer/me/addresses` with a specific body shape, OR through the `delivery.addresses` array on the Customer object (updated via `PUT /customer/{id}`). Not confirmed in this capture.

A restaurant's membership capability is announced on `GET /api/restaurant/{id}.membership` — if `is_enabled: true` the restaurant has one or more plans configurable through its Stripe account (`membership.processor_key`).

---

## 6. Order lifecycle

**Cart is client-side.** The SPA builds, mutates, and persists the cart entirely in `sessionStorage`. No cart XHR fires until the user hits Checkout; the first server interaction is `POST /api/order/validate` to quote the cart (same semantic as the Partner API's `POST /v1/quotes`). This is the single most important architectural fact in the private API.

### `POST /api/order/validate` — quote the cart — **[VERIFIED by replay with real $25.27 delivery quote]**

The authoritative body shape — reconstructed from the SPA bundle's `v(e, t)` order-body builder AND verified end-to-end against the live API.

```http
POST /api/order/validate
Accept: application/json version=3.0;
Content-Type: application/json; charset=UTF-8
X-CN-App-Info: Marketplace-Web/5.211.0
Cookie: session=<authed>

{
  "fulfill_method": "delivery",            // enum: pickup | delivery | curbside | dine_in
  "is_catering":    false,
  "items":          [ <see item shape below> ],
  "special_instructions": null,
  "tip":            null,                   // legacy top-level tip (null or number)
  "promo_code":     null,                   // null or a non-empty code string
  "restaurant_id":  "35",                   // location id as string
  "when":           "202610161900",         // YYYYMMDDHHMM — "ASAP" rejected (12004)
  "menu_id":        "121704_202610151951",
  "meta":           { "channel": null },    // null, or {cn_channel, cn_channel_xid} when the visit carried ?cn_channel=
  "tips": {                                 // newer split-tip object
    "managed_delivery_tip": null,
    "restaurant_tip":       null
  },
  "include_single_use_items": false,
  "customer": null                          // null for pickup; object for delivery (below)
}
```

**For delivery**, `customer` is NOT null — it carries the delivery address nested:

```json
"customer": {
  "email":      "<from session or guest input>",
  "first_name": "...", "last_name": "...",
  "phone":      "...",
  "id":          69538988,                     // null for guest, user id for authed
  "delivery": {
    "address": {
      "is_google_place":  true,                 // marker set by the SPA on Google-picked addresses
      "street_address1":  "100 College Ave",
      "street_address2":  "",
      "city":    "Kentfield",
      "state":   "CA",
      "zip":     "94904",
      "latitude":  37.9525,
      "longitude": -122.5500,
      "country":        "USA",
      "country_alpha2": "US",
      "geo":            "37.9525,-122.55",
      "formatted_address": "100 College Ave, Kentfield CA 94904"
    }
  }
}
```

**For curbside**, `customer.curbside = { vehicle: {...} }` and `customer.delivery = null`.
**For dine_in**, `customer.dine_in = { table_name: "..." }` and both delivery/curbside = null.

**Yelp channel override**: when `X-CN-App-Info: Yelp-Web/*`, the body builder additionally sets `meta.marketplace = { id: "1", x_id: <opportunity_token> }`. Marketplace-Web uses `id: "2"`.

#### Item shape — EXACTLY these six fields

The SPA bundle's `w(e)` cart-item builder emits exactly:

```json
{
  "id":                   "26801454_28687426",   // leaf item id from menu
  "quantity":             1,
  "recipient":            null,                   // always null; split-order recipients not wired
  "special_instructions": null,
  "client_id":            "1792108800000000",     // stringified Date.now() * 1000 — microsecond-ish ts
  "modifier_categories":  []                      // keep only categories that have selected modifiers
}
```

**Extra fields crash the server with 500** (`"Sorry, an error has occurred."`). Do NOT include `item_id`, `name`, `price`, `cost`, `size_id`, or `meta` on cart items. The server looks everything else up from the menu using the leaf `id`.

If the item has required `modifier_categories` on the menu, pass them here with the diner's selections. If all are optional (or none), pass `[]`. Error `34005 "Modifier selections invalid for item"` on 400 means a required category wasn't satisfied.

#### Full response (empty-cart pickup, replay-captured earlier)

Response `200` (even on business-rule failure the status is 200; the server embeds the failure in the top-level `errors` array). Full captured example on an empty-cart pickup quote:

```json
{
  "area": null,
  "available_discounts": [],
  "customer": null,
  "delivery_instructions": null,
  "fulfill_method": "pickup",
  "is_catering": false,
  "include_single_use_items": false,
  "items": [],
  "managed_delivery_id": null,
  "menu_id": "121704_202610151951",
  "meta": { "client_type": "web2", "chownow_app_info": null },
  "order_ahead": true,
  "promo_code": null,
  "restaurant_id": "35",
  "special_instructions": "",
  "tip": 0,
  "when": "202610161900",

  "delivery_fee":           null,
  "direct_diner_fee":       null,
  "marketplace_diner_fee":  null,
  "service_fee":            0,
  "misc_fee": { "label": "Gratuity", "amount": 0 },
  "gratuity":               0,
  "order_restaurant_savings":  null,
  "diner_restaurant_savings":  null,

  "sales_tax":    0.00,
  "item_total":   0.00,
  "subtotal":     0.00,
  "total":        0.00,
  "total_due":    0.00,

  "credits":   [],
  "discounts": [],

  "errors": [
    { "code": "32003", "message": "Add $0.50 to meet the $0.50 pickup minimum",
      "field": null, "value": null }
  ],
  "warnings": [],

  "taxes": {
    "delivery_fee_tax":          null,
    "direct_diner_fee_tax":      null,
    "marketplace_diner_fee_tax": null,
    "menu_items_tax":            0,
    "misc_fee_tax":              null,
    "total":                     0.00
  },
  "version": "3.0"
}
```

Notes:
- **The response is the full order object with totals computed**, not just a subset. The client renders directly off it.
- `meta.client_type: "web2"` is **server-assigned** — the Bottle layer tags the request based on `X-CN-App-Info` (anonymous call → `"web2"` with `chownow_app_info: null`; authed call → `"web2"` with the X-CN-App-Info echoed).
- Business-rule errors (minimum order, closed restaurant, etc.) ride in `errors[]` on a `200` response. HTTP `400` is reserved for schema violations.
- `total_due` is what the client echoes into `POST /order` for consistency check. (The field is `total_due`, not `validated_total` as the Partner API uses.)

`fulfill_method` enum (observed): `pickup`, `delivery`. `curbside` and `dine_in` are per-restaurant capabilities (`fulfillment.curbside`/`fulfillment.dine_in` on the restaurant payload) — likely accepted here when enabled; not yet enum-leaked.

### `POST /api/order` — place the order — **[VERIFIED by replay]**

Same body shape as `/order/validate` — the server shares the schema. Authenticated session required (anonymous POST → 401 at the auth layer AFTER passing schema validation).

The body additions on place vs. validate: payment-and-identity. The field names (from the SPA bundle, pending final replay):

- `payment_type`: `credit_card | apple_pay | google_pay | no_payment` (enum pending verification)
- `payment`: `{ "nonce": "pm_..." }` — Stripe PaymentMethod id (new card tokenized client-side)
- `payment_card`: `{ "id": "<saved billing-card id>" }` — alternative to `payment.nonce`
- `customer`: `{first_name, last_name, email, phone}` — required on guest checkout
- `sift_session_id`: Sift Science device id (string, from the Sift JS SDK)
- `idempotency_key`: UUID v4; the main.js bundle shows `idempotency_key` in body (NOT as a header on this surface, unlike the Partner API)

Aliases: `POST /api/order/submit` and `POST /api/order/create` both exist. `POST /api/order` is canonical.

### `POST /api/order` or `POST /api/order/submit` — place the order — **[OBSERVED via OPTIONS 200]**

Both paths preflight 200. The naming suggests `POST /api/order` is "create a new order resource" and `POST /api/order/submit` is a legacy/explicit alias. The body is the validate body **plus**:

```json
{
  "payment_type": "credit_card",                 // or "apple_pay", "google_pay", "no_payment"
  "payment": { "nonce": "pm_..." },              // Stripe PaymentMethod id (or Apple/Google Pay token)
  "payment_card": { "id": "..." },               // for a saved billing-card
  "validated_total": "34.65",
  "customer": {                                  // required when guest-checkout
    "first_name": "...", "last_name": "...",
    "email": "...", "phone": "..."
  },
  "sift_session_id": "...",                      // Sift Science device/session for fraud
  "idempotency_key": "..."                       // UUID v4; may be a header on this surface
}
```

Response `201`:

```json
{ "order": { "id": "...", "status": "received", "fulfillment_time": "...", ... }, "version": "3.0" }
```

See [`flows/order.md`](../flows/order.md) for the full state machine.

### `GET /api/order/{order_id}` — order detail — **[OBSERVED via replay (anonymous → 404)]**
### `GET /api/history/{order_id}` — history detail — **[INFERRED]**

Two paths pointing at the same resource. `/api/history/` is the older alias.

### `POST /api/order/{order_id}/reorder` — repeat a prior order — **[INFERRED]**

Returns a cart-ready payload the client drops into local cart state.

### `POST /api/order/{order_id}/adjust` — edit an in-progress order — **[INFERRED]**

Likely allows the diner to tweak items pre-acceptance by the restaurant.

### `POST /api/order/create` — alternate create path — **[OBSERVED via OPTIONS 200]**

Preflight 200 alongside `/order` and `/order/submit`. Likely a legacy third create-ish path.

---

## 7. Other

### `GET /api/` — root — **[VERIFIED by replay]** → `501 Not Implemented`
### `GET /api/customer` — collection root — **[VERIFIED by replay]** → `500 Generic exception` (exists, wrong method; POST = create account)
### `POST /api/customer/password-reset` — alt alias — not probed

---

## Appendix A — Marketplace meta injection

When `X-CN-App-Info` is `Marketplace-Web/*`, the SPA's request builder transforms the body on writes:

```js
const t = c?.marketplaceObnBypass && e?.cn_channel && a.nI.includes(e.cn_channel)
          ? {}
          : {marketplace: {id: "2", x_id: null}};
m = {...m, meta: {...p, ...t, channel: e}};
```

- `marketplace.id: "2"` identifies the ChowNow Marketplace.
- `x_id` is reserved for cross-marketplace routing and is `null` today.
- The `marketplaceObnBypass` flag + `meta.channel.cn_channel ∈ a.nI` suppresses this injection. `a.nI` (module `97730`) is `["google_cn_marketplace"]`, its only entry. (An earlier version of this appendix listed a 21-code array here; that array is the order-validation error list, see [`ERRORS.md`](../ERRORS.md#31xxx37xxx--993--order-business-rules).)
- `meta.channel` itself is `{cn_channel, cn_channel_xid}` or `null`. See [UNKNOWNS #4](../UNKNOWNS.md#4-the-cn_channel-parameter-closed-2026-10-16).

A replay client that always sends `meta.marketplace: {id: "2", x_id: null}` on write bodies when posing as Marketplace-Web will match production.

## Appendix B — Image CDN

Images come off `menuimages.chownowcdn.com` with a Cloudflare Image Resizing query API:

```
https://menuimages.chownowcdn.com/image-resizing?image=<uuid>.jpg
  &left=0&top=0&right=0&bottom=52
  &width=1400&quality=85&fit=contain&format=webp
```

Query params:
- `image` — the asset UUID (returned on each item/restaurant as `media.cover_image_url` with `format=webp` and sizing already applied).
- `left`/`top`/`right`/`bottom` — crop insets in pixels.
- `width` — pixel width target.
- `quality` — JPEG/WebP quality 1-100.
- `fit` — `contain`, `cover`, etc.
- `format` — `webp`, `jpeg`, `png`.

These URLs are **public** — no signing, no auth.
