# ChowNow Partner API — `openapi.chownow.com/v1`

> **Captured:** 2026-10-15 · **Source:** `developer.chownow.com` public docs · **Confidence:** `[OBSERVED]` from vendor documentation. Flip to `[VERIFIED by replay]` once a sandbox token is obtained and endpoints are replayed with `httpx`.

The Partner API is the **documented first-party surface** that ChowNow exposes to approved integrators. It is **not** the same as the private web/mobile ordering surface — it is a server-to-server OAuth2 client-credentials API designed for third parties (POS, loyalty, aggregators) to discover restaurants, read menus, quote carts, and place orders on behalf of their own users. There is no end-user account, no cart session, no favorites.

Document the private web/mobile surface separately in [`marketplace.md`](./marketplace.md), [`menu.md`](./menu.md), [`cart.md`](./cart.md), [`checkout.md`](./checkout.md), [`account.md`](./account.md).

---

## Hosts

| Env        | API base                                   | Token endpoint                                             |
| ---------- | ------------------------------------------ | ---------------------------------------------------------- |
| Production | `https://openapi.chownow.com`              | `https://auth.developer.chownow.com/oauth2/token`          |
| Sandbox    | `https://sandbox.openapi.chownow.com`      | `https://auth.sandbox.developer.chownow.com/oauth2/token`  |

Sandbox and production call the same codebase against the same data today — the only difference is which credentials you were issued. A sandbox token will not authenticate against production and vice versa. The `auth.*.developer.chownow.com` host pattern is consistent with WorkOS AuthKit; worth probing OIDC discovery (`/.well-known/openid-configuration`) during replay.

Root `GET /` returns 404; `GET /v1/orders` returns `405 Method Not Allowed`. The server rejects unversioned paths and unlisted methods before auth, which is consistent with an API gateway in front.

---

## Authentication

OAuth2 **client-credentials** grant, Bearer JWT. Machine-to-machine; no end-user is involved.

### OIDC discovery — **[VERIFIED by replay 2026-10-15]**

Both `auth.developer.chownow.com` and `auth.sandbox.developer.chownow.com` publish full OpenID Connect discovery documents at:

```
GET https://auth.developer.chownow.com/.well-known/openid-configuration     -> 200
GET https://auth.developer.chownow.com/.well-known/oauth-authorization-server -> 200
GET https://auth.developer.chownow.com/oauth2/jwks                           -> 200 (1475 B)
```

Production discovery (sandbox discovery is identical except for host swaps):

```json
{
  "issuer": "https://auth.developer.chownow.com",
  "authorization_endpoint":         "https://auth.developer.chownow.com/oauth2/authorize",
  "device_authorization_endpoint":  "https://auth.developer.chownow.com/oauth2/device_authorization",
  "token_endpoint":                 "https://auth.developer.chownow.com/oauth2/token",
  "userinfo_endpoint":              "https://auth.developer.chownow.com/oauth2/userinfo",
  "introspection_endpoint":         "https://auth.developer.chownow.com/oauth2/introspection",
  "jwks_uri":                       "https://auth.developer.chownow.com/oauth2/jwks",
  "grant_types_supported": [
    "authorization_code",
    "client_credentials",
    "refresh_token",
    "urn:ietf:params:oauth:grant-type:device_code"
  ],
  "response_types_supported": ["code"],
  "scopes_supported": ["email", "offline_access", "openid", "profile"],
  "id_token_signing_alg_values_supported": ["RS256"],
  "token_endpoint_auth_methods_supported": ["none", "client_secret_basic", "client_secret_post"],
  "subject_types_supported": ["public"]
}
```

Key takeaways beyond the documented client-credentials path:

- **Four grant types** are supported, not just `client_credentials`:
  - `authorization_code` — interactive OAuth2 flow with PKCE presumably; probably powers the restaurant admin portal's own sign-in.
  - `refresh_token` — note that this is listed on the IdP; the client-credentials flow doesn't normally use refresh tokens, so a Partner API client that uses the interactive flows gets refresh tokens.
  - `urn:ietf:params:oauth:grant-type:device_code` — RFC 8628 Device Authorization Grant. Suggests a CLI or TV/IoT client flow may be viable for Partner integrators.
- **IdP scopes are OIDC-standard** (`openid`, `email`, `profile`, `offline_access`) — these are the IdP's own scopes, distinct from the API scopes documented below (`restaurants:read`, etc.) which are app-level.
- **`id_token_signing_alg: RS256`** — JWKS at `/oauth2/jwks` publishes RSA public keys.
- **`token_endpoint_auth_methods`** includes `none` — public clients (device flow, native app) are supported.
- Shape matches **Ory Hydra** or a close relative, not WorkOS AuthKit as initially guessed.

### Mint a token

```
POST /oauth2/token
Host: auth.developer.chownow.com         # or auth.sandbox.developer.chownow.com
Content-Type: application/x-www-form-urlencoded

grant_type=client_credentials
&client_id=<CLIENT_ID>
&client_secret=<CLIENT_SECRET>
&scope=<optional space-separated scope list>
```

Response:

```json
{
  "access_token": "eyJ...<JWT>...",
  "token_type": "Bearer",
  "expires_in": 3600,
  "scope": "restaurants:read catalog:read orders:read orders:write"
}
```

Cache the token until near-expiry. Do not mint one per request.

### Call the API

```
Authorization: Bearer <access_token>
```

### Scopes

| Scope              | Grants                                                      |
| ------------------ | ----------------------------------------------------------- |
| `restaurants:read` | Discover restaurants and read restaurant detail             |
| `catalog:read`     | Read a restaurant's menu and pre-checkout availability      |
| `orders:read`      | Read order detail and status                                |
| `orders:write`     | Create price quotes and place orders                        |

Scopes are **assigned at the org level**, not per application (per-application scoping is on the roadmap). A reduced scope grant is reflected in newly minted tokens but **already-issued tokens keep their old scopes until they expire** (up to one hour).

### Token-endpoint errors

- `invalid_client` — bad `client_id` / `client_secret` or revoked secret.
- `invalid_scope` — requested a scope the application does not hold. Fix: omit the `scope` parameter.

### API-call auth errors

- `401 Unauthorized` — missing/malformed/expired token. Mint a new one, retry.
- `403 Forbidden` — valid token, missing scope for the endpoint.

---

## Rate limits

**600 requests per 60 seconds per client organization**, same cap in sandbox and production. Respect `Retry-After` on `429`.

---

## Error model — RFC 9457 Problem Details

```json
{
  "type":   "https://developer.chownow.com/errors/<code>",
  "title":  "Human-readable summary",
  "status": 400,
  "code":   "ITEM_UNAVAILABLE",
  "detail": "Human-readable detail",
  "errors": [
    { "pointer": "/items/0/id", "message": "..." }
  ]
}
```

Branch on `code`, not `title`.

Common codes:

| HTTP | `code`                | Meaning / handling                                                     |
| ---- | --------------------- | ---------------------------------------------------------------------- |
| 400  | `ITEM_UNAVAILABLE`    | An item sold out between quote and place. Re-fetch menu, re-quote.     |
| 400  | `RESTAURANT_CLOSED`   | Fulfillment time not valid for the restaurant.                         |
| 400  | `BELOW_MINIMUM_ORDER` | Subtotal below the restaurant's minimum.                               |
| 400  | `MENU_EXPIRED`        | `menu_id` no longer current. Re-fetch menu, re-quote with new id.      |
| 400  | `TOTAL_MISMATCH`      | `validated_total` differs from the server's computed total. Re-quote.  |
| 401  | —                     | See auth error table above.                                            |
| 402  | —                     | Payment declined. **Retry with a NEW `Idempotency-Key`.**              |
| 403  | —                     | Scope missing.                                                         |
| 429  | —                     | Rate-limited. Honor `Retry-After`.                                     |
| 501  | —                     | Endpoint not yet implemented (e.g., customer create, cancel, refund).  |

---

## Idempotency

`POST /v1/orders` requires a client-supplied `Idempotency-Key` header. Same key + same body → same order returned (not a new one).

- A `402 payment declined` **uses up the key**. To retry the order, you must mint a new `Idempotency-Key`.
- A `400 validation failure` **does not use up the key**. Fix the body and retry with the same key.

`external_id` is your own reference string that gets stored on the order. It is **not** the same thing as the idempotency key.

---

## Endpoints (`[OBSERVED]` from docs; schemas to be refined once replay succeeds)

Confidence tag applies to every row until a working token lets me pull the live OpenAPI (if the portal publishes one) or replay against sandbox.

### Restaurants

#### `GET /v1/restaurants` — discover restaurants

- **Auth:** `restaurants:read`
- **Query params (inferred):** `location`, `lat`, `lng`, `radius`, `cuisine`, `page`, `page_size` — to be confirmed.
- **Returns:** paginated list of restaurant summaries.

#### `GET /v1/restaurants/{restaurant_id}` — restaurant detail

- **Auth:** `restaurants:read`
- **Path params:** `restaurant_id` (int).
- **Returns:** hours, address, fulfillment capabilities (pickup/delivery), fees schedule, minimums.

#### `GET /v1/restaurants/{restaurant_id}/menu` — menu + availability

- **Auth:** `catalog:read`
- **Path params:** `restaurant_id`.
- **Returns:** `menu_id`, categories, items, modifiers/options, prices (minor units), sold-out flags.

The `menu_id` returned here must be passed verbatim into the quote and the order. The server treats menu versions as immutable; a changed menu returns a new `menu_id` and old ones expire (`MENU_EXPIRED`).

### Orders

#### `POST /v1/quotes` — price a cart

- **Auth:** `orders:write`
- **Body:**

```json
{
  "restaurant_id": 32,
  "menu_id": "<from GET menu>",
  "fulfill_method": "delivery",      // or "pickup"
  "fulfill_time": "ASAP",             // or ISO-8601 timestamp
  "items": [
    {
      "id": "<menu item id>",
      "quantity": 1,
      "modifiers": [{ "id": "<option id>", "quantity": 1 }]
    }
  ],
  "customer": {
    "address": {
      "line1": "...", "line2": "", "city": "...", "state": "CA", "zip": "..."
    }
  },
  "tips": { "amount": 300 }           // optional, minor units
}
```

- **Returns:** `totals` object with `subtotal`, `tax`, `fees`, `tip`, `total`, `total_due` (all integer minor units + currency). Store `menu_id` and `total` for the subsequent place.

#### `POST /v1/orders` — place the order

- **Auth:** `orders:write`
- **Required header:** `Idempotency-Key: <unique uuid v4 per attempt>`
- **Body (merged superset of quote):**

```json
{
  "restaurant_id": 32,
  "menu_id": "<same>",
  "fulfill_method": "delivery",
  "fulfill_time": "ASAP",
  "items": [ ... ],
  "customer": {
    "first_name": "...",
    "last_name": "...",
    "email": "...",
    "phone": "...",
    "address": { ... }
  },
  "payment": { "token": "pm_..." },   // Stripe PaymentMethod id, obtained client-side with ChowNow's publishable key
  "validated_total": 3465,            // minor units; must match quote.total
  "tips": { "amount": 300 },
  "external_id": "partner-order-123"  // your reference
}
```

- **Returns:** `201 Created` + order object including `id`, `status`.

Payments are **on-us in v1** — ChowNow holds the PSP relationship. The `pm_...` token prefix is Stripe. Tokens are environment-matched: use ChowNow's Stripe **publishable key** that corresponds to your API environment to tokenize cards client-side, then pass the resulting PaymentMethod id here.

#### `GET /v1/orders/{order_id}` — order detail

- **Auth:** `orders:read`
- **Returns:** full order (items, totals, customer, fulfill_method, timestamps, ETAs).

#### `GET /v1/orders/{order_id}/status` — poll status

- **Auth:** `orders:read`
- **Returns:**

```json
{
  "status": "received | accepted | rejected | cancelled | refunded",
  "managed_delivery": {
    "status": "<courier state>"    // null for pickup orders
  }
}
```

Poll this endpoint rather than `GET /v1/orders/{id}` while watching an order.

### Not yet implemented (`501`)

Documented but currently returns `501 Not Implemented`:

- Customer create / lookup (there is no customer object persisted on the Partner API side today).
- Order cancellation.
- Refunds.

Any client flow needing these must fall back to out-of-band handling.

---

## Open questions for replay phase

Tracked in [`../UNKNOWNS.md`](../UNKNOWNS.md):

1. OIDC discovery doc at `auth.developer.chownow.com/.well-known/openid-configuration` — likely WorkOS AuthKit. Confirm issuer, JWKS, and whether token refresh is supported (it should not be, for client_credentials).
2. Exact query-param shape of `GET /v1/restaurants` discovery.
3. Does the Partner API publish an OpenAPI spec at a well-known path (e.g., `/openapi.json`, `/v1/openapi.json`, `/docs/openapi`)? Try these during replay.
4. Does `catalog:read` on `/menu` include the brand-site private surface's modifier price-adjustment structures (`price_adjustment` vs flat `price`)?
5. Managed delivery courier states enum — undocumented.
6. Webhooks — are there any? The docs show only polling.
