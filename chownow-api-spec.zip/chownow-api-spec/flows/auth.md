# Flow: auth — signin, signup, SSO, magic-link, forgot/reset

All paths under `/api/customer/`. Session is a cookie set by the server on success. Request/response bodies here are **inferred** — see [`UNKNOWNS.md`](../UNKNOWNS.md) #1 for the gap.

## The Continue button pattern

The modal has one visible input: email. The user types their address and hits Continue. The SPA then:

1. Calls `POST /api/customer/exists` with just the email.
2. Based on the response, routes to one of two flows:
   - Account exists → render password step. On submit → `POST /api/customer/signin`.
   - Account does not exist → render full signup form (first name, last name, phone, password, marketing consent). On submit → `POST /api/customer/signup`.
3. Independently, the modal always offers:
   - **Continue with Google** — opens Google Identity Services; on completion → `POST /api/customer/google` with the ID token.
   - **Continue with Apple** — Apple ID; on completion → `POST /api/customer/apple`.
   - **Magic link** — some brands only; on request → `POST /api/customer/magic-link` with just the email.

## Email + password signin

```http
POST /api/customer/signin
Accept: application/json version=3.0;
Content-Type: application/json; charset=UTF-8
X-CN-App-Info: Marketplace-Web/5.211.0
Origin: https://www.chownow.com

{ "email": "user@example.com", "password": "..." }
```

Expected `200`:
- `Set-Cookie: <session cookie>; HttpOnly; Secure; SameSite=Lax`
- Body: the Customer object (same shape as `GET /api/customer/me`).

Expected `401` on wrong password; expected `429` on too-many-attempts (lockout TTL unknown).

**Do not use `/api/customer/login`.** CORS preflight returns `403` on that alias — it's legacy and does not allow cross-origin writes from `www.chownow.com`. Use `/signin`.

## Signup

```http
POST /api/customer/signup
Content-Type: application/json; charset=UTF-8

{
  "email": "user@example.com",
  "password": "...",
  "first_name": "...",
  "last_name": "...",
  "phone": "...",
  "marketing_consent": false
}
```

An alternate collection-root alias `POST /api/customer` exists and preflights 200. Prefer `/signup`.

## Google SSO

The modal loads `https://accounts.google.com/gsi/iframe/select` with the Google client-id (bundled in the SPA — not shown here). On successful user consent, Google returns a signed ID token to the page. The SPA posts it to:

```http
POST /api/customer/google
Content-Type: application/json; charset=UTF-8

{ "id_token": "eyJhbGciOi...", "nonce": "<randomly generated>" }
```

ChowNow verifies the token against Google's JWKS, matches on `email`/`sub`, and establishes a session.

## Apple SSO

```http
POST /api/customer/apple
Content-Type: application/json; charset=UTF-8

{ "id_token": "eyJhbGciOi...",
  "authorization_code": "...",
  "name": {"first":"...","last":"..."}   /* only on first-ever sign in */ }
```

Apple only returns the user's name on their very first authorization; the client must forward it to ChowNow or it's lost.

## Magic link

```http
POST /api/customer/magic-link
Content-Type: application/json; charset=UTF-8

{ "email": "user@example.com",
  "redirect": "https://www.chownow.com/order/32/locations/35" }
```

Expected `202 Accepted` with no body. The user receives an email with a tokenized link; clicking it hits a `/magic-link/<token>` web endpoint that calls back into the private API to establish the session. The exact server-side verification path was not captured.

## Forgot password

```http
POST /api/customer/forgot-password
Content-Type: application/json; charset=UTF-8

{ "email": "user@example.com" }
```

Email with a reset token is sent. User follows link to a `/reset-password?token=...` page, enters a new password, and the SPA calls:

```http
POST /api/customer/reset-password
Content-Type: application/json; charset=UTF-8

{ "token": "<from email>", "password": "<new>" }
```

## Change password (authed)

```http
PUT /api/customer/password
Content-Type: application/json; charset=UTF-8
Cookie: <session>

{ "old_password": "...", "new_password": "..." }
```

## Session refresh

```http
POST /api/customer/session
Cookie: <session>
```

Likely a no-op heartbeat that extends the session cookie's TTL. Not observed in traffic but preflights 200.

## Logout

```http
POST /api/customer/logout
Cookie: <session>
```

Server clears the cookie; the SPA additionally clears all `chownow:*` keys from `sessionStorage` and `localStorage`.

## Guest flow

Guest checkout — no account at all — is handled by inlining a `customer: {first_name, last_name, email, phone}` block into the `/api/order` body. See [`flows/order.md`](./order.md). The SPA guards this with the restaurant's `allows_no_payment_checkout` flag and a `guest` string literal that gates the UI switch.

## Session cookie attributes

The exact cookie name was not captured in this session. Expected: `HttpOnly`, `Secure`, `SameSite=Lax`, domain `.chownow.com`. The `credentials: "include"` on every XHR requires at minimum `SameSite=None; Secure` for cross-origin from `direct.chownow.com` and `www.chownow.com` — unless the cookie is pinned to `.chownow.com` which covers both. Confirm with a real signin capture.
