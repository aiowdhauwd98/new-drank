# Flow: order — cart → quote → place → status

The one real server interaction the diner has. Everything prior (menu rendering, cart edits, modifier picks) is client-side.

## Fulfillment choices (from `GET /api/restaurant/{id}`)

| Pickup available?   | `fulfillment.pickup != null && fulfillment.pickup.is_available_now`     |
| ------------------- | ----------------------------------------------------------------------- |
| Delivery available? | `fulfillment.delivery != null && fulfillment.delivery.is_available_now` |
| Scheduled OK?       | `order_ahead.is_pickup_ahead_available / is_delivery_ahead_available`   |
| Delivery address OK? | Need to validate against the delivery range (not a documented endpoint; client-side check uses `delivery_ranges[].max/min_order_amt` after the server quote returns) |

## Step 1 — Quote the cart (`POST /api/order/validate`)

```http
POST /api/order/validate
Accept: application/json version=3.0;
Content-Type: application/json; charset=UTF-8
X-CN-App-Info: Marketplace-Web/5.211.0
Origin: https://www.chownow.com
Cookie: <session cookie, if authed>

{
  "restaurant_id": "35",
  "menu_id": "121704_202610151951",
  "fulfillment": {
    "method": "delivery",
    "requested_fulfillment": "ASAP"
  },
  "address": {
    "street_address1": "123 Example St",
    "street_address2": "",
    "city": "Kentfield", "state": "CA", "zip": "94904",
    "latitude": 37.9523048, "longitude": -122.550087
  },
  "cartitems": [
    { "item_id": "3111147_3723854", "quantity": 1,
      "modifiers": [], "special_instructions": "" }
  ],
  "promo_code": null,
  "is_cart_update": false,          /* true while editing cart; false when at checkout */
  "tip": { "amount": null },
  "payment_type": null,
  "rewards": { "rewardsOptIn": null },
  "meta": { "marketplace": {"id": "2", "x_id": null}, "channel": null }
}
```

Expected `200`:

```json
{
  "validated_total": "34.65",
  "subtotal": "28.00",
  "tax": "2.31",
  "fees": { "delivery": "4.34" },
  "tip": "0.00",
  "payment_required": true,
  "fulfillment_time": "202610161200",
  "fulfillment_times": ["202610161200", "202610161215", ...],
  "fulfillmentEta": { "start": "...", "end": "..." },
  "available_discounts": [], "redeemed_discounts": [],
  "has_auto_promo": true,
  "errors": [], "warnings": [],
  "version": "3.0"
}
```

Error path (`200` with non-empty `errors`, or `400` with the shared `{errors:[{code,message,reason}]}`):

| Likely `code`      | Trigger                                             | Recovery                                                                 |
| ------------------ | --------------------------------------------------- | ------------------------------------------------------------------------ |
| `MENU_EXPIRED`     | Server has minted a new `menu_id` since you fetched | GET `/restaurant/{id}/menu`, update cart ids if any, re-validate         |
| `ITEM_UNAVAILABLE` | An item or modifier was marked sold-out             | Remove the offending `cartitems` entry (`errors[].pointer` names it)     |
| `RESTAURANT_CLOSED`| `requested_fulfillment` not valid for current hours | Pick a time from `fulfillment_times[]` returned by a prior call          |
| `BELOW_MINIMUM_ORDER` | Subtotal under `delivery.min_order_amt`           | Add more items                                                            |
| `OUT_OF_DELIVERY_RANGE` | Address outside `delivery_ranges`              | Fall back to pickup or ask the user to pick a different address          |

The private API's error codes are not fully documented; the Partner API's codes are a strong starting point for the enum since they share a backend. See [`endpoints/partner-api.md`](../endpoints/partner-api.md).

## Step 2 — Place the order (`POST /api/order`)

Three paths preflight 200: `/api/order`, `/api/order/submit`, `/api/order/create`. Use `/api/order`.

Body is the validate body **plus** payment-and-identity:

```http
POST /api/order
...same headers as above...

{
  ...same as validate...,
  "validated_total": "34.65",            /* echo from Step 1 */
  "payment_type": "credit_card",         /* or apple_pay, google_pay, no_payment */
  "payment": { "nonce": "pm_1QXXYZ..." },      /* Stripe PaymentMethod id */
  "payment_card": { "id": "<saved card id>" }, /* if using a saved card */
  "customer": {                                /* if guest-checkout */
    "first_name": "...", "last_name": "...",
    "email": "...@...",  "phone": "..."
  },
  "sift_session_id": "<Sift Science session>",
  "idempotency_key": "<uuid v4>"
}
```

Expected `201`:

```json
{ "order": { "id": "...", "status": "received", "fulfillment_time": "202610161200" },
  "version": "3.0" }
```

### Payment tokenization

The private API never sees card PANs. Three paths:

1. **New card** — tokenize client-side with Stripe Elements using the publishable key from `GET /api/web/manifest`; pass the resulting `pm_...` id as `payment.nonce`.
2. **Saved card** — pass `payment_card.id` referring to a previously added billing card (`POST /api/customer/{id}/billing-card`).
3. **Apple Pay / Google Pay** — use the Stripe Payment Request Button to collect the token, then post the Stripe `pm_...` id as `payment.nonce`. `payment_type` becomes `apple_pay` or `google_pay`. The Apple Pay merchant id is `merchant.com.stripe.chownow`.

### Idempotency

The Partner API requires a client-supplied `Idempotency-Key` header. On the private API the key name `idempotency_key` appears as a bundle string in the submit area but it is **not confirmed** whether it is a header or a body field. Treat as body for now; retry with a NEW uuid on `402` (payment declined) and reuse the same uuid on `400` (validation).

## Step 3 — Poll status (`GET /api/order/{id}`)

```
GET /api/order/{order_id}
Accept: application/json version=3.0;
X-CN-App-Info: Marketplace-Web/5.211.0
```

Returns the full order including `status` and (for delivery orders) `managed_delivery.status`.

Observed `status` enum (from Partner API docs, same backend):
- `received`   — restaurant has not yet acknowledged.
- `accepted`   — restaurant accepted.
- `rejected`   — restaurant rejected; refund flow kicks in.
- `cancelled`  — diner or restaurant cancelled.
- `refunded`   — refunded (customer service or partial).

`managed_delivery.status` courier enum is undocumented. See UNKNOWNS.md #8.

Polling cadence from the SPA: 10 seconds while on the status page, slowing to 60 seconds in the background. No websocket; no SSE.

## Step 4 — Reorder from history (`POST /api/order/{id}/reorder`)

Server returns a cart-ready payload (same shape as the client-side cart) the client drops into local state. Then re-run Steps 1–3.

## State diagram

```
       ┌─────────────┐
       │   building  │   (client-side cart)
       │     cart    │
       └──────┬──────┘
              │ user hits Checkout
              ▼
       ┌─────────────┐          ┌────────────────────┐
       │   quoted    │──────────│ errors[] non-empty │  →  fix cart, re-quote
       └──────┬──────┘          └────────────────────┘
              │ validated_total OK
              ▼
       ┌─────────────┐          ┌────────────────────┐
       │   placing   │──────────│ 402 declined       │  →  new nonce,
       └──────┬──────┘          │                    │     NEW idempotency_key
              │ 201             └────────────────────┘
              ▼
       ┌─────────────┐
       │  received   │
       └──────┬──────┘
              │
      ┌───────┴─────────────────────┐
      ▼                             ▼
┌──────────┐                 ┌──────────┐
│ accepted │ ──  delivery?   │ rejected │ ──  auto-refund
└────┬─────┘        │        └──────────┘
     │              ▼
     │        ┌──────────────────┐
     │        │ managed_delivery │  (pending → assigned → picked_up
     │        │     .status      │   → in_transit → delivered)
     │        └──────────────────┘
     ▼
┌──────────┐
│ delivered│ (terminal; order complete)
└──────────┘
```

## Guest vs authed

`allows_no_payment_checkout: false` + payment required = must have either a session or a guest `customer` block. The SPA's modal always offers "Continue as Guest" when the restaurant allows it (via a `guest` token in the bundle); the auth session is optional for most restaurants.
