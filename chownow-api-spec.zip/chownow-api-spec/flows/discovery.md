# Flow: discovery — city search → results → cuisine filter

End-to-end call sequence a client must make to reproduce the marketplace search page at `www.chownow.com/search?loc=<human address>`. All anonymous — no session required.

## Preconditions

- A human-readable address or city string the user typed (e.g. `"Los Angeles, CA"`).
- Google Maps JS SDK is used **client-side** to geocode that string into `(lat, lng)`. The private API never does this for you — it expects coordinates. A replay client has two choices:
  1. Call Google Geocoding directly with an API key you own, or
  2. Call `GET /api/restaurant` with the user's own stored `(lat, lng)` (the SPA caches the last-used address in `localStorage` under `chownow:diner:selected-address`).

## Step 1 — bootstrap config (optional, once per session)

```
GET https://api.chownow.com/api/web/manifest
Accept: application/json version=3.0;
X-CN-App-Info: Marketplace-Web/5.211.0
```

Response: the global config bundle with URLs, Stripe publishable key, support phone, etc. The server returns v2.0 regardless of the version you ask for.

## Step 2 — paginated discovery

```
GET https://api.chownow.com/api/restaurant
    ?pf=1
    &aggs=cuisines
    &u_lat=34.0549076
    &u_lon=-118.242643
    &limit=30
Accept: application/json version=3.0;
X-CN-App-Info: Marketplace-Web/5.211.0
```

Response: `{next, prev, limit, offset, total, aggregations.cuisines[], restaurants[], version}`.

- `total` is the full result count for the point (e.g. `439` for central LA).
- `aggregations.cuisines` is used by the client to render the cuisine filter sidebar — doc_count per cuisine.
- `restaurants[]` is page 0; follow `next` as-is for pages 1+.

## Step 3 — facet carousels (parallel with step 2)

```
GET https://api.chownow.com/api/restaurant/facets
    ?u_lat=34.0549076
    &u_lon=-118.242643
    &facets=is_favorite%2Cis_new%2Clow_cost_delivery
```

Response: `{facets: [{tag, name, restaurants[], total, next, ...}, ...]}` — one object per requested facet.

A client can also skip this call; the facets are UI candy, not required to render the list.

## Step 4 — cuisine filter / facet drill-in

To filter by `Mexican`:

```
GET https://api.chownow.com/api/restaurant?pf=1&u_lat=&u_lon=&limit=30&cuisine=Mexican
```

(The `cuisine` query param is **inferred** — the aggregations suggest it, but the exact param name needs replay to confirm. See UNKNOWNS.md #3.)

To drill into a facet (e.g. "New on ChowNow"), use the facet's own `next` URL verbatim — it already has `tags=is_new` set:

```
GET /api/restaurant?u_lat=&u_lon=&tags=is_new
```

## Step 5 — click into a restaurant → fetches `/restaurant/{id}` and `/restaurant/{id}/menu`

The result `restaurants[].id` is a **location** id. Navigating to the brand page uses the paired `restaurant_company_id`:

```
GET /order/{restaurant_company_id}/locations/{id}
```

That page triggers [`flow: menu`](./menu.md) which fires three XHRs: `GET /api/restaurant/{id}`, `GET /api/customer/me`, `GET /api/restaurant/{id}/menu`.

## Replay script

See `scripts/replay.py` — the `--flow discovery` option runs this exact sequence against the live API and prints each stage's status, size, and top-level keys.
