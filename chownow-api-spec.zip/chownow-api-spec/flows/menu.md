# Flow: menu — restaurant page load → menu render

Everything needed to render a restaurant's ordering experience, from a cold entry at `www.chownow.com/order/<brand>/locations/<location>`.

## Observed real traffic (from the SPA boot sequence)

Captured 2026-10-15 against `/order/32/locations/35` (Woodlands Market, Kentfield):

```
GET /api/restaurant/35
GET /api/customer/me               -- fires even when anonymous; returns 404
GET /api/restaurant/35             -- second hit; cache miss or React-Query re-fetch
GET /api/restaurant/35/menu
GET /api/web/manifest              -- deferred, lazy; only after the page has rendered
POST /api/restaurant/35/item-recommendations   -- when the first item is added to cart (v5.0)
```

All three request calls share the same headers:
```
Accept: application/json version=3.0;        (or 5.0 for item-recommendations)
Content-Type: application/json; charset=UTF-8
X-CN-App-Info: Marketplace-Web/5.211.0
Origin: https://www.chownow.com
```

## Step 1 — restaurant detail

`GET /api/restaurant/{location_id}` returns the ~15 KB `Restaurant` object. The three fields that matter for the rest of the flow:

- `fulfillment.pickup` / `.delivery` / `.curbside` / `.dine_in` — availability, hours, min/max order, tip rules per mode.
- `order_ahead.days[]` — a 7-day grid of 96 15-minute slots per mode (`pickup`, `delivery`, `curbside`), as a 0/1 array. `current_time_index` points at "now" inside today's array. The scheduling UI renders directly off this.
- `payment_processor_id` — `"3"` indicates Stripe. Pass to UI so it knows which SDK to load.
- `membership.processor_key` — if `is_enabled`, the Stripe publishable key to use for the membership checkout.

## Step 2 — current session (always fires)

`GET /api/customer/me`. Anonymous returns 404 with `{"warnings":["Reverting to default API version: 2.0"], "version":"2.0"}`. Authed returns the `Customer` object. The 404 is **not** an error — it's "no session." The SPA uses it to populate the "Log in" button.

## Step 3 — menu snapshot

`GET /api/restaurant/{location_id}/menu` returns the ~50 KB `Menu` object. The response's `id` is a **menu version** (pattern `<company>_<yyyymmddhhmm>`) that must be echoed on every subsequent order validate/place. If the server mints a new menu version, the server returns `MENU_EXPIRED` on validate and you re-fetch.

Items are nested as:

```
menu_categories[*].items[*]
  id: "M_<company_id>_<item_id>"
  name
  description
  is_meta: true | false
  meta_item_details:
    serving_size_group.child_ids: ["3111147_3723854", ...]   -- these are the real orderable ids
```

Modifier groups and prices are deeper in the item object (not shown in truncated example in this spec's examples/ folder — see the saved full JSON).

## Step 4 — cart is client-side

**No cart XHR fires** from the SPA on add-to-cart, quantity change, or remove. The SPA mutates its in-memory React-Query cache (and mirrors to `sessionStorage` under `chownow:*` keys for cross-tab resumption). The cart is only transmitted to the server on `POST /api/order/validate` at checkout time.

A replay client should model cart identically: build the cart body locally, don't call the server for cart ops. See [`flows/order.md`](./order.md) for the checkout entry.

## Step 5 — upsell recommendations (optional)

Once the cart has at least one item, the SPA fires:

```
POST /api/restaurant/{location_id}/item-recommendations
Accept: application/json version=5.0;      -- note version
Content-Type: application/json; charset=UTF-8

{ "menu_id": "121704_202610151951",
  "selected_item_ids": ["3111147_3723854"],
  "requested_time": null }
```

Client-side 4-second timeout; on timeout the UI silently drops the upsell section.

## Image URLs

Each item/restaurant's `media.cover_image_url` points at `menuimages.chownowcdn.com/image-resizing?...&format=webp`. These are public, Cloudflare-signed URLs. For a replay client that only cares about the data, images can be skipped entirely.
