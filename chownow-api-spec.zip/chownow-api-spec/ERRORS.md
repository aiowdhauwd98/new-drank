# Error-code catalog — private web API

Captured 2026-10-15. The private API wraps every error in:

```json
{ "errors": [ { "code": "<string>", "message": "...", "reason": "...", "field": "...", "value": "..." } ] }
```

- `code` — string of 3-5 digits (or sometimes the HTTP status). Namespaced by family (first 1–2 digits).
- `message` — human-readable; sometimes contains a stringified sub-validator payload (FastAPI/Pydantic details on migrating endpoints).
- `reason` — short machine-ish class. The current observed values:
  - `API logic validation`
  - `A required field is missing`
  - `Value is not in the enum`
  - `The value is an invalid type`
  - `Additional properties given`
  - `Generic exception`
- `field` — the offending request body field path (sometimes `null` at the operation level).
- `value` — the offending value that got rejected (not always present).

**IMPORTANT:** this is NOT the Partner API's RFC 9457 Problem Details envelope. The Partner API at `openapi.chownow.com/v1` uses `{type, title, status, code, detail, errors[{pointer,message}]}`. The two surfaces have different error schemas.

## Observed codes

### `100xx` — schema validation (code shape: int-as-string)

| code    | reason                        | Example message                                                        | Fix                                                                 |
| ------- | ----------------------------- | ---------------------------------------------------------------------- | ------------------------------------------------------------------- |
| `10101` | `A required field is missing` | `'<field>' is a required property`                                     | Add that field to the body.                                         |
| `10201` | `Value is not in the enum`    | `'<value>' is not one of ['a','b',...]`                                | Message leaks the full enum — pick one.                             |
| `10202` | `The value is an invalid type`| `<repr> is not of type 'boolean'`                                      | Message names the expected JSON Schema type.                        |
| `10204` | (schema violation)            | `Length below min length of: 1`                                        | Pad the string (minLength on a required string).                    |
| `10207` | `Additional properties given` | `Additional properties are not allowed ('x','y' were unexpected)`      | Message lists the extras — remove them.                             |

### `120xx` — operation validation

| code    | message                                      | Trigger / recovery                                                     |
| ------- | -------------------------------------------- | ---------------------------------------------------------------------- |
| `12004` | `Invalid request parameters.` + `value` key  | A field's value failed semantic validation. Example: `when="ASAP"` → `reason:"Not a calendar datetime in YYYYMMDDHHMM"`. Fix per the `reason` text. |

### `200xx` — account / identity

| code    | message                             | Trigger / recovery                                                                              |
| ------- | ----------------------------------- | ----------------------------------------------------------------------------------------------- |
| `20105` | `Account creation via Facebook failed` | Facebook SSO token exchange failed. Usually bad/expired `fb_token`.                            |
| `20501` | `Invalid card number`               | Stripe charge attempt rejected the `pm_...` (bad token, expired, declined). Payment stage.      |
| `20502` | `Invalid card number length`        | `customer.billing.card.number` isn't a well-formed Stripe `pm_...` id. Re-tokenize.             |
| `20900` | `User and account id mismatch`      | The authed session's user_id doesn't match the path/query the request targets. 403.             |

### `31xxx`–`37xxx` (+ `993`) — order business rules

Partially observed. The SPA's request module (webpack module `57495`, export `q$`) ships the list of **order-validation error codes the checkout UI knows how to handle**:

`["31001","32001","32003","32004","32005","33001","33002","33003","33004","33005","33006","34001","34002","34003","34004","34005","35001","35002","36008","36009","993"]`

When an order submit fails, the checkout page reports a 5xx code as `Purchase Failure`, treats a code in this list as expected, and logs any other code as a warning, `Unhandled order validation: <message>`. So the list is a lower bound on this error family, not the whole of it. (An earlier version of this file called the list an ONB channel allowlist. That was wrong; see [UNKNOWNS #4](UNKNOWNS.md#4-the-cn_channel-parameter-closed-2026-10-16).)

The same module names three codes (export `cx`), and the checkout page also branches on `31001`, `32001`, `37001` and `37002` individually.

| code    | message                                                              | Trigger / recovery                                       |
| ------- | -------------------------------------------------------------------- | -------------------------------------------------------- |
| `32003` | `Add $<n> to meet the $<min> pickup minimum`                         | Subtotal below `fulfillment.pickup.min_order_amt`. Add items. |
| `33001` | not captured (SPA name: `DELIVERY_UNAVAILABLE`)                      | Delivery not available for this order. Named in the bundle only. |
| `34006` | not captured (SPA name: `MENU_ITEM_UNAVAILABLE`)                     | An item in the cart is no longer available. Named in the bundle only. |
| `37008` | not captured (SPA name: `CURBSIDE_UNAVAILABLE`)                      | Curbside pickup not available. Named in the bundle only.  |
| `993`   | `You submitted an order a minute ago, please wait a minute to try again.` | Per-account 60-second cooldown between order submissions. Server-side rate limit. 403. |
| `41000` | `Unable to process your payment. Please try again.`                  | Payment-processor decline (Stripe charge failed). Order is created with `status: "Declined"`; kitchen does NOT fire. Common cause: AVS zip mismatch, bank fraud block. 200 with top-level order + errors. |

(Expect many more order codes once a real order flow is replayed end-to-end.)

### HTTP-level

| HTTP | app code | Trigger                                               |
| ---- | -------- | ----------------------------------------------------- |
| 400  | `10xxx`  | Schema validation (see above).                        |
| 401  | `401`    | `Authorization required.` — missing/invalid session.  |
| 403  | `20900`  | Authed but authorization scope mismatch.              |
| 404  | `404`    | `Requested object not found` — resource doesn't exist OR anonymous-request-for-user-resource. |
| 405  | n/a      | Bottle's default HTML 405 page. The URL exists but doesn't bind the method. |
| 500  | `500`    | `Generic exception`. Server crash, usually a mis-shaped body on a route that doesn't guard early. |
| 501  | `501 Not Implemented` | `HTTPError` — route or verb not implemented.                     |

## Backend hints the errors leak

- **Bottle** — HTML 405 page template matches Bottle's default. Private-API Python stack.
- **jsonschema** (Python) — the `10101/10201/10202/10204/10207` messages exactly match `jsonschema.exceptions.ValidationError.message` for `required`, `enum`, `type`, `minLength`, `additionalProperties`. So Bottle + jsonschema is the validator pipeline.
- **FastAPI/Pydantic** — on `/api/autocomplete` the inner `message` is a Pydantic-shaped `{"detail":[{"loc":[...],"msg":"...","type":"value_error.missing"}]}`. Newer endpoints migrated to FastAPI.
- **Django REST Framework** — `/api/customer/me/orders` returns `{count,next,previous,results}` — the DRF default paginator. Another newer service.
- **Three stacks coexist**: Bottle (legacy, most of /customer/*), FastAPI (newer, /autocomplete), DRF (newer, /customer/me/orders).
