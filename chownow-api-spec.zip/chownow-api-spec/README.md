# chownow-api-spec

A reverse-engineered, replayable specification of ChowNow's public and private HTTP surface, built by driving the real web client and probing the live hosts. Written 2026-10-15.

ChowNow operates two orthogonal APIs:

| Surface            | Host                                        | Purpose                                                     | Auth                                | See                                   |
| ------------------ | ------------------------------------------- | ----------------------------------------------------------- | ----------------------------------- | ------------------------------------- |
| **Partner API**    | `openapi.chownow.com/v1`                    | Server-to-server integrator API (POS, loyalty, aggregators) | OAuth2 client-credentials → JWT     | [`endpoints/partner-api.md`](endpoints/partner-api.md) |
| **Private web API**| `api.chownow.com/api`                       | Powers the browser SPA and the native apps                  | Cookie session, versioned via `Accept` header | [`endpoints/private-web-api.md`](endpoints/private-web-api.md) |

The two APIs are **not the same product**. The Partner API is a documented, scope-gated REST surface served off a separate hostname (`openapi.chownow.com`) and a separate OAuth2 identity provider (`auth.developer.chownow.com`, WorkOS-shaped). It intentionally hides restaurant-location detail, menu versioning, Stripe tokens, courier states, etc. behind a cleaner contract. The private web API at `api.chownow.com/api` is what the actual customer-facing apps use. It carries the whole shopping experience — discovery, menu, cart, checkout, order history, favorites, memberships — and uses a cookie session the server mints on sign-in.

This spec covers both.

---

## Repo layout

```
chownow-api-spec/
├── README.md                 - this file
├── METHODOLOGY.md            - exactly how the capture was done; replayable
├── FINDINGS.md               - what works, what's inferred, what's blocked
├── UNKNOWNS.md               - ranked gaps + how to resolve each
├── openapi.yaml              - OpenAPI 3.1 for every verified endpoint
├── endpoints/
│   ├── partner-api.md        - openapi.chownow.com/v1 (OAuth2 Partner)
│   ├── private-web-api.md    - api.chownow.com/api (private)
│   └── mobile.md             - iOS + Android identifiers, deep-link paths
├── flows/
│   ├── discovery.md          - city search → results → cuisine filter
│   ├── menu.md               - restaurant → menu → item/modifier model
│   ├── order.md              - cart (client) → validate → place → status
│   └── auth.md               - signin/signup/SSO/magic-link/forgot/reset
├── schemas/
│   ├── manifest.json         - /api/web/manifest response
│   ├── restaurant.json       - /api/restaurant/{id} response
│   ├── menu.json             - /api/restaurant/{id}/menu response
│   └── discovery.json        - /api/restaurant list response
├── examples/                 - real captured request/response pairs
├── har/                      - (empty — the Claude built-in browser does not
│                               expose HAR export; raw request/response pairs
│                               live in examples/ with timestamped folders.)
├── bundles/                  - archived minified JS the API was mined from
└── scripts/
    ├── probe.sh              - single-shot authed/anonymous probe
    ├── replay.py             - full anonymous-flow replay using httpx
    ├── mine_paths.py         - extract REST-shaped literals from a JS bundle
    ├── mine_api_calls.py     - extract `new URL(/api/...)` call sites
    ├── mine_v2.py            - extract fetch(X, s("METHOD",...)) call sites
    ├── mine_v3.py            - extract s(METHOD)-adjacent template paths
    └── token_search.py       - substring search for RE tokens in a bundle
```

The `examples/` folder is the source of truth for every claim marked `[VERIFIED by replay]` — each sub-folder is one real request against the live API, named `<UTCstamp>_<METHOD>_<slugified_url>/`, with `response_headers.txt` and `response_body.json` beside it.

---

## Environment notes (2026-10-15)

- SPA bundle: `direct.chownow.com/static/js/main.93c065e7.js`, app version `5.211.0`.
- Marketplace shell: Next.js 4.81.0 at `www.chownow.com`.
- Order shell: SPA embedded inside Next.js shell; the SPA is channel-aware and sets `X-CN-App-Info: {Marketplace-Web | Yelp-Web | Direct-Web}/5.211.0` based on the host it is running on.
- CDN: Cloudflare in front of both `www.chownow.com` and `api.chownow.com`. A JS challenge (`/cdn-cgi/challenge-platform/`) runs on the page, but **the API itself was reachable from `curl` with a plain Chrome `User-Agent` and the three `X-CN-App-Info / Accept / Content-Type` headers** — no `curl-impersonate` / `tls-client` was needed for anonymous read endpoints.
- Everything was captured during 22:50–23:05 UTC on 2026-10-15; data is a point-in-time snapshot. Menu `menu_id` strings are of the form `<company_id>_<yyyymmddhhmm>` and will rotate.

---

## Auth model, at a glance

**Partner API** — OAuth2 client-credentials.
- Mint: `POST https://auth.developer.chownow.com/oauth2/token` with form-encoded `grant_type=client_credentials&client_id=&client_secret=`.
- Use: `Authorization: Bearer <jwt>` on every call.
- TTL: 3600 s. Scopes: `restaurants:read`, `catalog:read`, `orders:read`, `orders:write`.

**Private web API** — session cookies, no bearer token.
- Every request sent with `credentials: "include"`; the server sets session cookies on successful sign-in via `POST /api/customer/signin`.
- Versioning is in the `Accept` header: `Accept: application/json version=3.0;` (or `5.0` for a handful of newer endpoints). If the requested version does not exist for that resource, the server **silently falls back to its default** (2.0) and includes `{"warnings": ["Reverting to default API version: 2.0"], "version": "2.0"}` in the response.
- Channel identity in `X-CN-App-Info: {Marketplace-Web | Yelp-Web | Direct-Web}/<app-version>`. The server reads this to apply a `meta.marketplace: {id: "2", x_id: null}` injection on write bodies when the channel is `Marketplace-Web`.
- Anonymous sessions get a client-side UUID `diner-<uuid>` used only by LaunchDarkly for feature-flag targeting — it is not an API credential.
- Guest checkout: supported. The `customer` object is inline on the order body and no sign-in is required (`allows_no_payment_checkout` and the `payment_type` enum govern this per restaurant).

Full tables in [`endpoints/private-web-api.md`](endpoints/private-web-api.md).

---

## Third parties in the request path

The customer flow actively calls these outside first-party hosts. They are all client-side only; the private API never relays through them.

| Vendor         | Role                                                      | Observed identifier                                        |
| -------------- | --------------------------------------------------------- | ---------------------------------------------------------- |
| Google Maps JS | Place autocomplete, geocoding, map tiles on `/search`     | API key `AIzaSyDUlpe6P81A4LHenAbyymQMT5uPPttRZW0` (referrer-locked) |
| Google Pay     | Payment sheet (`pay.google.com/gp/p/js/pay.js`)           | Merchant handshake runs inline                              |
| Apple Pay      | `/.well-known/apple-developer-merchantid-domain-association`; merchant id `merchant.com.stripe.chownow` | — |
| Stripe         | Card tokenization and Apple/Google Pay settlement         | Publishable key `pk_live_1rHqZgeuWfzjo9nCVWMdRsbZUztUaNhhlxt4wHymS1kVK5MDf8dLcyjojGR487uMuZSeZyjKIraWRqrTKSoLfNzr000Bs7zTqEF` (from `/api/web/manifest`); same key is also returned per-restaurant on the `membership.processor_key` field |
| Sift Science   | Device fingerprint for fraud (loaded on every order page) | `cdn.siftscience.com/s.js`                                  |
| Branch.io      | Deep links from marketing / app-link cards                 | `cdn.branch.io/branch-latest.min.js`                        |
| mParticle      | Event analytics (`add_to_cart`, `payment_attempted`, …)   | Account `us1-ac1aceee57b0a84fb9b566f3377d629e`, plan `chownow_marketplace` v2 |
| LaunchDarkly   | Feature flags                                              | Client-side id `61f8128467ed48159707693c`                  |
| Sentry         | Error reporting                                            | Project `1476807`, DSN `e4ffdff121ec415eb1d9c162b0b21333`   |
| Rokt           | Upsell / in-flow ad placements                            | `apps.rokt-api.com/wsdk/`                                   |
| OneTrust       | Cookie consent (`cdn.cookielaw.org`)                      | Script id `5adc3527-b6ec-4d0d-b0f6-e706f15990f7`           |
| Iterable       | Marketing email (privacy policy linked from manifest)      | `iterable.com/trust/privacy-policy/`                       |
| Hexagon Analytics | Additional analytics on marketplace pages                | `hexagon-analytics.com/images/106621.gif`                   |

None of these are required to call the first-party API; a replay client can skip all of them.

---

## Anti-bot

Cloudflare sits in front of `www.chownow.com` AND `api.chownow.com`. On `www.*` the JS challenge (`/cdn-cgi/challenge-platform/`) is active for every page load. On `api.*` the challenge did not fire against plain `curl` requests with a browser UA during this capture window — read endpoints returned 200 OK directly. **Expect this to change under load**; if a future replay hits 403/HTML-interstitial, swap `curl`/`httpx` for `curl-impersonate` (chrome120) or `tls-client` and retry. The three canonical headers (`Accept`, `Content-Type`, `X-CN-App-Info`) stay the same.

---

## Mobile APIs

iOS: **`com.ChowNow.Marketplace`** (bundle), iTunes `1210943577`, v1.74.0 released 2026-10-05, min iOS 15.0 — "ChowNow: Local Food Ordering". Deep links `/order/*/locations/*` and `/`.
Android: **`com.chownow.discover`** (package), SHA256 cert `CA:27:AC:EC:C6:28:71:83:7D:B1:B3:23:A4:3D:75:00:60:6F:53:5B:74:EF:A9:8B:4F:78:0E:FC:80:40:49:E7`.

Per-restaurant **ChowNow Direct** apps are per-brand builds (`com.chownow.<brand>` on Android, `id<n>` on iOS) that each wrap `direct.chownow.com` with branded theming — they call the **same** `api.chownow.com/api/` endpoints as the web SPA. The marketplace apps are expected to as well; `X-CN-App-Info` would carry `Diner-iOS/<v>` or `Diner-Android/<v>` instead of `Marketplace-Web/<v>`. Full details in [`endpoints/mobile.md`](endpoints/mobile.md). DEX/IPA binary analysis is still deferred — APK download is Cloudflare-blocked on every public mirror we tried; the resolution procedure is in [`UNKNOWNS.md`](UNKNOWNS.md) #2.

---

## Where to go next

1. Read [`FINDINGS.md`](FINDINGS.md) for the full inventory and VERIFIED/OBSERVED/INFERRED tags.
2. Walk [`flows/order.md`](flows/order.md) for the quote → place → status sequence.
3. Hit `python scripts/replay.py --flow discovery` to re-verify the public-read endpoints from a clean shell.
4. If you need Partner API access, start at [`endpoints/partner-api.md`](endpoints/partner-api.md) and apply at `developer.chownow.com/request-access`.
