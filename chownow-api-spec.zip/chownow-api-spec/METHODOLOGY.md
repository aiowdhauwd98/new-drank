# Methodology

How this spec was produced on 2026-10-15, and how a future pass would reproduce it.

## Tools used

| Phase                 | Tool                                              |
| --------------------- | ------------------------------------------------- |
| Recon (host map, docs)| `WebFetch`, `WebSearch`, direct `curl` probes     |
| Browser automation    | The Claude desktop app's built-in browser pane (Chromium) with `mcp__Claude_Browser__*` tools |
| JS deobfuscation      | Python regex extractors (`scripts/mine_*.py`), ripgrep |
| Replay                | `curl` (via `scripts/probe.sh`), Python `httpx` (via `scripts/replay.py`) |

A full capture environment (Playwright + mitmproxy + a mobile emulator with cert-unpinning) was **not** available in this session; the web surface was fully reachable with the browser pane and `curl`, and mobile is flagged in [`UNKNOWNS.md`](UNKNOWNS.md).

---

## Phase 1 — Recon

1. **Public hostname inventory**
   - `curl https://www.chownow.com/robots.txt` → learned the two sitemaps and the three `Disallow` paths that reveal routing (`/order/*/locations/*`, `/search/*`, `/cdn-cgi/*`).
   - Pulled the first ~80 entries from both sitemaps (`sitemap-brand-chownow.xml`, `sitemap-location-chownow.xml`) to learn the brand/location id pattern.
   - WebSearch'd `site:developer.chownow.com` and found the public **Partner API** portal — captured its five doc pages: `/`, `/docs/getting-started`, `/docs/getting-access`, `/docs/authentication`, `/docs/guides/place-an-order`.

2. **Framework fingerprint**
   - Loaded `www.chownow.com` in the browser pane and probed `document.scripts`, `performance.getEntriesByType('resource')`.
   - Discovered the two-origin architecture: marketplace shell is Next.js 4.81.0 on `www.chownow.com`; the ordering experience is a separate React SPA served from `direct.chownow.com` and embedded inside the Next.js shell via `<script defer>` for `vendor.3f4b5240.js` and `main.93c065e7.js`.

3. **Bundle acquisition**
   - `curl` the SPA's `vendor.3f4b5240.js` (794 KB), `main.93c065e7.js` (155 KB), and the seven lazy chunks that mount on the order page.

## Phase 2 — Capture

The capture phase ran in two parallel tracks: live browser capture and static mining of the SPA bundles.

### Live browser capture

1. Opened `https://www.chownow.com/order/32/locations/35` (Woodlands Market — Kentfield) in a new tab; the SPA mounted and fired its boot sequence.
2. Installed a persistent `window.fetch` interceptor so every XHR could be read back later with method, request headers, body, status, response headers, response body:

   ```js
   if (!window.__cn_calls) {
     window.__cn_calls = [];
     const orig = window.fetch;
     window.fetch = async function(url, opts) { /* capture → __cn_calls → delegate → return */ };
   }
   ```

3. Read `performance.getEntriesByType('resource')` to list every request URL (the built-in browser's `read_network_requests` tool filtered too aggressively; Performance API was the ground truth).
4. Opened `https://www.chownow.com/search?loc=Los%20Angeles%2C%20CA` to capture the discovery flow.

### Static mining

The 155 KB `main.93c065e7.js` is where every path to `api.chownow.com/api/` is constructed. Three extractors (committed under `scripts/`) walk it:

- `mine_paths.py` — pulls REST-shaped string literals (`restaurant/${id}/menu`, `customer/me`, …). These are the first argument to the SPA's `l()` request-options builder, which prepends `https://api.chownow.com/api/`.
- `mine_api_calls.py` — pulls `new URL("/api/...", "https://api.chownow.com/api")` call sites, since some endpoints are built via `new URL` instead of the builder.
- `mine_v3.py` — walks every `s("METHOD", body?, version?)` call and matches it to the nearest preceding template-literal path to recover `(method, path, body-hint)` triples.
- `token_search.py` — grep for RE tokens of interest (`login`, `signup`, `cart`, `address`, `payment`, …) inside string literals, with context.

The lazy chunks (`chunk-244.js` etc.) proved to contain **zero** direct `api.chownow.com` references — all API logic is in `main.js`; chunks are UI only.

### OPTIONS enumeration

After bundle mining identified a `customer/*` prefix, 32 candidate paths were enumerated by firing a CORS-preflight **OPTIONS** request with `Origin: https://www.chownow.com` and `Access-Control-Request-Method: POST`. A 200 means the server published a CORS allowance for that path; a 404 means it doesn't exist. This technique revealed the entire auth surface (`customer/signin`, `customer/signup`, `customer/forgot-password`, `customer/reset-password`, `customer/password`, `customer/session`, `customer/exists`, `customer/sso`, `customer/google`, `customer/apple`, `customer/magic-link`) which was otherwise invisible as a literal in the SPA bundle. OPTIONS was chosen specifically because it does not transmit authentication, has no side effects, and is published by the CORS layer rather than the authenticated application.

## Phase 3 — Extract

Documented every endpoint under [`endpoints/private-web-api.md`](endpoints/private-web-api.md) and [`endpoints/partner-api.md`](endpoints/partner-api.md), with per-row confidence tags:

- `[VERIFIED by replay]` — fired via `scripts/probe.sh` against the live API from `curl` and saw an expected (2xx) response.
- `[OBSERVED]` — path and method confirmed from the SPA's own XHRs (via the fetch interceptor or Performance API), or by OPTIONS preflight returning 200.
- `[INFERRED]` — path extracted from the SPA bundle but no replay yet. Method is sometimes inferred from React-Query usage (`useQuery`/`useMutation`).

Grouped by domain:
- `discovery.md` — city search, cuisine aggregations, facets.
- `menu.md` — restaurant detail, menu + modifier hierarchy.
- `auth.md` — signin, signup, SSO, magic-link, forgot/reset, session.
- `cart.md` — client-side only; documented as such.
- `checkout.md` — order validate / place / status.
- `account.md` — profile, addresses, billing cards, favorites, memberships, rewards.

## Phase 4 — Replay & verify

Every `[VERIFIED by replay]` tag corresponds to a run of `scripts/probe.sh` whose output lives in `examples/<UTCstamp>_<METHOD>_<slug>/` as:

- `response_headers.txt` — the full response header block as returned by Cloudflare + ChowNow.
- `response_body.json` — the response body, in its native encoding.

For the end-to-end flow, `scripts/replay.py` chains anonymous reads: boot manifest → discovery near a city → restaurant detail → menu. It is deliberately read-only. It exits with a non-zero status if any step mismatches the documented shape.

Authenticated flows (signin, order place, favorites, memberships) require a real customer session and were **not** closed in this session — see [`UNKNOWNS.md`](UNKNOWNS.md).

## Phase 5 — Harden

- `openapi.yaml` was handwritten from the probed responses; schemas were derived by observation, not generated.
- All secrets in captured examples that could identify a human are nulls — the sample flow was anonymous.
- The one public key found (Stripe `pk_live_...`) is **publishable**, intended to be seen client-side, and is left in place.

---

## Reproducibility checklist

To redo this spec end-to-end in a different session:

1. `curl` the two sitemaps and `robots.txt` from `www.chownow.com`.
2. `curl` every page under `developer.chownow.com/docs/*`.
3. Open `www.chownow.com/order/<brand>/locations/<location>` in a Chromium browser you control; `document.scripts` names the SPA bundle to download.
4. `curl` `main.<hash>.js` and `vendor.<hash>.js` from `direct.chownow.com/static/js/`.
5. Run `scripts/mine_paths.py main.*.js` and `scripts/mine_api_calls.py main.*.js`.
6. Install the `window.fetch` interceptor; drive each flow by hand.
7. Preflight-enumerate `OPTIONS` against the paths listed in `scripts/replay.py::OPTIONS_PROBE_PATHS` to confirm nothing new has shipped since.
8. Diff against `openapi.yaml`; add or remove endpoints as needed.
