#!/usr/bin/env python3
"""Extract every /api/ call site from a minified JS bundle.

For each occurrence of '/api/' in the file, pull a window of context, then
try to identify the HTTP method and the templated path. Also captures the
`fetch(url, {...})` option shape and the pre-shared headers builder.
"""
from __future__ import annotations
import re, sys, pathlib, json, collections

if len(sys.argv) < 2:
    print("usage: mine_api_calls.py <bundle.js>", file=sys.stderr); sys.exit(2)

text = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8", errors="replace")

# 1) Templated URL constructions:  new URL(`/api/...`, "https://api.chownow.com/api")
#    Capture the backtick template string.
URL_CTOR = re.compile(r"new URL\(\s*`([^`]{3,200})`\s*,\s*\"https://api\.chownow\.com/api\"\s*\)")
calls = []
for m in URL_CTOR.finditer(text):
    path = m.group(1)
    start = max(0, m.start() - 400)
    end   = min(len(text), m.end() + 500)
    window = text[start:end]
    # look backwards for a nearby `s("METHOD", body)` or `i(...)` request-builder call
    method_m = re.search(r"\bs\(\s*\"(GET|POST|PUT|PATCH|DELETE|HEAD)\"", window)
    is_i    = "fetch(" in window and ",i(" in window  # i() = default GET builder
    method = method_m.group(1) if method_m else ("GET" if is_i else "?")
    # body hint: content after the method literal, until the closing fetch
    body_hint = None
    if method_m:
        bh = re.search(r"s\(\s*\"(?:GET|POST|PUT|PATCH|DELETE)\"\s*,\s*(\{[^}]{0,220}\})", window)
        if bh:
            body_hint = bh.group(1)[:200]
    calls.append((path, method, body_hint))

seen = set()
unique = []
for c in calls:
    key = (c[0], c[1])
    if key in seen: continue
    seen.add(key)
    unique.append(c)
unique.sort(key=lambda c: (c[1], c[0]))

print(f"Total /api/ URL constructions: {len(calls)}  |  unique (path+method): {len(unique)}\n")
for path, method, body in unique:
    print(f"  {method:6s}  /api{path}")
    if body:
        print(f"           body-hint: {body}")

# 2) The request-builder itself: `s(method, body, version)` and `i(version)` helpers
print("\n==== Request-builder header shape (±350B around 'X-CN-App-Info') ====")
for m in re.finditer(r".{0,350}X-CN-App-Info.{0,350}", text):
    print(m.group(0).replace("\\n", " "))
    print("---")

# 3) Base-URL rewrite: Marketplace-Web / Yelp-Web / Direct-Web mapping
print("\n==== Channel/base rewrite ====")
for m in re.finditer(r".{0,200}(Marketplace-Web|Yelp-Web|Direct-Web).{0,200}", text):
    print(m.group(0))
    print("---")

# 4) Any additional base-URL hosts in the bundle besides api.chownow.com
print("\n==== Other https:// bases referenced ====")
bases = collections.Counter()
for m in re.finditer(r"https://[a-z0-9.\-]+\.(com|io|net|cloud|dev|co|app)(/[A-Za-z0-9_\-./]*)?", text):
    bases[m.group(0)] += 1
for b, n in bases.most_common(60):
    print(f"  {n:>4} {b}")
