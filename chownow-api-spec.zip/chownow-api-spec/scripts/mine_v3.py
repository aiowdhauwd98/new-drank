#!/usr/bin/env python3
"""V3: for every s(METHOD,...) occurrence, find the nearest preceding template-literal path.

The ChowNow web client's call shape is:
    const u = new URL(`/api/<path>`, "https://api.chownow.com/api"),
          body = {...},
          r = await fetch(u, s("METHOD", body, "VERSION"));

We walk every `s(` call that passes a method literal, then look backward within
400 bytes for a backticked template literal that looks like a path, and forward
for the body `{...}` arg. We also catch `l("path", body, "METHOD", ...)` style.
"""
from __future__ import annotations
import re, sys, pathlib

text = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8", errors="replace")

# any s(METHOD, ...)
S_CALL = re.compile(r"""\bs\(\s*["'](GET|POST|PUT|PATCH|DELETE)["']\s*(?:,\s*(\{[^}]{0,260}\}|[A-Za-z_$][\w$.]*))?""")
# backticked path near fetch
TPL = re.compile(r"`([^`]{2,200})`")

seen = set()
found = []

for m in S_CALL.finditer(text):
    method, bodyish = m.group(1), (m.group(2) or "").strip()
    # look back 450 bytes for the most recent template-literal path
    start = max(0, m.start()-450)
    window = text[start:m.start()]
    # pick the LAST backticked literal containing a slash and no HTML
    last = None
    for tm in TPL.finditer(window):
        s = tm.group(1)
        if "/" in s and " " not in s and "<" not in s and "}" not in s[:2]:
            last = s
    if not last: continue
    # body may be a short literal or an identifier
    body_short = bodyish[:160].replace("\n", " ")
    key = (last, method)
    if key in seen: continue
    seen.add(key)
    found.append((method, last, body_short))

# Also catch `l(path, body, method)` calls -- method literal is 3rd positional
L_CALL = re.compile(r"""\bl\(\s*["'`]([^"'`]{2,160})["'`]\s*,\s*([^,]{0,220})\s*,\s*["'`](GET|POST|PUT|PATCH|DELETE)["'`]""")
for m in L_CALL.finditer(text):
    path, body, method = m.group(1), m.group(2).strip(), m.group(3)
    key = (path, method)
    if key in seen: continue
    seen.add(key)
    found.append((method, path, body[:160]))

# Sort by path for readability
found.sort(key=lambda x: (x[1], x[0]))
for method, path, body in found:
    norm = path.lstrip("/")
    if norm.startswith("api/"): norm = norm[4:]
    print(f"  {method:6s}  /api/{norm}")
    if body: print(f"           body~ {body}")
