#!/usr/bin/env python3
"""Extract REST-shaped strings and api.chownow.com context from a minified JS bundle."""
from __future__ import annotations
import re, sys, json, pathlib, collections

if len(sys.argv) < 2:
    print("usage: mine_paths.py <bundle.js> [bundle2.js ...]", file=sys.stderr)
    sys.exit(2)

RESTY = re.compile(r"""(?P<q>["'`])(?P<s>[A-Za-z0-9_\-./:${}]{3,120})(?P=q)""")
API_CTX = re.compile(r".{0,160}api\.chownow\.com.{0,220}")
# Looks like a REST path: at least one slash, contains word chars, optional template ${}, no spaces
PATHY = re.compile(r"^[A-Za-z0-9_${}][A-Za-z0-9_\-./${}]*/[A-Za-z0-9_\-./${}]+$")

for arg in sys.argv[1:]:
    path = pathlib.Path(arg)
    text = path.read_text(encoding="utf-8", errors="replace")
    print(f"\n==== {path.name}  ({len(text):,} bytes) ====")

    # 1) all string literals that look like REST paths
    paths = collections.Counter()
    for m in RESTY.finditer(text):
        s = m.group("s")
        if PATHY.match(s) and "." not in s.rsplit("/", 1)[-1][:8]:  # skip filenames
            paths[s] += 1

    print(f"\n-- REST-shaped string literals ({len(paths)} unique) --")
    for s, n in paths.most_common():
        print(f"{n:>4}  {s}")

    # 2) show every api.chownow.com context window
    print(f"\n-- api.chownow.com contexts --")
    seen = set()
    for m in API_CTX.finditer(text):
        chunk = m.group(0)
        # dedupe by hash of chunk
        h = hash(chunk)
        if h in seen: continue
        seen.add(h)
        print("  …" + chunk.replace("\n", "\\n") + "…")
