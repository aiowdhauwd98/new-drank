for ($i = 0; $i -lt 15; $i++) {
    [Console]::Beep(1500, 250)
    Start-Sleep -Milliseconds 60
}
# Also play an actual WAV so laptop speakers kick in (console beep uses motherboard speaker on some setups)
try {
    $player = New-Object System.Media.SoundPlayer "C:\Windows\Media\Alarm01.wav"
    for ($j = 0; $j -lt 5; $j++) { $player.PlaySync() }
} catch {}
