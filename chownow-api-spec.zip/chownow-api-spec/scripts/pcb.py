#!/usr/bin/env python3
"""
Place a ChowNow order through real Chromium — ALL API calls fire from inside
the live page, so every fingerprint signal (TLS, cookies, Sift beacon, UA, JS
runtime state, request timing) matches what Chrome itself would send.

Install once:
    pip install playwright
    playwright install chromium

Run:
    python place_order_browser.py --dry-run
    python place_order_browser.py
    python place_order_browser.py --headed      # watch it work in a window
"""
from __future__ import annotations
import argparse
import getpass
import json
import os
import random
import re
import secrets
import string
import sys
import time

# Prefer patchright (Playwright fork with built-in anti-detection patches tuned
# for Sift / Datadome / Cloudflare). Falls back to vanilla playwright if not installed.
try:
    from patchright.sync_api import sync_playwright  # type: ignore
    _PW_FLAVOR = "patchright"
except ImportError:
    try:
        from playwright.sync_api import sync_playwright
        _PW_FLAVOR = "playwright"
    except ImportError:
        print("Install first:  pip install patchright  &&  patchright install chromium", file=sys.stderr)
        sys.exit(2)
try:
    import requests
except ImportError:
    print("Install first:  pip install requests", file=sys.stderr); sys.exit(2)

# Public Stripe publishable key from GET /api/web/manifest
STRIPE_PK = "pk_live_1rHqZgeuWfzjo9nCVWMdRsbZUztUaNhhlxt4wHymS1kVK5MDf8dLcyjojGR487uMuZSeZyjKIraWRqrTKSoLfNzr000Bs7zTqEF"

def parse_proxy(raw):
    """Accept either a full URL or the host:port:user:pass colon-list format
    many proxy vendors (incl. Evomi) hand out. Returns (server, user, pass).
    """
    if not raw: return None, None, None
    from urllib.parse import urlparse
    # host:port:user:pass style
    if "://" not in raw:
        parts = raw.split(":")
        if len(parts) == 4:
            host, port, user, pw = parts
            return f"http://{host}:{port}", user, pw
    # Also allow http://host:port:user:pass (what the user actually pasted)
    if "://" in raw:
        scheme, rest = raw.split("://", 1)
        parts = rest.split(":")
        if len(parts) == 4:
            host, port, user, pw = parts
            return f"{scheme}://{host}:{port}", user, pw
    # Fall through to standard URL parsing
    u = urlparse(raw)
    scheme = u.scheme or "http"
    return f"{scheme}://{u.hostname}:{u.port}", (u.username or None), (u.password or None)

def requests_proxies(raw):
    if not raw: return None
    server, user, pw = parse_proxy(raw)
    if user and pw:
        from urllib.parse import urlparse, quote
        s = urlparse(server)
        auth_url = f"{s.scheme}://{quote(user)}:{quote(pw)}@{s.hostname}:{s.port}"
        return {"http": auth_url, "https": auth_url}
    return {"http": server, "https": server}

def stripe_preflight(pan, exp_m, exp_y, cvc, postal, proxy_url=None):
    """Create a PaymentMethod via Stripe directly and print the full card detail.
    Returns (ok, message). The response includes:
      - card.checks.cvc_check (pass|fail|unavailable|unchecked)
      - card.checks.address_zip_check / address_line1_check
      - card.funding (credit|debit|prepaid|unknown)
      - card.country (ISO)
      - card.brand (visa|mastercard|...)
      - card.wallet (null, or apple_pay/google_pay/link data if present)
    Those tell us if the card is prepaid, in a mismatched country, or
    getting AVS/CVC-blocked by the issuer before ChowNow even attempts a charge.
    """
    r = requests.post(
        "https://api.stripe.com/v1/payment_methods",
        auth=(STRIPE_PK, ""),
        data={
            "type": "card",
            "card[number]": pan.replace(" ", ""),
            "card[exp_month]": str(exp_m),
            "card[exp_year]":  str(exp_y),
            "card[cvc]":       str(cvc),
            "billing_details[address][postal_code]": postal,
        },
        timeout=20,
        proxies=requests_proxies(proxy_url),
    )
    if r.status_code != 200:
        try:
            err = r.json().get("error", {})
        except Exception:
            return False, f"Stripe HTTP {r.status_code}: {r.text[:200]}"
        return False, f"Stripe REJECTED. code={err.get('code')} decline_code={err.get('decline_code')} msg={err.get('message','')[:200]}"
    j = r.json()
    c = j.get("card", {}) or {}
    checks = c.get("checks", {}) or {}
    bits = [
        f"brand={c.get('brand')}",
        f"last4={c.get('last4')}",
        f"funding={c.get('funding')}",         # credit / debit / prepaid / unknown
        f"country={c.get('country')}",         # issuer country
        f"cvc_check={checks.get('cvc_check')}",
        f"zip_check={checks.get('address_postal_code_check')}",
        f"line1_check={checks.get('address_line1_check')}",
        f"wallet={(c.get('wallet') or {}).get('type')}",
    ]
    issues = []
    if checks.get("cvc_check") == "fail":
        issues.append("CVC does NOT match the issuer's records (wrong 3-digit code)")
    if checks.get("address_postal_code_check") == "fail":
        issues.append("Billing ZIP does NOT match the issuer's records")
    if c.get("funding") == "prepaid":
        issues.append("Card is PREPAID — many merchants decline these on policy")
    if c.get("country") and c.get("country") != "US":
        issues.append(f"Card issued in {c.get('country')} — may fail US merchant checks")
    tag = "✓ Stripe accepted" if not issues else "⚠ Stripe accepted BUT:"
    msg = f"{tag} {' '.join(bits)}"
    for i in issues:
        msg += f"\n       !! {i}"
    return (not issues), msg

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

WARMUP_URL    = "https://www.chownow.com/order/32/locations/35?mode=pickup"
RESTAURANT_ID = "35"
WHEN          = None   # None = ASAP pickup; use "YYYYMMDDHHMM" for scheduled
ITEMS         = [{"id": "26801454_28687426", "quantity": 1}]  # Mt. Tam Crunch
FULFILL       = "pickup"   # "pickup" or "delivery"

DELIVERY_ADDRESS = {
    "is_google_place":  True,
    "street_address1":  "100 College Ave",
    "street_address2":  "",
    "city": "Kentfield", "state": "CA", "zip": "94904",
    "latitude": 37.9525, "longitude": -122.5500,
    "country": "USA", "country_alpha2": "US",
    "geo": "37.9525,-122.55",
    "formatted_address": "100 College Ave, Kentfield CA 94904",
}

API_PATHS = {
    "signup":   "/api/customer",
    "menu":     "/api/restaurant/35/menu",
    "validate": "/api/order/validate",
    "order":    "/api/order",
}

# ---------------------------------------------------------------------------
# Local helpers
# ---------------------------------------------------------------------------

FIRST_NAMES = ["Alex","Jordan","Taylor","Morgan","Riley","Casey","Avery","Quinn","Hayden","Jamie",
               "Dakota","Reese","Skyler","Rowan","Finley","Emerson","Blake","Harper","Logan","Peyton",
               "Charlie","Sam","Drew","Cameron","Parker","Micah","Kai","Elliot","Spencer","Devon",
               "Chris","Pat","Jesse","Robin","Terry","Jordan","Max","Lee","Toni","Dana"]
LAST_NAMES  = ["Smith","Johnson","Williams","Brown","Jones","Garcia","Miller","Davis","Rodriguez","Martinez",
               "Hernandez","Lopez","Gonzalez","Wilson","Anderson","Thomas","Taylor","Moore","Jackson","Martin",
               "Lee","Perez","Thompson","White","Harris","Sanchez","Clark","Ramirez","Lewis","Robinson",
               "Walker","Young","Allen","King","Wright","Scott","Torres","Nguyen","Hill","Flores"]
# Real US area codes
AREA_CODES = ["202","213","305","310","312","404","415","425","503","512","602","617","619","646","702",
              "713","773","781","832","847","858","919"]

def random_credentials():
    first = random.choice(FIRST_NAMES)
    last  = random.choice(LAST_NAMES)
    tag   = secrets.token_hex(3)[:5]           # 5 hex chars
    nnn   = secrets.randbelow(90) + 10         # 2-digit number
    email = f"{first.lower()}.{last.lower()}{nnn}{tag}@gmail.com"
    alphabet = string.ascii_letters + string.digits + "!@#$%&*-_"
    password = "".join(secrets.choice(alphabet) for _ in range(20)) + "A1!"
    area = random.choice(AREA_CODES)
    phone = f"{area}{secrets.randbelow(900)+100}{secrets.randbelow(9000)+1000}"  # NXX-XXXX
    return email, password, first, last, phone

def parse_exp_mmyy(raw):
    m = re.match(r"^(\d{1,2})\s*[/\-]\s*(\d{2}|\d{4})$", raw.strip().replace(" ", ""))
    if not m: raise ValueError(f"expected MM/YY, got {raw!r}")
    month, year = int(m.group(1)), int(m.group(2))
    if year < 100: year += 2000
    return month, year

def detect_brand(pan):
    n = pan.replace(" ", "")
    if n.startswith("4"): return "Visa"
    if n[:2] in ("34","37"): return "American Express"
    if n[:4] == "6011" or n[:2] == "65": return "Discover"
    if n[:2] == "35": return "JCB"
    if n[:3] in ("300","301","302","303","304","305") or n[:2] in ("36","38","39"): return "Diners Club"
    if n[:2] == "62": return "UnionPay"
    try:
        if 51 <= int(n[:2]) <= 55 or 2221 <= int(n[:4]) <= 2720: return "MasterCard"
    except ValueError: pass
    return "Visa"

def cart_items():
    return [{
        "id": it["id"], "quantity": int(it.get("quantity", 1)),
        "recipient": None, "special_instructions": None,
        "client_id": str(int(time.time() * 1_000_000)),
        "modifier_categories": it.get("modifier_categories", []),
    } for it in ITEMS]

BRAND_TYPE_ID = {"Visa":"1","MasterCard":"2","American Express":"3","Discover":"4","JCB":"5","Diners Club":"6","UnionPay":"7"}

def build_body(me, menu_id, phone):
    """Body shape confirmed from a 2026-10-16 HAR of the real browser flow."""
    return {
        "fulfill_method": FULFILL,
        "is_catering": False,
        "items": cart_items(),
        "special_instructions": None,
        "tip": None,
        "promo_code": None,
        "restaurant_id": RESTAURANT_ID,
        "when": WHEN,                              # None = ASAP
        "menu_id": menu_id,
        "meta": {"channel": None, "marketplace": {"id": "2", "x_id": None}},
        "tips": {
            "managed_delivery_tip": {"managed_delivery_tip_percentage": 0, "managed_delivery_tip_amount": 0},
            "restaurant_tip":       {"restaurant_tip_percentage": 0,       "restaurant_tip_amount": 0},
        },
        "include_single_use_items": False,
        "customer": {
            "email": me["email"],
            "first_name": me["first_name"],
            "id": me["id"],
            "last_name": me["last_name"],
            "phone": {"number": phone},
            "rewards_opt_in": True,
            "delivery": ({"address": DELIVERY_ADDRESS} if FULFILL == "delivery" else None),
            "billing": None,
        },
    }

def attach_billing(body, pan, brand, exp_m, exp_y, cvc, zip_):
    pan_clean = pan.replace(" ", "")
    body["customer"]["billing"] = {
        "card": {
            "address":    {"zip": zip_},
            "cvv":        str(cvc),
            "exp_month":  int(exp_m),
            "exp_year":   int(exp_y),
            "id":         None,
            "is_visible": True,
            "last_four":  pan_clean[-4:],
            "number":     pan_clean,
            "type":       brand,
            "type_id":    BRAND_TYPE_ID.get(brand, "1"),
        },
    }

# ---------------------------------------------------------------------------
# Browser-side fetch — called from Python, executes inside the page.
# Returns {status, body}. The browser's own fetch pulls cookies, JA3, UA, etc.
# ---------------------------------------------------------------------------

JS_FETCH = """
async ({ method, path, body }) => {
  // Per HAR capture 2026-10-16: real browser uses version=6.0 on /order,
  // version=3.0 on everything else. Pick accept version per-path.
  const ver = path === '/api/order' ? '6.0' : '3.0';
  const r = await fetch("https://api.chownow.com" + path, {
    method,
    credentials: "include",
    headers: {
      "Accept":        "application/json version=" + ver + ";",
      "Content-Type":  "application/json; charset=UTF-8",
      "X-CN-App-Info": "Marketplace-Web/5.211.0",
    },
    body: body == null ? undefined : JSON.stringify(body),
  });
  let parsed = null;
  const text = await r.text();
  try { parsed = JSON.parse(text); } catch(e) {}
  return { status: r.status, body: parsed || text.slice(0, 500) };
}
"""

STEALTH_INIT = """
// Common anti-detection fixes
Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
window.chrome = window.chrome || { runtime: {} };
Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
Object.defineProperty(navigator, 'plugins', { get: () => [1,2,3,4,5] });
// WebGL vendor/renderer spoof so it doesn't say "SwiftShader" (headless signal)
const getParameter = WebGLRenderingContext.prototype.getParameter;
WebGLRenderingContext.prototype.getParameter = function (p) {
  if (p === 37445) return 'Intel Inc.';
  if (p === 37446) return 'Intel Iris OpenGL Engine';
  return getParameter.call(this, p);
};
"""

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dry-run", action="store_true", help="Quote; do not place.")
    ap.add_argument("--headed",  action="store_true", help="Visible window.")
    ap.add_argument("--proxy",   default=os.environ.get("PCB_PROXY"),
                    help="Proxy URL, e.g. http://user:pass@rp.evomi.com:1000. "
                         "Also honored via env PCB_PROXY. Routes both the Stripe "
                         "pre-flight and the Playwright/patchright browser.")
    args = ap.parse_args()

    print("Card entry — stays local.\n")
    card_number  = input("  card number  : ").strip()
    exp_m, exp_y = parse_exp_mmyy(input("  exp (MM/YY)  : ").strip())
    cvc          = getpass.getpass("  cvc (hidden) : ").strip()
    postal       = input("  billing zip  : ").strip() or "94904"
    brand        = detect_brand(card_number)
    pan_clean    = card_number.replace(" ", "")
    print(f"\n  card: {brand} ••••{pan_clean[-4:]}  bill zip: {postal}")
    # BIN 410039 = Privacy.com / Lithic virtual cards. ChowNow + Stripe reject these.
    if pan_clean.startswith("410039"):
        print("  !!  BIN 410039 is Privacy.com virtual cards — ChowNow / Stripe reject")
        print("      this BIN with cvv_valid:false (code 41000). Use a mainstream Visa/MC.")

    if args.proxy:
        print(f"\n[*] Proxy set — {parse_proxy(args.proxy)[0]}")
        # Verify proxy works + show egress IP + geolocation
        try:
            ipj = requests.get("https://api.ipify.org?format=json", proxies=requests_proxies(args.proxy), timeout=15).json()
            geoj = requests.get(f"http://ip-api.com/json/{ipj['ip']}", proxies=requests_proxies(args.proxy), timeout=15).json()
            print(f"    egress IP: {ipj['ip']}  ({geoj.get('city','?')}, {geoj.get('regionName','?')}, {geoj.get('country','?')}, ISP={geoj.get('isp','?')})")
        except Exception as e:
            print(f"    !! proxy check failed: {e}")
            return 1

    print("\n[*] Stripe pre-flight (card checks before any ChowNow calls)...")
    ok, msg = stripe_preflight(card_number, exp_m, exp_y, cvc, postal, proxy_url=args.proxy)
    print(f"    {msg}")
    if ok is False and "REJECTED" in msg:
        print("    Stripe rejected the card BEFORE ChowNow even sees it. Fix and re-run.")
        return 1
    # Soft issues (cvc_check=fail, zip_check=fail, prepaid, non-US) are warnings,
    # not hard stops — ChowNow may or may not care.

    with sync_playwright() as p:
        print(f"\n[1/5] launching Chromium via {_PW_FLAVOR} ({'headed' if args.headed else 'headless'})...")
        proxy_server, proxy_user, proxy_pass = parse_proxy(args.proxy)
        proxy_kwargs = {}
        if proxy_server:
            proxy_kwargs["proxy"] = {"server": proxy_server}
            if proxy_user: proxy_kwargs["proxy"]["username"] = proxy_user
            if proxy_pass: proxy_kwargs["proxy"]["password"] = proxy_pass
        if _PW_FLAVOR == "patchright":
            context = p.chromium.launch_persistent_context(
                user_data_dir=os.path.join(os.path.dirname(__file__), ".pcb_profile"),
                channel="chrome",
                headless=not args.headed,
                viewport={"width": 1920, "height": 1080},
                locale="en-US", timezone_id="America/Los_Angeles",
                no_viewport=False,
                **proxy_kwargs,
            )
            browser = context.browser
        else:
            browser = p.chromium.launch(
                headless=not args.headed,
                args=[
                    "--headless=new",
                    "--disable-blink-features=AutomationControlled",
                    "--disable-features=IsolateOrigins,site-per-process",
                ],
                **proxy_kwargs,
            )
            context = browser.new_context(
                user_agent=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                            "AppleWebKit/537.36 (KHTML, like Gecko) "
                            "Chrome/129.0.0.0 Safari/537.36"),
                viewport={"width": 1920, "height": 1080},
                locale="en-US", timezone_id="America/Los_Angeles",
                device_scale_factor=1, has_touch=False, is_mobile=False,
            )
            context.add_init_script(STEALTH_INIT)

        page = context.new_page()
        t0 = time.time()
        # Start on the marketplace home like a real user would
        print(f"[2/5] seeding Sift fingerprint (home -> restaurant, mouse + scroll)...")
        page.goto("https://www.chownow.com/", wait_until="domcontentloaded", timeout=30_000)
        for _ in range(4):
            x = random.randint(100, 1800); y = random.randint(100, 900)
            try: page.mouse.move(x, y, steps=random.randint(5, 20))
            except Exception: pass
            try: page.mouse.wheel(0, random.randint(50, 300))
            except Exception: pass
            page.wait_for_timeout(random.randint(400, 800))
        # Then navigate to the restaurant page
        page.goto(WARMUP_URL, wait_until="domcontentloaded", timeout=30_000)
        for _ in range(6):
            x = random.randint(100, 1800); y = random.randint(100, 900)
            try: page.mouse.move(x, y, steps=random.randint(5, 20))
            except Exception: pass
            try: page.mouse.wheel(0, random.randint(50, 300))
            except Exception: pass
            page.wait_for_timeout(random.randint(400, 800))

        # Confirm Sift beaconed
        beacons = page.evaluate("""() => performance.getEntriesByType('resource')
            .filter(r => /hexagon-analytics|siftscience/.test(r.name))
            .map(r => r.name.slice(0,220))""")
        print(f"       Sift beacons: {len(beacons)}  (want ≥1)")
        if not beacons:
            print("       !! no Sift beacon detected — the fraud score will likely bite")

        # From here on, every fetch runs INSIDE the page, carrying full browser state.
        def call(method, path, body=None, retries=3):
            last_err = None
            for attempt in range(retries):
                try:
                    return page.evaluate(JS_FETCH, {"method": method, "path": path, "body": body})
                except Exception as e:
                    last_err = e
                    if attempt < retries - 1:
                        page.wait_for_timeout(1200)
            raise last_err

        # ---- Signup ----
        email, password, first, last, phone = random_credentials()
        print(f"\n[3/9] signup {email}  ({first} {last})")
        r = call("POST", API_PATHS["signup"], {
            "email": email, "password": password,
            "first_name": first, "last_name": last,
        })
        me = r["body"] if isinstance(r["body"], dict) else {}
        if "id" not in me:
            print(f"  signup failed: status={r['status']} body={r['body']}"); context.close(); return 1
        print(f"       id={me['id']}")
        page.wait_for_timeout(random.randint(2000, 4000))

        # ---- Browse (deep humanish pattern, not just a signup -> order sprint) ----
        print(f"[4/9] browsing (restaurant, rewards, recently-ordered, manifest, discovery)...")
        call("GET",  "/api/restaurant/" + RESTAURANT_ID)
        page.wait_for_timeout(random.randint(400, 900))
        call("GET",  "/api/customer/me")
        page.wait_for_timeout(random.randint(600, 1200))
        call("GET",  "/api/customer/me/rewards?restaurant_id=" + RESTAURANT_ID + "&include_opt_outs=true")
        call("GET",  "/api/customer/me/restaurant/" + RESTAURANT_ID + "/recently-ordered")
        call("GET",  "/api/web/manifest")
        page.wait_for_timeout(random.randint(1500, 3000))

        # ---- Save payment card FIRST with preauthorize ----
        # This is the key change vs. earlier revs: real returning users have their
        # card on file BEFORE they order. Preauth runs a $0/$1 verification against
        # Stripe, which (a) tells us immediately if the card has a problem and
        # (b) lowers Radar score on the subsequent /order charge (reauth of a
        # recently-successful card on an authed account is a very different trace
        # than an inline first-time card on a fresh account).
        print(f"[5/9] save card to account via /customer/me/billing-card (preauthorize)...")
        card_add_body = {
            "is_optout": False,
            "address":   {"zip": postal},
            "cvv":       str(cvc),
            "exp_month": int(exp_m),
            "exp_year":  int(exp_y),
            "number":    card_number.replace(" ", ""),
            "type":      brand,
            "preauthorize": True,
        }
        r = call("PUT", f"/api/customer/me/billing-card", card_add_body)
        saved_card = r["body"] if isinstance(r["body"], dict) else {}
        saved_card_id = None
        # Server returns the saved card record. Pull its id.
        if isinstance(saved_card, dict):
            if saved_card.get("id"):
                saved_card_id = saved_card.get("id")
            else:
                for c in (saved_card.get("cards") or saved_card.get("billing", {}).get("cards", [])):
                    if c.get("last_four") == card_number.replace(" ","")[-4:]:
                        saved_card_id = c.get("id"); break
        if r.get("status", 200) >= 400 or not saved_card_id:
            print(f"       card-save response: status={r.get('status')} body-head={json.dumps(saved_card)[:300]}")
            print(f"       falling back to inline card on /order")
        else:
            print(f"       saved card id={saved_card_id} (preauth passed)")
        page.wait_for_timeout(random.randint(1200, 2400))

        # Fetch /customer/me so the saved-card is in our local view of the user
        r = call("GET", "/api/customer/me")
        me_full = r["body"] if isinstance(r["body"], dict) else me

        # ---- Menu ----
        r = call("GET", API_PATHS["menu"])
        menu_id = (r["body"] or {}).get("id")
        print(f"[6/9] menu_id={menu_id}")
        page.wait_for_timeout(random.randint(1500, 3000))

        # ---- Validate (2 iterations like a user tweaking cart) ----
        body = build_body(me_full, menu_id, phone)
        for i in range(2):
            r = call("POST", API_PATHS["validate"], body)
            page.wait_for_timeout(random.randint(600, 1200))
        quote = r["body"] if isinstance(r["body"], dict) else {}
        totals = {k: quote.get(k) for k in ("item_total","subtotal","sales_tax","delivery_fee","total","total_due")}
        print(f"[7/9] quote: {json.dumps(totals)}")
        validated_total = quote.get("total_due") or quote.get("total")

        # Item recommendations (fired by SPA after cart has items) + rewards re-check
        try:
            call("POST", f"/api/restaurant/{RESTAURANT_ID}/item-recommendations",
                 {"menu_id": menu_id, "selected_item_ids": [i["id"] for i in body["items"]]})
        except Exception:
            pass
        call("GET", "/api/customer/me/rewards?restaurant_id=" + RESTAURANT_ID + "&include_opt_outs=true")
        page.wait_for_timeout(random.randint(2000, 4000))

        if saved_card_id:
            # Reference the saved+pre-authed card by id, not inline details.
            # This matches the "returning user with saved card" flow which gets
            # a lower Radar score than inline-first-time-card.
            body["customer"]["billing"] = {
                "card": {
                    "id": saved_card_id,
                    "type": brand,
                    "exp_month": int(exp_m),
                    "exp_year":  int(exp_y),
                    "is_visible": True,
                    "last_four": card_number.replace(" ","")[-4:],
                    "type_id": BRAND_TYPE_ID.get(brand, "1"),
                    "address": {"zip": postal},
                }
            }
            print(f"       using saved card id={saved_card_id}")
        else:
            attach_billing(body, card_number, brand, exp_m, exp_y, cvc, postal)
            print(f"       inline card (saved-card path unavailable)")
        body["validated_total"] = validated_total

        if args.dry_run:
            print(f"\n[8/9] --dry-run — total ${validated_total}. Not placing.")
            context.close(); return 0

        print(f"\n[8/9] About to place ${validated_total}  acc={email}  card={brand}••••{card_number.replace(' ','')[-4:]}")
        if not args.yes:
            if input("Type YES to place: ").strip() != "YES":
                print("Aborted."); context.close(); return 0

        # Humanish pause before submit — a user takes 3-6s between "review order" and clicking Place
        page.wait_for_timeout(random.randint(3000, 6000))

        # menu_id blanked per real-browser capture (validate takes it, order rejects it).
        print(f"[9/9] POST /api/order...")
        body["menu_id"] = ""
        r = call("POST", API_PATHS["order"], body)
        card_number = "x" * 16; cvc = "***"
        result = r["body"] if isinstance(r["body"], dict) else {"__text": r["body"]}
        print(f"status={r['status']}")
        print(json.dumps(result, indent=2)[:2500])

        errs = result.get("errors") or []
        order_id = result.get("id") or (errs[0].get("object_id") if errs else None)
        status   = result.get("status")
        code     = errs[0].get("code") if errs else None

        # If payment didn't clean-succeed, fetch the full order record — Stripe's
        # actual decline code/message is stored on the order, not in /order's response envelope.
        detail = None
        if order_id and status and status.lower() in ("declined", "payment due"):
            print(f"\n   fetching order detail for decline reason...")
            for ep in (f"/api/order/{order_id}", f"/api/history/{order_id}"):
                try:
                    dr = call("GET", ep)
                    if isinstance(dr.get("body"), dict) and dr["body"].get("id") == str(order_id):
                        detail = dr["body"]; print(f"   detail from {ep}"); break
                except Exception:
                    pass

        def pull_decline(d):
            """Walk the order detail for anything that smells like a decline reason."""
            if not isinstance(d, dict): return []
            hits = []
            def walk(x, path=""):
                if isinstance(x, dict):
                    for k, v in x.items():
                        p = f"{path}.{k}" if path else k
                        kl = k.lower()
                        if any(key in kl for key in ("decline","failure","risk","gateway","processor","stripe","cvv_valid","charge_status","payment_history","payment_attempts","last_payment_error","error_code","error_message")):
                            if v not in (None, "", [], {}, False):
                                hits.append((p, v))
                        walk(v, p)
                elif isinstance(x, list):
                    for i, v in enumerate(x): walk(v, f"{path}[{i}]")
            walk(d)
            return hits

        print()
        if order_id and status and status.lower() in ("received","accepted","pending","submitted","active"):
            print(f"✓ ORDER PLACED  id={order_id}  status={status}  total=${result.get('total_due')}")
        elif code == "34001":
            print("✗ MENU EXPIRED between validate and order calls. Just re-run.")
        elif order_id and status and status.lower() == "payment due":
            print(f"⚠ PAYMENT DUE  id={order_id}")
            print("   Sift accepted. Stripe/bank soft-declined the charge.")
            print(f"   You should see an attempted auth of ${result.get('total_due')} on the card.")
            if detail:
                hits = pull_decline(detail)
                if hits:
                    print("\n   decline signals from GET /api/order/{id}:")
                    for p, v in hits[:40]:
                        print(f"     {p:<50s} = {json.dumps(v)[:220]}")
                else:
                    print("\n   no decline fields surfaced; full order dump:")
                    print(json.dumps(detail, indent=2)[:3500])
        elif order_id and (status == "Declined" or code == "41000"):
            print(f"✗ ORDER DECLINED  id={order_id}  code={code}")
            if detail:
                hits = pull_decline(detail)
                if hits:
                    print("\n   decline signals from GET /api/order/{id}:")
                    for p, v in hits[:40]:
                        print(f"     {p:<50s} = {json.dumps(v)[:220]}")
        elif order_id:
            print(f"? id={order_id} status={status} errs={errs}")
        else:
            print(f"✗ No order id. errors={errs}")
        print(f"total time: {time.time()-t0:.1f}s")

        try:
            context.close()
        except Exception:
            pass
        try:
            if browser: browser.close()
        except Exception:
            pass
        return 0

if __name__ == "__main__":
    sys.exit(main())
