#!/usr/bin/env bash
# Replay-sized probe of a private ChowNow endpoint.
# Captures: method, URL, request headers, status, response headers, response body.
# usage: ./probe.sh METHOD URL [channel]   channel = Marketplace-Web | Direct-Web | Yelp-Web
set -euo pipefail

METHOD="${1:-GET}"
URL="${2:?url required}"
CHANNEL="${3:-Marketplace-Web}"
# slugify URL -> filename-safe
SAFE="$(echo -n "$URL" | sed -E 's#https?://##; s#[^A-Za-z0-9]+#_#g')"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_DIR="chownow-api-spec/examples/${STAMP}_${METHOD}_${SAFE}"
mkdir -p "$OUT_DIR"

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36'

# -D dumps response headers; -o saves body; -w prints status to stderr.
curl -sS -L --max-time 30 \
  -X "$METHOD" \
  -A "$UA" \
  -H 'Accept: application/json version=3.0;' \
  -H 'Content-Type: application/json; charset=UTF-8' \
  -H "X-CN-App-Info: ${CHANNEL}/5.211.0" \
  -H 'Origin: https://www.chownow.com' \
  -H 'Referer: https://www.chownow.com/' \
  -D "${OUT_DIR}/response_headers.txt" \
  -o "${OUT_DIR}/response_body.json" \
  -w "status=%{http_code} size=%{size_download} time=%{time_total}s type=%{content_type}\n" \
  "$URL"

echo "--> ${OUT_DIR}"
head -1 "${OUT_DIR}/response_headers.txt"
head -c 400 "${OUT_DIR}/response_body.json"; echo
