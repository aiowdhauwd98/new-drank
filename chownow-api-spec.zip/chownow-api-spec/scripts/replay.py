#!/usr/bin/env python3
"""End-to-end replay of ChowNow's private web API — anonymous flows only.

Verifies the endpoints marked [VERIFIED by replay] in endpoints/private-web-api.md.
Does NOT exercise authenticated writes (signin, signup, order submit) — see
UNKNOWNS.md #1 for the resolution path.

Dependencies: curl_cffi (preferred, uses Chrome TLS fingerprint to bypass Cloudflare's
JA3 heuristic) or httpx (fallback — may hit 403 on some endpoints).

    pip install curl_cffi
    # or, degraded:
    pip install httpx

Usage:
    python replay.py --flow discovery
    python replay.py --flow menu --restaurant 35
    python replay.py --flow error-shapes
    python replay.py --flow preflight
    python replay.py --flow all

Exit code is non-zero when any step mismatches the documented shape, so this
script doubles as a regression check.
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

try:
    from curl_cffi import requests as _curl
    _IMPL = "curl_cffi"
except ImportError:
    _curl = None
    try:
        import httpx
        _IMPL = "httpx"
    except ImportError:
        print("Install one of: pip install curl_cffi   OR   pip install httpx", file=sys.stderr)
        sys.exit(2)

BASE = "https://api.chownow.com/api"
APP_VERSION = "5.211.0"

# ---- shared request shape ----------------------------------------------------

class Client:
    """Minimal client wrapper that works over curl_cffi (preferred) or httpx."""
    def __init__(self, channel: str = "Marketplace-Web"):
        self.channel = channel
        self.headers = {
            "Accept": "application/json version=3.0;",
            "Content-Type": "application/json; charset=UTF-8",
            "X-CN-App-Info": f"{channel}/{APP_VERSION}",
            "Origin": "https://www.chownow.com",
            "Referer": "https://www.chownow.com/",
        }
        if _IMPL == "curl_cffi":
            self._sess = _curl.Session(impersonate="chrome120")
        else:
            self._sess = httpx.Client(
                timeout=httpx.Timeout(15.0),
                follow_redirects=True,
                headers={**self.headers,
                         "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                                       "Chrome/120.0.0.0 Safari/537.36"},
            )
    def __enter__(self): return self
    def __exit__(self, *a): self._sess.close()

    def _request(self, method: str, path: str, params=None, headers=None):
        url = BASE + path
        all_hdrs = {**self.headers, **(headers or {})}
        if _IMPL == "curl_cffi":
            return self._sess.request(method, url, params=params, headers=all_hdrs, timeout=15)
        return self._sess.request(method, url, params=params, headers=all_hdrs)

    def get(self, path: str, params=None): return self._request("GET", path, params=params)
    def options(self, path: str, headers=None): return self._request("OPTIONS", path, headers=headers)

def status_line(method: str, path: str, params, resp) -> str:
    q = ""
    if params:
        q = "?" + "&".join(f"{k}={v}" for k, v in (params.items() if isinstance(params, dict) else params))
    size = len(getattr(resp, "content", b"")) or len(getattr(resp, "text", "") or "")
    ctype = resp.headers.get("content-type", "?")
    reason = getattr(resp, "reason", getattr(resp, "reason_phrase", ""))
    return (f"  {method:6s} /api{path}{q}\n"
            f"    -> {resp.status_code} {reason}  ({size:,}B, {ctype})")

def expect(ok: bool, msg: str, fatal: bool = True) -> bool:
    marker = "OK  " if ok else "FAIL"
    print(f"    [{marker}] {msg}")
    if not ok and fatal:
        sys.exit(1)
    return ok

# ---- flows -------------------------------------------------------------------

def flow_discovery(client: Client, lat: float, lon: float, limit: int = 30) -> None:
    print("\n=== flow: discovery ===")

    r = client.get("/web/manifest")
    print(status_line("GET", "/web/manifest", None, r))
    expect(r.status_code == 200, "manifest returns 200")
    manifest = r.json()
    expect("payment_processor_key" in manifest, "manifest has payment_processor_key")
    expect(manifest["payment_processor_key"].startswith("pk_"), "manifest payment_processor_key is a Stripe-shaped key")

    params = {"pf": 1, "aggs": "cuisines", "u_lat": lat, "u_lon": lon, "limit": limit}
    r = client.get("/restaurant", params=params)
    print(status_line("GET", "/restaurant", params, r))
    expect(r.status_code == 200, "discovery returns 200")
    body = r.json()
    expect(isinstance(body.get("restaurants"), list), "body.restaurants is a list")
    expect(isinstance(body.get("total"), int) and body["total"] >= 0, "body.total is a non-negative int")
    expect("cuisines" in body.get("aggregations", {}), "aggregations.cuisines present")
    expect(body.get("version", "").startswith("3."), "response version is 3.x")

    print(f"    total near point: {body['total']} restaurants")
    print(f"    first 3: " + ", ".join(f"{r['name']} ({r['id']})" for r in body["restaurants"][:3]))

    params = {"u_lat": lat, "u_lon": lon, "facets": "is_favorite,is_new,low_cost_delivery"}
    r = client.get("/restaurant/facets", params=params)
    print(status_line("GET", "/restaurant/facets", params, r))
    expect(r.status_code == 200, "facets returns 200")
    expect(isinstance(r.json().get("facets"), list), "body.facets is a list")

def flow_menu(client: Client, location_id: str) -> None:
    print(f"\n=== flow: menu - restaurant {location_id} ===")

    r = client.get(f"/restaurant/{location_id}")
    print(status_line("GET", f"/restaurant/{location_id}", None, r))
    expect(r.status_code == 200, "restaurant returns 200")
    rest = r.json()
    expect(rest["id"] == location_id, "response.id matches path")
    expect("fulfillment" in rest, "restaurant has fulfillment")
    expect(set(rest["fulfillment"].keys()) >= {"pickup", "delivery"}, "fulfillment has pickup and delivery")
    expect(rest.get("payment_processor_id") in ("3", None), "payment_processor_id looks sane")

    print(f"    restaurant: {rest['name']}  tax={rest['tax_rate']}")

    r = client.get("/customer/me")
    print(status_line("GET", "/customer/me", None, r))
    expect(r.status_code == 404, "customer/me anonymous returns 404")
    expect("warnings" in r.json(), "customer/me anonymous body has warnings[]")

    r = client.get(f"/restaurant/{location_id}/menu")
    print(status_line("GET", f"/restaurant/{location_id}/menu", None, r))
    expect(r.status_code == 200, "menu returns 200")
    menu = r.json()
    expect("menu_categories" in menu, "menu has menu_categories")
    expect("_" in menu["id"], "menu.id is a versioned id (contains _)")
    print(f"    menu id: {menu['id']}")
    print(f"    categories ({len(menu['menu_categories'])}): "
          + ", ".join(c["name"] for c in menu["menu_categories"][:5]))

def flow_error_shapes(client: Client) -> None:
    print("\n=== flow: error shapes ===")

    r = client.get("/")
    print(status_line("GET", "/", None, r))
    expect(r.status_code == 501, "GET /api/ returns 501")
    expect(r.json()["errors"][0]["code"].startswith("501"), "501 error has code '501 Not Implemented'")

    r = client.get("/customer")
    print(status_line("GET", "/customer", None, r))
    expect(r.status_code == 500, "GET /api/customer returns 500 (exists, wrong method)")
    expect(r.json()["errors"][0]["reason"] == "Generic exception", "500 error has reason 'Generic exception'")

    r = client.get("/order/validate")
    print(status_line("GET", "/order/validate", None, r))
    expect(r.status_code == 404, "GET /api/order/validate returns 404 (exists, needs POST)")
    expect(r.json()["errors"][0]["reason"] == "API logic validation", "404 reason is 'API logic validation'")

def flow_cors_preflight(client: Client) -> None:
    """Preflight-probe every path that the discovery pass identified as a write."""
    print("\n=== flow: CORS preflight enumeration ===")
    paths = [
        "customer/signin", "customer/signup", "customer/exists",
        "customer/forgot-password", "customer/reset-password", "customer/password",
        "customer/session", "customer/validate", "customer/sso",
        "customer/google", "customer/apple", "customer/magic-link",
        "customer/addresses", "customer",
        "order", "order/submit", "order/create",
        # negative controls
        "login", "signin", "signup", "auth/login", "auth/signin", "session",
    ]
    expected_200 = {
        "customer/signin", "customer/signup", "customer/exists",
        "customer/forgot-password", "customer/reset-password", "customer/password",
        "customer/session", "customer/validate", "customer/sso",
        "customer/google", "customer/apple", "customer/magic-link",
        "customer/addresses", "customer", "order", "order/submit", "order/create",
    }
    for p in paths:
        r = client.options(
            f"/{p}",
            headers={
                "Origin": "https://www.chownow.com",
                "Access-Control-Request-Method": "POST",
                "Access-Control-Request-Headers": "content-type,accept,x-cn-app-info",
            },
        )
        verdict = "allowed" if r.status_code == 200 else f"{r.status_code}"
        marker = "OK" if (r.status_code == 200) == (p in expected_200) else "DRIFT"
        print(f"  [{marker}] OPTIONS /{p:<28s}  -> {verdict}")

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--flow", default="all",
                    choices=["discovery", "menu", "error-shapes", "preflight", "all"])
    ap.add_argument("--lat", type=float, default=34.0549076)
    ap.add_argument("--lon", type=float, default=-118.242643)
    ap.add_argument("--restaurant", default="35")
    ap.add_argument("--channel", default="Marketplace-Web",
                    choices=["Marketplace-Web", "Direct-Web", "Yelp-Web"])
    args = ap.parse_args()

    print(f"HTTP impl: {_IMPL}")
    with Client(args.channel) as client:
        if args.flow in ("discovery", "all"):
            flow_discovery(client, args.lat, args.lon)
        if args.flow in ("menu", "all"):
            flow_menu(client, args.restaurant)
        if args.flow in ("error-shapes", "all"):
            flow_error_shapes(client)
        if args.flow in ("preflight", "all"):
            flow_cors_preflight(client)

    print("\nAll checks passed.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
