#!/usr/bin/env python3
"""Grep a minified JS bundle for API-flow tokens of interest inside string literals.

Pure static analysis of a locally saved JS file. Used to map the SPA's REST paths
to the private web API during API discovery / documentation work.
"""
from __future__ import annotations
import re, sys, pathlib

if len(sys.argv) < 2:
    print("usage: token_search.py <bundle.js>", file=sys.stderr); sys.exit(2)

text = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8", errors="replace")

TOKENS = [
    "customer/login", "customer/signup", "customer/register", "customer/forgot",
    "customer/reset", "customer/session", "customer/profile",
    "auth/login", "auth/signin", "auth/signup", "auth/session",
    "login", "signin", "signup", "register", "forgot", "reset",
    "pwd", "credential",
    "session",
    "order/submit", "order/place", "order/create", "order/validate",
    "cart", "address", "guest", "membership",
    "promo", "coupon",
    "fulfillment", "quote", "track",
    "billing-card", "payment",
    "stripe", "spreedly", "braintree",
]

hits = {}
for tok in TOKENS:
    # match the token anywhere inside a string literal (single, double, backtick)
    pat = re.compile(r"""(["'`])([^"'`]{0,80}""" + re.escape(tok) + r"""[^"'`]{0,80})\1""")
    seen = set()
    for m in pat.finditer(text):
        s = m.group(2)
        if "<" in s or ">" in s or "  " in s or len(s) > 100:
            continue
        if s in seen: continue
        seen.add(s)
    if seen:
        hits[tok] = sorted(seen)

for tok, items in hits.items():
    print(f"== {tok} ({len(items)}) ==")
    for it in items[:20]:
        print(f"  {it}")
    print()
