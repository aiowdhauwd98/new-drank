#!/usr/bin/env python3
"""
End-to-end order placement against ChowNow — endpoint-only, no browser.

How payment works:
  ChowNow's SPA bundle does NOT call Stripe.createPaymentMethod anywhere, and the
  `pk_live_...` key in /api/web/manifest is a fallback for Apple/Google Pay only.
  The regular card flow sends the raw PAN to the ChowNow server as
  `customer.billing.card.number` (over TLS); the server tokenizes with Stripe
  server-side. So this script skips Stripe entirely.

Does, in order:
  1. Prompts for raw card details LOCALLY
  2. Logs in to ChowNow with the test account
  3. Builds the order body
  4. Validates the cart (quote)
  5. Attaches billing with the raw card
  6. Fires POST /api/order with a one-shot confirmation

Dependencies:  pip install requests

Usage:  python place_order.py
        python place_order.py --dry-run
        python place_order.py --card 4242... --exp-month 12 --exp-year 2030 --cvc 123 --postal 90210
"""
from __future__ import annotations
import argparse
import getpass
import json
import re
import secrets
import string
import sys
import time
import uuid
from typing import Any, Optional

try:
    import requests
except ImportError:
    print("pip install requests", file=sys.stderr)
    sys.exit(2)

# ---------------------------------------------------------------------------
# Config — all public, pulled from ChowNow's own /api/web/manifest + captures
# ---------------------------------------------------------------------------

CHOWNOW_API      = "https://api.chownow.com/api"
STRIPE_API       = "https://api.stripe.com/v1"
STRIPE_PK        = "pk_live_1rHqZgeuWfzjo9nCVWMdRsbZUztUaNhhlxt4wHymS1kVK5MDf8dLcyjojGR487uMuZSeZyjKIraWRqrTKSoLfNzr000Bs7zTqEF"

HEADERS_WEB = {
    "Accept":        "application/json version=3.0;",
    "Content-Type":  "application/json; charset=UTF-8",
    "X-CN-App-Info": "Marketplace-Web/5.211.0",
    "Origin":        "https://www.chownow.com",
    "Referer":       "https://www.chownow.com/",
    "User-Agent":    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                     "(KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36",
}

# ---- The cart being placed. Edit here or override via CLI if desired. ------

# A fresh account is minted each run (new mailinator address + random password).
# Reusing a single long-lived test account loses the "first-time diner" 10% auto-discount
# after the first order; a fresh account gets it every time.
ACCOUNT_EMAIL_DOMAIN = "mailinator.com"
ACCOUNT_FIRST_NAME   = "Test"
ACCOUNT_LAST_NAME    = "User"

RESTAURANT_ID = "35"                       # Woodlands Market — Kentfield, CA
MENU_ID       = "121704_202610151951"      # will be refreshed live before placing
WHEN          = "202610161900"             # YYYYMMDDHHMM — 2026-10-16 19:00 local

ITEMS = [
    # Mt. Tam Crunch, no required modifiers, $16.99
    {"id": "26801454_28687426", "quantity": 1},
]

DELIVERY_ADDRESS = {
    "is_google_place":  True,
    "street_address1":  "100 College Ave",
    "street_address2":  "",
    "city":             "Kentfield",
    "state":            "CA",
    "zip":              "94904",
    "latitude":         37.9525,
    "longitude":        -122.5500,
    "country":          "USA",
    "country_alpha2":   "US",
    "geo":              "37.9525,-122.55",
    "formatted_address": "100 College Ave, Kentfield CA 94904",
}

# ---------------------------------------------------------------------------
# Card brand detection (local — no network)
# ---------------------------------------------------------------------------

def detect_brand(pan: str) -> str:
    """Return ChowNow's card.type enum string for a given PAN.

    ChowNow's enum: 'Visa', 'MasterCard', 'American Express', 'Discover', 'JCB',
    'Diners Club', 'UnionPay'. Detection by BIN prefix (plus length for some).
    """
    n = pan.replace(" ", "")
    if n.startswith("4"):
        return "Visa"
    if n[:2] in ("34", "37"):
        return "American Express"
    if n[:4] in ("6011",) or n[:2] in ("65",) or n[:3] in ("644","645","646","647","648","649"):
        return "Discover"
    if n[:2] in ("35",):
        return "JCB"
    if n[:3] in ("300","301","302","303","304","305") or n[:2] in ("36","38","39"):
        return "Diners Club"
    if n[:2] == "62":
        return "UnionPay"
    if 51 <= int(n[:2] or "0") <= 55:
        return "MasterCard"
    if 2221 <= int(n[:4] or "0") <= 2720:
        return "MasterCard"
    return "Visa"  # safest default

# ---------------------------------------------------------------------------
# ChowNow auth + order flow
# ---------------------------------------------------------------------------

def login(sess: requests.Session, email: str, password: str) -> dict:
    r = sess.post(f"{CHOWNOW_API}/customer/login",
                  json={"email": email, "password": password},
                  headers=HEADERS_WEB, timeout=15)
    r.raise_for_status()
    me = r.json()
    print(f"  logged in as {me['email']}  (id {me['id']})")
    return me

def random_credentials() -> tuple[str, str]:
    """Mint a fresh mailinator email + strong random password."""
    ts  = int(time.time())
    tag = secrets.token_hex(4)
    email = f"cn-{ts}-{tag}@{ACCOUNT_EMAIL_DOMAIN}"
    # 20 char password covering all four classes
    alphabet = string.ascii_letters + string.digits + "!@#$%&*-_"
    password = "".join(secrets.choice(alphabet) for _ in range(20)) + "A1!"
    return email, password

def signup(sess: requests.Session, email: str, password: str) -> dict:
    """POST /api/customer — creates account, server returns the Customer object
    and sets the authed 30-day session cookie on the response.
    """
    r = sess.post(f"{CHOWNOW_API}/customer",
                  json={"email": email, "password": password,
                        "first_name": ACCOUNT_FIRST_NAME, "last_name": ACCOUNT_LAST_NAME},
                  headers=HEADERS_WEB, timeout=15)
    if r.status_code != 201:
        print(f"  signup failed: {r.status_code} {r.text[:300]}", file=sys.stderr)
        sys.exit(1)
    me = r.json()
    print(f"  created account {me['email']}  (id {me['id']})")
    return me

def parse_exp_mmyy(raw: str) -> tuple[int, int]:
    """Parse 'MM/YY' or 'MM/YYYY' into (month, 4-digit-year)."""
    s = raw.strip().replace(" ", "")
    m = re.match(r"^(\d{1,2})\s*[/\-]\s*(\d{2}|\d{4})$", s)
    if not m:
        raise ValueError(f"expected MM/YY or MM/YYYY, got: {raw!r}")
    month = int(m.group(1))
    year  = int(m.group(2))
    if year < 100:  # two-digit YY
        year += 2000
    if not (1 <= month <= 12):
        raise ValueError(f"month out of range: {month}")
    return month, year

def refresh_menu_id(sess: requests.Session, restaurant_id: str) -> str:
    r = sess.get(f"{CHOWNOW_API}/restaurant/{restaurant_id}/menu",
                 headers=HEADERS_WEB, timeout=15)
    r.raise_for_status()
    mid = r.json()["id"]
    print(f"  current menu_id: {mid}")
    return mid

def cart_items() -> list[dict]:
    """Build the exact per-item shape the ChowNow SPA emits."""
    out = []
    for it in ITEMS:
        out.append({
            "id":                   it["id"],
            "quantity":             int(it.get("quantity", 1)),
            "recipient":            None,
            "special_instructions": None,
            "client_id":            str(int(time.time() * 1_000_000)),
            "modifier_categories":  it.get("modifier_categories", []),
        })
    return out

def build_order_body(me: dict, menu_id: str, phone: str, fulfill_method: str = "delivery") -> dict:
    customer: Optional[dict]
    if fulfill_method == "delivery":
        customer = {
            "email":      me["email"],
            "first_name": me["first_name"],
            "last_name":  me["last_name"],
            "phone":      {"number": phone},                 # NESTED, not flat
            "id":         me["id"],
            "delivery":   { "address": DELIVERY_ADDRESS },
            "billing":    None,                              # filled in by attach_billing()
        }
    else:
        customer = None
    return {
        "fulfill_method":           fulfill_method,
        "is_catering":              False,
        "items":                    cart_items(),
        "special_instructions":     None,
        "tip":                      None,
        "promo_code":               None,
        "restaurant_id":            RESTAURANT_ID,
        "when":                     WHEN,
        "menu_id":                  menu_id,
        "meta":                     { "channel": None },
        "tips": {
            "managed_delivery_tip": None,
            "restaurant_tip":       None,
        },
        "include_single_use_items": False,
        "customer":                 customer,
    }

def attach_billing(body: dict, card_number: str, brand: str, exp_month: int, exp_year: int,
                   cvc: str, postal_code: str) -> None:
    """Fill customer.billing with the raw card data + billing postal.

    ChowNow's SPA bundle has no client-side Stripe tokenization — raw PAN goes
    to the ChowNow server over TLS; they tokenize server-side. So `card.number`
    is the actual digits, not a `pm_...`.
    """
    body["customer"]["billing"] = {
        "address": {"zip": postal_code},
        "card": {
            "type":      brand,
            "number":    card_number.replace(" ", ""),
            "cvv":       str(cvc),
            "exp_month": int(exp_month),
            "exp_year":  int(exp_year),
            "address":   {"zip": postal_code},
        },
    }

def validate_order(sess: requests.Session, body: dict) -> dict:
    r = sess.post(f"{CHOWNOW_API}/order/validate", json=body, headers=HEADERS_WEB, timeout=15)
    out = r.json()
    errs = out.get("errors") or []
    if errs:
        print(f"  validate returned errors: {errs}")
    totals = {k: out.get(k) for k in
              ("item_total","subtotal","sales_tax","delivery_fee","service_fee","gratuity","total","total_due")}
    print(f"  quote: {json.dumps(totals)}")
    return out

def place_order(sess: requests.Session, body: dict, validated_total: float) -> dict:
    """Fire POST /api/order. Billing is already attached to body['customer']['billing']
    via attach_billing(). The server exchanges `card.number` (the Stripe pm_... id)
    with Stripe server-side to charge.
    """
    body = dict(body)
    body["validated_total"] = validated_total
    r = sess.post(f"{CHOWNOW_API}/order", json=body, headers=HEADERS_WEB, timeout=30)
    print(f"  POST /order -> {r.status_code}")
    try:
        return r.json()
    except Exception:
        print(f"  non-JSON response: {r.text[:400]}")
        return {"errors": [{"code": str(r.status_code), "message": r.text[:200]}]}

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dry-run", action="store_true",
                    help="Build + validate the cart but do NOT place the order.")
    ap.add_argument("--card")
    ap.add_argument("--exp",       help="Expiry in MM/YY or MM/YYYY. Prompted if omitted.")
    ap.add_argument("--cvc")
    ap.add_argument("--postal", help="Billing zip code (your card's statement zip). Prompted if omitted.")
    ap.add_argument("--name",      default="Test User")
    ap.add_argument("--yes",       action="store_true",
                    help="Skip the final confirmation prompt. Required for scripted non-dry-run.")
    args = ap.parse_args()

    print("ChowNow endpoint-only order placement\n")

    if args.card and args.exp and args.cvc:
        card_number = args.card
        exp_m, exp_y = parse_exp_mmyy(args.exp)
        cvc = args.cvc
    else:
        print("Card entry — nothing leaves this machine except via TLS to ChowNow.\n")
        card_number = input("  card number       : ").strip()
        exp_m, exp_y = parse_exp_mmyy(input("  exp (MM/YY)       : ").strip())
        cvc         = getpass.getpass("  cvc (hidden)      : ").strip()
    if not args.postal:
        args.postal = input("  billing zip code  : ").strip() or "94904"

    brand = detect_brand(card_number)
    print(f"\n[1/5] Detected brand: {brand}  (••••{card_number.replace(' ','')[-4:]})")

    sess = requests.Session()
    print("\n[2/5] Creating a fresh ChowNow account...")
    email, password = random_credentials()
    me = signup(sess, email, password)

    print("\n[3/5] Refreshing menu_id...")
    menu_id = refresh_menu_id(sess, RESTAURANT_ID)

    # phone may come back as a flat string OR as {"number":"...","id":...} after an earlier PUT
    raw_phone = me.get("phone")
    if isinstance(raw_phone, dict):
        phone = raw_phone.get("number") or "4155551234"
    else:
        phone = raw_phone or "4155551234"
    body = build_order_body(me, menu_id, phone=phone)

    print("\n[4/5] Validating cart (quote)...")
    quote = validate_order(sess, body)
    validated_total = quote.get("total_due") or quote.get("total")

    attach_billing(body, card_number, brand, exp_m, exp_y, cvc, args.postal)

    if args.dry_run:
        print("\n[5/5] --dry-run: not placing.")
        print(f"\nquote total_due: ${validated_total}")
        # Dump a redacted body (strip card number / cvv for safety)
        import copy
        dump = copy.deepcopy(body)
        dump["validated_total"] = validated_total
        dump["customer"]["billing"]["card"]["number"] = "**** **** **** " + card_number.replace(" ","")[-4:]
        dump["customer"]["billing"]["card"]["cvv"]    = "***"
        print("\n--- body (card number + cvv redacted) ---")
        print(json.dumps(dump, indent=2)[:3500])
        return 0

    print(f"\nAbout to place order for ${validated_total} at Woodlands Market — Kentfield, CA.")
    print(f"  card: {brand} ••••{card_number.replace(' ','')[-4:]}  billing zip: {args.postal}")
    print(f"  acc:  {email}  (fresh)")
    if not args.yes:
        ok = input("Type YES to place: ").strip() == "YES"
        if not ok:
            print("Aborted.")
            return 0

    print(f"\n[5/5] POST /api/order ...")
    result = place_order(sess, body, validated_total)
    # Scrub local plaintext
    card_number = "x" * 16
    cvc = "***"
    print("\n--- response (abbreviated) ---")
    print(json.dumps(result, indent=2)[:2500])

    # Three observed response shapes for POST /api/order:
    #   A) 200 + full order object with top-level `id` and `status`
    #      (e.g. {"id":"310928824","status":"Declined", ... + errors[]})
    #   B) 400 + lean errors[] where the created order id is inside errors[0].object_id
    #      (e.g. {"errors":[{"code":"41000","object_name":"order","object_id":310928914}]})
    #   C) hard failure (schema violation, auth) with no order id anywhere
    errs = result.get("errors") or []
    order_id = (result.get("id")
                or (errs[0].get("object_id") if errs else None))
    status = result.get("status")
    code   = errs[0].get("code") if errs else None
    print()
    if order_id and status and status.lower() in ("received","accepted","pending","active","submitted"):
        print(f"✓ ORDER PLACED. id={order_id}  status={status}")
    elif order_id and (status == "Declined" or code == "41000"):
        print(f"✗ ORDER DECLINED by processor/fraud. id={order_id}")
        for e in errs:
            print(f"   code={e.get('code')}  msg={e.get('message')}")
        print()
        print("  The order record exists in Declined state. Kitchen never fires, no money moved.")
        print("  Rule out, in order:")
        print("   1. BILLING ZIP mismatch (AVS) — must be the exact zip on your card statement.")
        print("   2. BANK FRAUD HOLD — one-time $25 Marin-County restaurant on an out-of-state card")
        print("      is a common block pattern. Call the number on the back of the card and whitelist.")
        print("   3. CHOWNOW/SIFT fraud score — headless requests with no browser fingerprint are")
        print("      scored high. The clean fix is to run the LAST step in a real browser (log in to")
        print("      ChowNow in Chrome, re-build the cart there, type the card into their form). The")
        print("      script does everything up to and including the quote; only the final submit")
        print("      needs the Sift fingerprint.")
    elif order_id:
        print(f"? order id={order_id} status={status}  errs={errs}")
    else:
        print(f"✗ No order id in response. errors={errs}")

    order = result.get("order") or {}
    if order.get("id"):
        print(f"\nORDER PLACED. id={order['id']}  status={order.get('status')}")
    else:
        print(f"\nNo order id in response. errors={result.get('errors')}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
