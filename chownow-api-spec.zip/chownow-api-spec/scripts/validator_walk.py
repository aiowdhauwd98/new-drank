#!/usr/bin/env python3
"""Walk the private API's JSON Schema validator by sending empty-ish bodies and
feeding back the field names it says are missing until it stops complaining.

Each 400 response's `errors[0].field` names the NEXT required field.
Each 10207 "Additional properties" error names fields that are REJECTED.
Each 10201 "Value is not in the enum" leaks the enum.

Produces a progressive map of the body schema without ever placing a real order.
"""
from __future__ import annotations
import json, sys, time, argparse, re
try:
    import httpx as _rq
    _IMPL = "httpx"
except ImportError:
    print("pip install httpx", file=sys.stderr); sys.exit(2)
try:
    from curl_cffi import requests as _rq
    _IMPL = "curl_cffi"
except ImportError:
    pass

BASE = "https://api.chownow.com/api"
HEADERS = {
    "Accept": "application/json version=3.0;",
    "Content-Type": "application/json; charset=UTF-8",
    "X-CN-App-Info": "Marketplace-Web/5.211.0",
    "Origin": "https://www.chownow.com",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36",
}

# Each required field gets a stub value — the server's schema validates types
# but we never go deep enough to make the server attempt a real write.
STUB = {
    # cross-cutting on all PUT /customer/*
    "is_optout": False,
    # order/validate + order
    "when": "ASAP",
    "fulfill_method": "pickup",
    "fulfillment_method": "pickup",
    "restaurant_id": "35",
    "menu_id": "121704_202610151951",
    "cartitems": [],
    "cart_items": [],
    "items": [],
    "address": {},
    "promo_code": "",
    "payment_type": "no_payment",
    "payment_method": "no_payment",
    "payment": {},
    "customer": {},
    "fulfillment_time": "ASAP",
    "requested_fulfillment": "ASAP",
    "tip": {},
    "rewards": {},
    "meta": {"marketplace": {"id": "2", "x_id": None}},
    "is_cart_update": False,
    "validated_total": "0.00",
    # customer / auth
    "email": "nobody-rediscover-99999@mailinator.com",
    "password": "SomeStrongP@ssw0rd!",
    "first_name": "Test",
    "last_name": "User",
    "phone": "5555551234",
    "marketing_consent": False,
    # SSO
    "id_token": "xx.xx.xx",
    "authorization_code": "xx",
    "nonce": "xxxxxxxxxxxxxxxx",
    "redirect": "https://www.chownow.com/",
    "name": {},
    # device
    "device_id": "walk-" + str(int(time.time())),
    "device_token": "deadbeef",
    "platform": "web",
}

def _mk_session():
    if _IMPL == "curl_cffi":
        return _rq.Session(impersonate="chrome120")
    return _rq.Client(headers=HEADERS, follow_redirects=True)

def walk(method: str, path: str, max_steps: int = 30) -> dict:
    body: dict = {}
    history = []
    sess = _mk_session()
    # Bootstrap: hit /restaurant/35 to mint an anonymous session cookie
    try:
        if _IMPL == "curl_cffi":
            sess.request("GET", f"{BASE}/restaurant/35", headers=HEADERS, timeout=10)
        else:
            sess.request("GET", f"{BASE}/restaurant/35", timeout=10)
    except Exception:
        pass
    for step in range(max_steps):
        try:
            if _IMPL == "curl_cffi":
                r = sess.request(method, f"{BASE}{path}", json=body, headers=HEADERS, timeout=15)
            else:
                r = sess.request(method, f"{BASE}{path}", json=body, timeout=15)
        except Exception as e:
            history.append({"step": step, "err": str(e)}); break
        try:
            data = r.json()
        except Exception:
            history.append({"step": step, "status": r.status_code, "body": body.copy(), "resp_text_head": (r.text or "")[:120]})
            break
        err = (data.get("errors") or [{}])[0]
        code = str(err.get("code", "")) if err else ""
        field = err.get("field")
        msg = err.get("message", "")
        history.append({"step": step, "status": r.status_code, "body": body.copy(), "code": code, "field": field, "msg": msg})
        if r.status_code // 100 == 2:
            break  # done; server accepted
        # Required-field missing — add stub
        if code == "10101" and field and field not in body:
            body[field] = STUB.get(field, "placeholder")
            continue
        # Additional-properties — strip them
        if code == "10207" and msg:
            # Pull out field names between single quotes
            extras = re.findall(r"'([^']+)'", msg)
            # First match group is the list of extras, so just drop them.
            dropped = []
            for e in extras:
                if e in body:
                    body.pop(e); dropped.append(e)
            if dropped:
                history[-1]["dropped"] = dropped
                continue
            break  # couldn't drop anything useful
        # Enum validation — leak the allowed values and try the first
        if code == "10201" and field:
            allowed = re.findall(r"\[(.*?)\]", msg)
            history[-1]["enum_hint"] = allowed
            if allowed:
                first = allowed[0].split(",")[0].strip().strip("'\"")
                if first:
                    body[field] = first
                    continue
            break
        # Type mismatch — recover based on target type
        if code == "10202" and field:
            if "boolean" in msg: body[field] = False
            elif "integer" in msg: body[field] = 0
            elif "number"  in msg: body[field] = 0
            elif "array"   in msg: body[field] = []
            elif "object"  in msg: body[field] = {}
            elif "string"  in msg: body[field] = "x"
            else: break
            continue
        # String min-length — pad
        if code == "10204" and field:
            body[field] = (body.get(field, "") or "") + "xxxxxxxx"
            continue
        break
    return {"path": path, "method": method, "final_body": body, "history": history}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("endpoints", nargs="+", help="METHOD:/path pairs e.g. POST:/order/validate")
    args = ap.parse_args()

    results = []
    for ep in args.endpoints:
        method, path = ep.split(":", 1)
        print(f"\n==== {method} {path} ====")
        r = walk(method, path)
        results.append(r)
        for h in r["history"]:
            fields_so_far = list(h["body"].keys())
            print(f"  step {h['step']:>2}  status={h.get('status')}  code={h.get('code')}  field={h.get('field')!r}  body-keys={fields_so_far}")
            if h.get("enum_hint"): print(f"            enum hint: {h['enum_hint']}")
            if h.get("dropped"):   print(f"            dropped: {h['dropped']}")
            if h.get("msg"):       print(f"            msg: {h['msg'][:200]}")
    print()
    print(json.dumps([{k:v for k,v in r.items() if k!='history'} for r in results], indent=2, default=str))
