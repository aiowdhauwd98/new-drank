#!/usr/bin/env python3
"""V2: find every fetch(...) call site and extract the endpoint, method, body shape."""
from __future__ import annotations
import re, sys, pathlib, collections

text = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8", errors="replace")

# All string literals (back-tick, single, double) that are plausibly a path OR path fragment
# Short ones get included only when they contain an alpha char.
STR = re.compile(r"""(?P<q>["'`])(?P<s>[A-Za-z0-9_\-./:${}@+=,?!]{2,180})(?P=q)""")

# Request builder calls:
#   s("POST", {...}, "5.0")       -> body + version
#   s("DELETE")                   -> no body
#   i()                            -> default GET
# Match the method literal only.
METHOD = re.compile(r"""[si]\(\s*["'](GET|POST|PUT|PATCH|DELETE|HEAD)["']""")

# Match a URL assembled via `l()` builder or `fetch(new URL(...))`
# l("path/${id}", bodyOrOpts, "METHOD", baseOverride, version, ctxOpts)
L_CALL = re.compile(r"""\bl\(\s*`([^`]{2,140})`\s*(?:,[^,]{0,40}){0,5}\)""")
# Also catch l("path/...", ...)
L_CALL_STR = re.compile(r"""\bl\(\s*["']([^"']{2,140})["']\s*,""")

# fetch(url, s("METHOD", body, version)) patterns
FETCH_S = re.compile(r"""fetch\(\s*([^,]{1,120})\s*,\s*s\(\s*["'](GET|POST|PUT|PATCH|DELETE)["']\s*(?:,\s*(\{[^}]{0,220}\}))?\s*(?:,\s*["']([0-9.]+)["'])?""")

print(f"==== {sys.argv[1]} ====\n")

# A) all l(`...`) and l("...") calls
l_paths = collections.Counter()
for m in L_CALL.finditer(text): l_paths[m.group(1)] += 1
for m in L_CALL_STR.finditer(text): l_paths[m.group(1)] += 1
print(f"-- paths passed to `l()` builder (prefixed with /api/) : {len(l_paths)} --")
for p, n in sorted(l_paths.items()): print(f"  {n:>3}  /api/{p}")

# B) fetch(X, s("METHOD", body, version)) call sites with body hint
print("\n-- fetch() with s() wrapper (method + body hint) --")
seen = set()
for m in FETCH_S.finditer(text):
    url_expr, method, body, version = m.group(1).strip(), m.group(2), m.group(3), m.group(4)
    key = (url_expr, method)
    if key in seen: continue
    seen.add(key)
    body_short = (body or "").replace("\n", " ")[:140]
    v = f" (v{version})" if version else ""
    print(f"  {method:6s}{v:<8s}  url={url_expr[:120]}")
    if body_short: print(f"            body≈ {body_short}")

# C) all string literals near 'fetch(' — pull every unique string in a window
print("\n-- string literals within ±200 bytes of a fetch( call --")
near = collections.Counter()
for m in re.finditer(r"\bfetch\(", text):
    win = text[max(0,m.start()-250):m.end()+250]
    for sm in STR.finditer(win):
        s = sm.group("s")
        if (len(s) >= 3
            and re.search(r"[A-Za-z]", s)
            and not s.startswith("application/")
            and not s.startswith("http")
            and "." not in s[:3]
            and not s.endswith(".svg") and not s.endswith(".png")
            and not s.endswith(".js") and not s.endswith(".css") and not s.endswith(".woff2")):
            near[s] += 1
# print the most-interesting ones (contain / or _ or - or no vowel-only noise)
INTERESTING = re.compile(r"[/_-]|^[a-zA-Z]{3,}$")
for s, n in sorted(near.items()):
    if INTERESTING.search(s) and n <= 20:
        print(f"  {n:>3}  {s}")
