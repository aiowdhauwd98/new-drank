#!/usr/bin/env python3
"""Resolve UNKNOWNS #3: what does the pf query parameter on /api/restaurant mean?

Fires the discovery endpoint at the same point with pf=0/1/2/omitted and diffs
the response shapes.
"""
from __future__ import annotations
import os, json, sys, pathlib

try:
    from curl_cffi import requests as rq
except ImportError:
    import httpx as rq  # fallback

BASE = "https://api.chownow.com/api"
HEADERS = {
    "Accept": "application/json version=3.0;",
    "Content-Type": "application/json; charset=UTF-8",
    "X-CN-App-Info": "Marketplace-Web/5.211.0",
    "Origin": "https://www.chownow.com",
}
PARAMS_SHARED = {"aggs": "cuisines", "u_lat": 34.0549076, "u_lon": -118.242643, "limit": 10}

out_dir = pathlib.Path("chownow-api-spec/examples/pf_test")
out_dir.mkdir(parents=True, exist_ok=True)

rows = []
for label, pf in [("omitted", None), ("pf=0", 0), ("pf=1", 1), ("pf=2", 2)]:
    params = dict(PARAMS_SHARED)
    if pf is not None:
        params["pf"] = pf
    try:
        # curl_cffi: impersonate kwarg goes on each request (works on both top-level and Session.request)
        kwargs = {"params": params, "headers": HEADERS, "timeout": 15}
        if hasattr(rq, "get"):
            try:
                r = rq.get(f"{BASE}/restaurant", impersonate="chrome120", **kwargs)
            except TypeError:
                r = rq.get(f"{BASE}/restaurant", **kwargs)
        else:
            r = rq.request("GET", f"{BASE}/restaurant", **kwargs)
        if r.status_code != 200:
            rows.append((label, r.status_code, "-", "-", "-"))
            continue
        d = r.json()
        ids = [x["id"] for x in d.get("restaurants", [])]
        names = [x["name"].split("-")[0].strip() for x in d.get("restaurants", [])][:3]
        (out_dir / f"{label.replace('=', '_')}.json").write_text(json.dumps(d, indent=2), encoding="utf-8")
        rows.append((label, r.status_code, d.get("total", "?"), ids[:5], names))
    except Exception as e:
        rows.append((label, "err", str(e)[:60], "-", "-"))

print(f"{'variant':<10}  {'status':<7}  {'total':<6}  first 5 ids")
for label, status, total, ids, names in rows:
    print(f"{label:<10}  {status!s:<7}  {total!s:<6}  {ids}")

# Diff first 5 ids across variants
print("\nDiff of first-5 restaurant ids by variant:")
by_label = {r[0]: r[3] for r in rows if isinstance(r[3], list)}
for a in by_label:
    for b in by_label:
        if a < b:
            same = by_label[a] == by_label[b]
            print(f"  {a}  vs  {b}  :  {'SAME' if same else 'DIFF'}")
