# pzui: rounded control-panel theme + widget pack for Dear ImGui

A drop-in theme and widget set for Dear ImGui (DX11 + Win32): a big rounded sidebar with pill nav rows, a chip strip for subtabs, nested rounded cards with icon headers, a pink/lavender accent, and a bottom-left user card with a Settings pill. All icons are vector (ImDrawList), so the pack needs no image or icon-font assets.

![pzui demo](demo.png)

More states (open dropdown, row-gear popover, expanded search, second page):

![states](docs/states.png)

## Build

Requires Windows x64, Visual Studio 2022 (or newer) with the C++ workload, and CMake 3.24+. Dear ImGui `v1.93.0-docking` is fetched automatically (tarball pinned by SHA256).

```
cmake -B build -G "Visual Studio 17 2022" && cmake --build build --config Release
```

Run `build\Release\pzui_demo.exe`. Drag the header to move the window; press **Esc** (or Alt+F4) to quit.

- The project has a single configuration, **Release | x64**, and uses the static CRT, so the exe runs without the VC++ redistributable.
- Newer Visual Studio: use the matching generator, for example `-G "Visual Studio 18 2026"`.
- Offline builds: `-DFETCHCONTENT_SOURCE_DIR_IMGUI=C:/path/to/imgui` points CMake at a local ImGui checkout.

### Capture mode (how demo.png was made)

```
build\Release\pzui_demo.exe --shot demo.png --prefs
```

| flag | effect |
|---|---|
| `--shot <file.png>` | render offscreen, save the back buffer as PNG (with alpha), exit |
| `--prefs` | open the Preferences popover |
| `--page N` / `--tab N` | start on a sidebar page / subtab |
| `--mouse X,Y` / `--click` | inject a cursor position (client px) and a click mid-run |
| `--frames N` / `--scale S` | frames to settle before capture (default 90) / UI scale (default 1) |

## Layout

```
CMakeLists.txt        imgui (FetchContent) + pzui static lib + pzui_demo
src/ui/
  pzui.h              umbrella include
  theme.h/.cpp        palette, radii, font sizes, ImGuiStyle Apply(), fonts
  anim.h/.cpp         frame-rate independent tweening keyed by ImGuiID
  icons.h/.cpp        vector icons
  frame.h/.cpp        outer rounded frame + header bar (brand, search), panels
  sidebar.h/.cpp      sidebar, nav pills, user card, settings pill
  subtabs.h/.cpp      chip strip
  card.h/.cpp         nested cards, card header, floating popover card
  controls.h/.cpp     checkbox, slider, combo, button, search, input, swatch
  fonts/
    quicksand.h/.cpp  embedded Quicksand Medium + Bold (generated data, ~200 KB)
    OFL.txt           Quicksand license (SIL Open Font License 1.1)
demo/
  main.cpp            borderless DX11 window (DirectComposition alpha) + demo UI
  capture.h/.cpp      back buffer -> PNG via WIC
```

## Integrating into another project

1. Copy `src/ui/` into your project and compile its `.cpp` files, including `fonts/quicksand.cpp`. It needs only `imgui.h` and `imgui_internal.h` on the include path, and no global defines. Keep `fonts/OFL.txt` with it.
2. After `ImGui::CreateContext()` and before the first frame:

```cpp
#include "ui/pzui.h"

pz::theme::Apply(dpiScale);   // e.g. ImGui_ImplWin32_GetDpiScaleForHwnd(hwnd)
pz::theme::LoadFonts();       // embedded Quicksand; or LoadFonts("regular.ttf", "medium.ttf", "bold.ttf")
```

3. Build the UI each frame:

```cpp
pz::BeginShell("##app", "brand", searchBuf, sizeof(searchBuf));   // full viewport
ImVec2 body = pz::ShellBodyMin(), size = pz::ShellBodySize();

ImGui::SetCursorScreenPos(body);
pz::BeginSidebar("##nav", ImVec2(pz::S(170), size.y));
if (pz::NavItem("Combat",  pz::Icon::Crosshair, page == 0)) page = 0;
if (pz::NavItem("Visuals", pz::Icon::Eye,       page == 1)) page = 1;
pz::BeginSidebarFooter();
pz::UserCard("Guest", "version dev");
if (pz::SidebarButton("Settings##pill", pz::Icon::Gear, prefsOpen)) ImGui::OpenPopup("##prefs");
pz::EndSidebar();

ImGui::SetCursorScreenPos(ImVec2(body.x + pz::S(182), body.y));
pz::BeginSubtabs("##tabs", ImVec2(w, pz::S(44)));
if (pz::Subtab("General", pz::Icon::Crosshair, tab == 0)) tab = 0;
pz::EndSubtabs();

pz::BeginPanel("##content", ImVec2(w, h));
if (pz::BeginCard("Primary", pz::Icon::Crosshair, ImVec2(colW, -1)))   // -1: fill height, 0: auto-fit
{
    pz::Checkbox("Feature A", &a);
    pz::SliderFloat("Strength", &strength, 0, 100, "%.1f");
    pz::Combo("##mode", &mode, items, count);
}
pz::EndCard();                                                           // always, like EndChild
pz::EndPanel();
pz::EndShell();
```

`demo/main.cpp` is the complete reference, including window dragging (`pz::ShellDragging()`) for a borderless OS window.

### Widgets

| call | look |
|---|---|
| `pz::Checkbox(label, &b)` | filled accent box with an animated check when on (label goes bold), hollow outline when off |
| `pz::SliderFloat / SliderInt(label, &v, min, max, fmt)` | label left, readout right, accent track, glowing thumb |
| `pz::Combo / MultiCombo` | dark field, divider, rotating chevron, styled list with checkmarks |
| `pz::Button(label, size)` | pill; full width by default |
| `pz::Search(id, buf, n, width, collapsible)` | magnifier field; collapsible starts as an icon and expands leftward |
| `pz::InputText(label, buf, n, hint)` | field with placeholder and accent focus border |
| `pz::ColorSwatch(label, &vec4)` | label + glowing chip; click opens a picker |
| `pz::RowIconButton(id, icon)` | small icon (e.g. gear) at the right end of the previous row |
| `pz::GroupLabel(text)` | small dim section label |
| `pz::BeginPopover(id, title, icon, anchor, pivot, width)` | floating card with fade/slide-in |

A visible label on Combo/InputText is drawn above the field; use `"##id"` for the label-less mockup look.

## Palette

Values were sampled from the reference mockup and live in `pz::Palette` (`theme.h`). Edit them, or change `pz::Pal()` at runtime and call `pz::theme::ApplyColors()`. `pz::theme::SetAccent(col)` recolors the whole UI live (the demo's Accent color swatch does this).

| token | value | used for |
|---|---|---|
| `backdrop` | `#090D13` | behind the frame |
| `bg` | `#131A27` | outer frame |
| `sidebar` | `#0D151E` | recessed panels: header, sidebar, chip strip, content |
| `card` | `#111B28` | cards, popovers |
| `cardInner` | `#0D1520` | fields inside cards |
| `raised` | `#121A25` | idle nav pills, user card |
| `border` / `borderHi` | `#1B2430` / `#2A3341` | panel / control outlines |
| `accent` / `accentG` | `#C48ACB` / `#DDA8E0` | accent / glow and hover |
| `text` / `textSoft` / `dim` / `groupLbl` | `#ECEEF4` / `#9AA1AB` / `#7A828D` / `#565E6A` | text levels |

The mockup is bluer-slate than the starting values in the brief (`#0E0E1A`, `#15152A`, …), and its accent is a softer mauve than `#C080E8`. Its panels are also *darker* than the frame around them, so the shipped values follow the mockup.

Radii: 16 outer/sidebar/content, 12 header and chip strip, 10 cards and popovers, 8 chips/pills/buttons, 6 combos and inputs, 4 checkbox.

## Fonts

The mockup uses a rounded geometric face, so **Quicksand** (Medium and Bold) is compiled into the library. Text looks the same on every machine, with nothing to install. `Font::Regular` and `Font::Medium` both use Quicksand Medium, because Quicksand Regular renders thin on dark backgrounds at UI sizes. Sizes (`pz::fontsize`) are set so capital letters match the mockup's height.

- **Glyph fallback:** Quicksand covers Latin only. Segoe UI is merged under each face, so other characters still render.
- **Your own fonts:** `LoadFonts("regular.ttf", "medium.ttf", "bold.ttf")` replaces any slot you pass.
- **Smaller binary:** define `PZUI_NO_EMBEDDED_FONTS` to compile the data out. `LoadFonts()` then uses an installed Quicksand or Segoe UI, sized up 6.4% so cap heights match, and finally ImGui's built-in vector font.
- **Regenerating the data:** `src/ui/fonts/quicksand.cpp` holds the unmodified upstream TTFs (`fonts/statics/` in [QuicksandFamily](https://github.com/andrew-paglinawan/QuicksandFamily)), stb-compressed and base85-encoded with imgui's `misc/fonts/binary_to_compressed_c`, split into chunks under MSVC's 64 KB string-literal limit.

## Licenses

- Quicksand: Copyright 2011 The Quicksand Project Authors, SIL Open Font License 1.1 (`src/ui/fonts/OFL.txt`). It is bundled unmodified, so the Reserved Font Name is kept.
- Dear ImGui: MIT, fetched at configure time.

## Motion

Hover, press and selection states ease with `pz::anim::To(id, target, speed)`. The nav highlight and the active chip slide between rows and chips, cards tint their border and glow on hover, the checkmark draws itself in, combo chevrons rotate, and popovers fade and slide in. `pz::anim::SetReducedMotion(true)` snaps everything (wired to the demo's Reduce motion toggle).
