#include "capture.h"

#include <wincodec.h>
#include <vector>

template <class T> static void SafeRelease(T*& p)
{
    if (p) { p->Release(); p = nullptr; }
}

static bool EncodePNG(const wchar_t* path, UINT w, UINT h, std::vector<BYTE>& bgra)
{
    const HRESULT co = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    IWICImagingFactory* factory = nullptr;
    IWICStream* stream = nullptr;
    IWICBitmapEncoder* encoder = nullptr;
    IWICBitmapFrameEncode* frame = nullptr;
    IPropertyBag2* props = nullptr;

    WICPixelFormatGUID fmt = GUID_WICPixelFormat32bppBGRA;
    HRESULT hr = CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&factory));
    if (SUCCEEDED(hr)) hr = factory->CreateStream(&stream);
    if (SUCCEEDED(hr)) hr = stream->InitializeFromFilename(path, GENERIC_WRITE);
    if (SUCCEEDED(hr)) hr = factory->CreateEncoder(GUID_ContainerFormatPng, nullptr, &encoder);
    if (SUCCEEDED(hr)) hr = encoder->Initialize(stream, WICBitmapEncoderNoCache);
    if (SUCCEEDED(hr)) hr = encoder->CreateNewFrame(&frame, &props);
    if (SUCCEEDED(hr)) hr = frame->Initialize(props);
    if (SUCCEEDED(hr)) hr = frame->SetSize(w, h);
    if (SUCCEEDED(hr)) hr = frame->SetPixelFormat(&fmt);
    if (SUCCEEDED(hr) && !IsEqualGUID(fmt, GUID_WICPixelFormat32bppBGRA)) hr = E_FAIL;
    if (SUCCEEDED(hr)) hr = frame->WritePixels(h, w * 4, (UINT)bgra.size(), bgra.data());
    if (SUCCEEDED(hr)) hr = frame->Commit();
    if (SUCCEEDED(hr)) hr = encoder->Commit();

    SafeRelease(props);
    SafeRelease(frame);
    SafeRelease(encoder);
    SafeRelease(stream);
    SafeRelease(factory);
    if (SUCCEEDED(co))
        CoUninitialize();
    return SUCCEEDED(hr);
}

bool SaveBackbufferPNG(ID3D11Device* device, ID3D11DeviceContext* ctx, IDXGISwapChain* swap, const wchar_t* path)
{
    ID3D11Texture2D* back = nullptr;
    if (FAILED(swap->GetBuffer(0, IID_PPV_ARGS(&back))))
        return false;

    D3D11_TEXTURE2D_DESC desc;
    back->GetDesc(&desc);
    desc.Usage = D3D11_USAGE_STAGING;
    desc.BindFlags = 0;
    desc.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    desc.MiscFlags = 0;
    desc.MipLevels = 1;
    desc.ArraySize = 1;
    desc.SampleDesc.Count = 1;
    desc.SampleDesc.Quality = 0;

    ID3D11Texture2D* staging = nullptr;
    const HRESULT hr = device->CreateTexture2D(&desc, nullptr, &staging);
    if (SUCCEEDED(hr))
        ctx->CopyResource(staging, back);
    back->Release();
    if (FAILED(hr))
        return false;

    D3D11_MAPPED_SUBRESOURCE map;
    if (FAILED(ctx->Map(staging, 0, D3D11_MAP_READ, 0, &map)))
    {
        staging->Release();
        return false;
    }

    // Back buffer is premultiplied (composition swap chain); PNG wants straight alpha, BGRA order.
    const UINT w = desc.Width, h = desc.Height;
    const bool rgba = desc.Format == DXGI_FORMAT_R8G8B8A8_UNORM;
    std::vector<BYTE> px((size_t)w * h * 4);
    for (UINT y = 0; y < h; ++y)
    {
        const BYTE* src = (const BYTE*)map.pData + (size_t)y * map.RowPitch;
        BYTE* dst = px.data() + (size_t)y * w * 4;
        for (UINT x = 0; x < w; ++x, src += 4, dst += 4)
        {
            UINT b = rgba ? src[2] : src[0], g = src[1], r = rgba ? src[0] : src[2];
            const UINT a = src[3];
            if (a > 0 && a < 255)
            {
                b = (b * 255 + a / 2) / a; g = (g * 255 + a / 2) / a; r = (r * 255 + a / 2) / a;
                b = b > 255 ? 255 : b; g = g > 255 ? 255 : g; r = r > 255 ? 255 : r;
            }
            dst[0] = (BYTE)b; dst[1] = (BYTE)g; dst[2] = (BYTE)r; dst[3] = (BYTE)a;
        }
    }
    ctx->Unmap(staging, 0);
    staging->Release();

    return EncodePNG(path, w, h, px);
}
