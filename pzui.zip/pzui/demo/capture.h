#pragma once
// Saves the swap chain's current back buffer as a PNG (straight alpha) via WIC.
// Call after rendering and before Present().
#include <d3d11.h>
#include <dxgi.h>

bool SaveBackbufferPNG(ID3D11Device* device, ID3D11DeviceContext* ctx, IDXGISwapChain* swap, const wchar_t* path);
