// pzui demo: every widget of the pack in situ.
//
// Borderless 740x680 window. The swap chain is presented through
// DirectComposition with premultiplied alpha, so the rounded outer frame gets
// real anti-aliased transparent corners (falls back to an opaque HWND swap
// chain if composition is unavailable).
//
// Capture mode (used to produce demo.png):
//   pzui_demo.exe --shot demo.png [--prefs] [--page N] [--tab N] [--frames N]
//                 [--scale S] [--mouse X,Y] [--click]
#include "ui/pzui.h"

#include "imgui.h"
#include "imgui_impl_dx11.h"
#include "imgui_impl_win32.h"
#include "capture.h"

#include <d3d11.h>
#include <dcomp.h>
#include <dwmapi.h>
#include <dxgi1_3.h>
#include <shellapi.h>

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <string>

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// ---------------------------------------------------------------------------
// D3D11 + DirectComposition
// ---------------------------------------------------------------------------
static ID3D11Device*           g_device = nullptr;
static ID3D11DeviceContext*    g_ctx = nullptr;
static IDXGISwapChain1*        g_swap = nullptr;
static ID3D11RenderTargetView* g_rtv = nullptr;
static IDCompositionDevice*    g_dcomp = nullptr;
static IDCompositionTarget*    g_dcompTarget = nullptr;
static IDCompositionVisual*    g_dcompVisual = nullptr;
static bool                    g_transparent = false;

template <class T> static void SafeRelease(T*& p)
{
    if (p) { p->Release(); p = nullptr; }
}

static void CreateRenderTarget()
{
    ID3D11Texture2D* back = nullptr;
    if (SUCCEEDED(g_swap->GetBuffer(0, IID_PPV_ARGS(&back))))
    {
        g_device->CreateRenderTargetView(back, nullptr, &g_rtv);
        back->Release();
    }
}

static bool CreateDeviceD3D(HWND hwnd, UINT w, UINT h)
{
    const D3D_FEATURE_LEVEL levels[] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };
    const UINT flags = D3D11_CREATE_DEVICE_BGRA_SUPPORT;
    HRESULT hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, flags, levels, 2, D3D11_SDK_VERSION, &g_device, nullptr, &g_ctx);
    if (FAILED(hr))
        hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, flags, levels, 2, D3D11_SDK_VERSION, &g_device, nullptr, &g_ctx);
    if (FAILED(hr))
        return false;

    IDXGIDevice* dxgiDevice = nullptr;
    IDXGIFactory2* factory = nullptr;
    g_device->QueryInterface(IID_PPV_ARGS(&dxgiDevice));
    hr = CreateDXGIFactory2(0, IID_PPV_ARGS(&factory));
    if (FAILED(hr) || !dxgiDevice)
    {
        SafeRelease(dxgiDevice);
        return false;
    }

    DXGI_SWAP_CHAIN_DESC1 sd = {};
    sd.Width = w;
    sd.Height = h;
    sd.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    sd.SampleDesc.Count = 1;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.BufferCount = 2;
    sd.SwapEffect = DXGI_SWAP_EFFECT_FLIP_SEQUENTIAL;
    sd.Scaling = DXGI_SCALING_STRETCH;
    sd.AlphaMode = DXGI_ALPHA_MODE_PREMULTIPLIED;

    // Preferred: composition swap chain with per-pixel alpha.
    hr = factory->CreateSwapChainForComposition(g_device, &sd, nullptr, &g_swap);
    if (SUCCEEDED(hr)) hr = DCompositionCreateDevice(dxgiDevice, IID_PPV_ARGS(&g_dcomp));
    if (SUCCEEDED(hr)) hr = g_dcomp->CreateTargetForHwnd(hwnd, TRUE, &g_dcompTarget);
    if (SUCCEEDED(hr)) hr = g_dcomp->CreateVisual(&g_dcompVisual);
    if (SUCCEEDED(hr)) hr = g_dcompVisual->SetContent(g_swap);
    if (SUCCEEDED(hr)) hr = g_dcompTarget->SetRoot(g_dcompVisual);
    if (SUCCEEDED(hr)) hr = g_dcomp->Commit();
    g_transparent = SUCCEEDED(hr);

    if (!g_transparent) // Fallback: plain opaque HWND swap chain.
    {
        SafeRelease(g_dcompVisual);
        SafeRelease(g_dcompTarget);
        SafeRelease(g_dcomp);
        SafeRelease(g_swap);
        sd.AlphaMode = DXGI_ALPHA_MODE_IGNORE;
        sd.Scaling = DXGI_SCALING_NONE;
        hr = factory->CreateSwapChainForHwnd(g_device, hwnd, &sd, nullptr, nullptr, &g_swap);
    }
    factory->Release();
    dxgiDevice->Release();
    if (FAILED(hr))
        return false;

    CreateRenderTarget();
    return g_rtv != nullptr;
}

static void CleanupDeviceD3D()
{
    SafeRelease(g_rtv);
    SafeRelease(g_dcompVisual);
    SafeRelease(g_dcompTarget);
    SafeRelease(g_dcomp);
    SafeRelease(g_swap);
    SafeRelease(g_ctx);
    SafeRelease(g_device);
}

static LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;
    switch (msg)
    {
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU) // no ALT application menu
            return 0;
        break;
    case WM_DESTROY:
        ::PostQuitMessage(0);
        return 0;
    }
    return ::DefWindowProcW(hWnd, msg, wParam, lParam);
}

// ---------------------------------------------------------------------------
// Command line
// ---------------------------------------------------------------------------
struct Options
{
    std::wstring shot;          // capture to this PNG and exit
    int   frames = 90;          // frames to run before capturing
    float scale = 0.0f;         // UI scale (0 = monitor DPI; 1 in capture mode)
    int   page = 0, tab = 0;
    bool  prefs = false;        // open the preferences popover
    bool  mouse = false;        // inject a mouse position (client px, unscaled)
    float mx = 0, my = 0;
    bool  click = false;        // inject a click at the mouse position mid-run
};

static Options ParseArgs()
{
    Options o;
    int argc = 0;
    LPWSTR* argv = ::CommandLineToArgvW(::GetCommandLineW(), &argc);
    for (int i = 1; argv && i < argc; ++i)
    {
        const std::wstring a = argv[i];
        const bool more = i + 1 < argc;
        if (a == L"--shot" && more) o.shot = argv[++i];
        else if (a == L"--frames" && more) o.frames = _wtoi(argv[++i]);
        else if (a == L"--scale" && more) o.scale = (float)_wtof(argv[++i]);
        else if (a == L"--page" && more) o.page = _wtoi(argv[++i]);
        else if (a == L"--tab" && more) o.tab = _wtoi(argv[++i]);
        else if (a == L"--prefs") o.prefs = true;
        else if (a == L"--click") o.click = true;
        else if (a == L"--mouse" && more)
        {
            o.mouse = swscanf_s(argv[++i], L"%f,%f", &o.mx, &o.my) == 2;
        }
    }
    ::LocalFree(argv);
    return o;
}

// ---------------------------------------------------------------------------
// Demo UI
// ---------------------------------------------------------------------------
struct GenericTab
{
    bool  flags[3] = { true, false, true };
    int   choice = 0;
    float a = 62.0f;
    int   b = 12;
    ImVec4 color = ImVec4(0.45f, 0.70f, 0.95f, 1.0f);
};

struct DemoState
{
    int  page = 0;
    int  tab[4] = {};
    char search[64] = "";

    // Combat / General: one of each widget
    bool   featureA = true, featureB = false, featureC = true;
    bool   targets[4] = { true, true, false, false };
    char   profile[64] = "";
    float  strength = 40.0f;
    int    range = 35;
    int    mode = 0;
    bool   optionA = true, optionB = false;
    ImVec4 tint = ImVec4(0.42f, 0.78f, 0.86f, 1.0f);
    double lastAction = -100.0;
    bool   featureCSub = true;
    float  featureCAmount = 0.6f;

    // Preferences popover
    bool   openPrefs = false, prefsVisible = false;
    ImVec4 accent;
    bool   reduceMotion = false;
    int    preset = 1, density = 1, anchor = 1;

    GenericTab generic[4][3];

    // Page transition
    int   lastKey = -1;
    float fade = 1.0f;
};

static const char* const kTargets[] = { "Option A", "Option B", "Option C", "Option D" };
static const char* const kModes[]   = { "Balanced", "Fast", "Precise" };
static const char* const kPresets[] = { "Preset 1", "Preset 2", "Preset 3" };
static const char* const kDensity[] = { "Comfortable", "Compact", "Dense" };
static const char* const kAnchor[]  = { "Anchor left", "Anchor right", "Anchor center" };
static const char* const kChoices[] = { "Mode A", "Mode B", "Mode C" };

struct NavDef { const char* label; pz::Icon icon; };
static const NavDef kPages[4] = {
    { "Combat", pz::Icon::Crosshair }, { "Visuals", pz::Icon::Eye }, { "Misc", pz::Icon::Sliders }, { "Settings", pz::Icon::Gears },
};
static const NavDef kTabs[4][3] = {
    { { "General", pz::Icon::Crosshair }, { "Input", pz::Icon::Keyboard }, { "Extra", pz::Icon::Sliders } },
    { { "Overlay", pz::Icon::Eye }, { "Colors", pz::Icon::Palette }, { "Extra", pz::Icon::Sliders } },
    { { "General", pz::Icon::Layers }, { "Notes", pz::Icon::Chat }, { "Extra", pz::Icon::Sliders } },
    { { "Interface", pz::Icon::Gear }, { "Hotkeys", pz::Icon::Keyboard }, { "About", pz::Icon::Avatar } },
};

static void PageMain(DemoState& s)
{
    using namespace pz;
    const float colW = std::floor((ImGui::GetContentRegionAvail().x - S(10)) * 0.5f);

    if (BeginCard("Primary", Icon::Crosshair, ImVec2(colW, -1.0f)))
    {
        Checkbox("Feature A", &s.featureA);
        Checkbox("Feature B", &s.featureB);
        Checkbox("Feature C", &s.featureC);
        if (RowIconButton("##featureC.cfg", Icon::Gear))
            ImGui::OpenPopup("##featureC.pop");
        const ImVec2 gear = ImGui::GetItemRectMax();
        MultiCombo("##targets", s.targets, kTargets, IM_ARRAYSIZE(kTargets));
        InputText("##profile", s.profile, sizeof(s.profile), "Profile name");

        if (BeginPopover("##featureC.pop", "Feature C", Icon::Sliders, ImVec2(gear.x + S(8), gear.y - S(20)), ImVec2(0, 0), 220.0f))
        {
            Checkbox("Sub-option", &s.featureCSub);
            SliderFloat("Amount", &s.featureCAmount, 0.0f, 1.0f, "%.2f");
            EndPopover();
        }
    }
    EndCard();

    ImGui::SameLine(0.0f, S(10));
    if (BeginCard("Tuning", Icon::Sliders, ImVec2(colW, -1.0f)))
    {
        SliderFloat("Strength", &s.strength, 0.0f, 100.0f, "%.1f");
        SliderInt("Range", &s.range, 0, 180, "%d px");
        Combo("##mode", &s.mode, kModes, IM_ARRAYSIZE(kModes));
        Checkbox("Option A", &s.optionA);
        Checkbox("Option B", &s.optionB);
        if (Button("Run action"))
            s.lastAction = ImGui::GetTime();
        ColorSwatch("Tint", &s.tint);

        const float since = (float)(ImGui::GetTime() - s.lastAction);
        if (since < 1.6f)
        {
            ImGui::PushStyleColor(ImGuiCol_Text, ImGui::ColorConvertU32ToFloat4(WithAlpha(Pal().dim, 1.0f - since / 1.6f)));
            ImGui::TextUnformatted("Action ran");
            ImGui::PopStyleColor();
        }
    }
    EndCard();
}

static void PageGeneric(DemoState& s)
{
    using namespace pz;
    const NavDef& tab = kTabs[s.page][s.tab[s.page]];
    GenericTab& g = s.generic[s.page][s.tab[s.page]];
    const float colW = std::floor((ImGui::GetContentRegionAvail().x - S(10)) * 0.5f);

    ImGui::PushID(s.page * 8 + s.tab[s.page]);
    if (BeginCard(tab.label, tab.icon, ImVec2(colW, -1.0f)))
    {
        GroupLabel("TOGGLES");
        Checkbox("Feature A", &g.flags[0]);
        Checkbox("Feature B", &g.flags[1]);
        Checkbox("Feature C", &g.flags[2]);
        GroupLabel("MODE");
        Combo("##choice", &g.choice, kChoices, IM_ARRAYSIZE(kChoices));
    }
    EndCard();

    ImGui::SameLine(0.0f, S(10));
    if (BeginCard("Details##generic", Icon::Sliders, ImVec2(colW, -1.0f)))
    {
        SliderFloat("Amount", &g.a, 0.0f, 100.0f, "%.0f%%");
        SliderInt("Steps", &g.b, 1, 32, "%d");
        ColorSwatch("Color", &g.color);
        Button("Apply");
    }
    EndCard();
    ImGui::PopID();
}

static void HandleWindowDrag(HWND hwnd)
{
    static bool dragging = false;
    static POINT start;
    static RECT startRect;
    if (pz::ShellDragging())
    {
        POINT pt;
        ::GetCursorPos(&pt);
        if (!dragging)
        {
            dragging = true;
            start = pt;
            ::GetWindowRect(hwnd, &startRect);
        }
        ::SetWindowPos(hwnd, nullptr, startRect.left + pt.x - start.x, startRect.top + pt.y - start.y, 0, 0,
                       SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
    }
    else
        dragging = false;
}

static void DrawDemo(DemoState& s, HWND hwnd)
{
    using namespace pz;

    BeginShell("##pz.shell", "pzui", s.search, sizeof(s.search));
    HandleWindowDrag(hwnd);
    const ImVec2 body = ShellBodyMin(), bodySz = ShellBodySize();
    const float sideW = S(170), gap = S(12);

    // Sidebar
    ImGui::SetCursorScreenPos(body);
    BeginSidebar("##nav", ImVec2(sideW, bodySz.y));
    for (int i = 0; i < 4; ++i)
        if (NavItem(kPages[i].label, kPages[i].icon, s.page == i))
            s.page = i;
    BeginSidebarFooter();
    UserCard("Guest", "version dev");
    if (SidebarButton("Settings##pill", Icon::Gear, s.prefsVisible))
        s.openPrefs = true;
    const ImVec2 pill = ImGui::GetItemRectMin();
    EndSidebar();

    // Preferences popover, anchored next to the sidebar footer
    if (s.openPrefs)
    {
        ImGui::OpenPopup("##prefs");
        s.openPrefs = false;
    }
    if (BeginPopover("##prefs", "Preferences", Icon::Gear, ImVec2(body.x + sideW + S(5), pill.y - S(30)), ImVec2(0, 1)))
    {
        if (ColorSwatch("Accent color", &s.accent))
            theme::SetAccent(ImGui::ColorConvertFloat4ToU32(s.accent));
        if (Checkbox("Reduce motion", &s.reduceMotion))
            anim::SetReducedMotion(s.reduceMotion);
        Combo("##preset", &s.preset, kPresets, IM_ARRAYSIZE(kPresets));
        Combo("##density", &s.density, kDensity, IM_ARRAYSIZE(kDensity));
        Combo("##anchor", &s.anchor, kAnchor, IM_ARRAYSIZE(kAnchor));
        EndPopover();
    }
    s.prefsVisible = ImGui::IsPopupOpen("##prefs");

    // Chip strip
    const float cx = body.x + sideW + gap, cw = body.x + bodySz.x - cx;
    ImGui::SetCursorScreenPos(ImVec2(cx, body.y));
    BeginSubtabs("##tabs", ImVec2(cw, S(44)));
    for (int i = 0; i < 3; ++i)
        if (Subtab(kTabs[s.page][i].label, kTabs[s.page][i].icon, s.tab[s.page] == i))
            s.tab[s.page] = i;
    EndSubtabs();

    // Content panel with a short fade/slide when the page or tab changes
    const float top = body.y + S(44) + S(14);
    ImGui::SetCursorScreenPos(ImVec2(cx, top));
    BeginPanel("##content", ImVec2(cw, body.y + bodySz.y - top), radius::outer, ImVec2(10, 10));
    const int key = s.page * 8 + s.tab[s.page];
    if (key != s.lastKey)
    {
        s.fade = s.lastKey < 0 || anim::ReducedMotion() ? 1.0f : 0.0f;
        s.lastKey = key;
    }
    s.fade = std::min(1.0f, s.fade + ImGui::GetIO().DeltaTime * 6.0f);
    const float e = 1.0f - (1.0f - s.fade) * (1.0f - s.fade) * (1.0f - s.fade);
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, e);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + (1.0f - e) * S(6));
    if (s.page == 0 && s.tab[0] == 0)
        PageMain(s);
    else
        PageGeneric(s);
    ImGui::PopStyleVar();
    EndPanel();

    EndShell();
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------
int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, PWSTR, int)
{
    const Options opt = ParseArgs();
    const bool capture = !opt.shot.empty();

    ImGui_ImplWin32_EnableDpiAwareness();
    float scale = opt.scale;
    if (scale <= 0.0f)
        scale = capture ? 1.0f : ImGui_ImplWin32_GetDpiScaleForMonitor(::MonitorFromPoint(POINT{ 0, 0 }, MONITOR_DEFAULTTOPRIMARY));

    const int w = (int)(740 * scale), h = (int)(680 * scale);
    RECT work;
    ::SystemParametersInfoW(SPI_GETWORKAREA, 0, &work, 0);

    WNDCLASSEXW wc = { sizeof(wc), CS_CLASSDC, WndProc, 0, 0, hInst, ::LoadIconW(nullptr, IDI_APPLICATION),
                       ::LoadCursorW(nullptr, IDC_ARROW), nullptr, nullptr, L"pzui_demo", nullptr };
    ::RegisterClassExW(&wc);
    HWND hwnd = ::CreateWindowExW(WS_EX_NOREDIRECTIONBITMAP | (capture ? WS_EX_TOOLWINDOW : 0), wc.lpszClassName, L"pzui demo",
                                  WS_POPUP | WS_MINIMIZEBOX | WS_SYSMENU,
                                  work.left + (work.right - work.left - w) / 2, work.top + (work.bottom - work.top - h) / 2, w, h,
                                  nullptr, nullptr, hInst, nullptr);
    const DWM_WINDOW_CORNER_PREFERENCE corners = DWMWCP_DONOTROUND; // we draw our own anti-aliased corners
    ::DwmSetWindowAttribute(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, &corners, sizeof(corners));

    if (!CreateDeviceD3D(hwnd, (UINT)w, (UINT)h))
    {
        CleanupDeviceD3D();
        ::DestroyWindow(hwnd);
        ::UnregisterClassW(wc.lpszClassName, hInst);
        ::MessageBoxW(nullptr, L"Could not create a Direct3D 11 device.", L"pzui demo", MB_ICONERROR);
        return 1;
    }
    if (!capture)
    {
        ::ShowWindow(hwnd, SW_SHOWDEFAULT);
        ::UpdateWindow(hwnd);
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;

    pz::theme::Apply(scale);
    pz::theme::LoadFonts();
    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(g_device, g_ctx);

    DemoState state;
    state.page = opt.page & 3;
    state.tab[state.page] = opt.tab % 3;
    state.accent = ImGui::ColorConvertU32ToFloat4(pz::Pal().accent);
    state.openPrefs = opt.prefs;

    const ImVec4 clear = g_transparent ? ImVec4(0, 0, 0, 0) : ImGui::ColorConvertU32ToFloat4(pz::Pal().backdrop);
    const float clearColor[4] = { clear.x, clear.y, clear.z, clear.w };

    bool done = false, ok = !capture, prevBlocking = false;
    for (int frame = 0; !done; ++frame)
    {
        MSG msg;
        while (::PeekMessageW(&msg, nullptr, 0U, 0U, PM_REMOVE))
        {
            ::TranslateMessage(&msg);
            ::DispatchMessageW(&msg);
            if (msg.message == WM_QUIT)
                done = true;
        }
        if (done)
            break;
        if (!capture && ::IsIconic(hwnd))
        {
            ::Sleep(16);
            continue;
        }

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        if (capture)
        {
            io.DeltaTime = 1.0f / 60.0f; // deterministic animation timing
            if (opt.mouse)
                io.AddMousePosEvent(opt.mx * scale, opt.my * scale);
            if (opt.mouse && opt.click && frame == opt.frames / 2)
                io.AddMouseButtonEvent(ImGuiMouseButton_Left, true);
            if (opt.mouse && opt.click && frame == opt.frames / 2 + 1)
                io.AddMouseButtonEvent(ImGuiMouseButton_Left, false);
        }
        ImGui::NewFrame();

        DrawDemo(state, hwnd);

        // Esc quits, unless it was used to close a popup or leave a text field.
        if (ImGui::IsKeyPressed(ImGuiKey_Escape, false) && !prevBlocking)
            ::PostMessageW(hwnd, WM_CLOSE, 0, 0);
        prevBlocking = ImGui::IsPopupOpen("", ImGuiPopupFlags_AnyPopup) || ImGui::IsAnyItemActive();

        ImGui::Render();
        g_ctx->OMSetRenderTargets(1, &g_rtv, nullptr);
        g_ctx->ClearRenderTargetView(g_rtv, clearColor);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

        if (capture && frame >= opt.frames)
        {
            ok = SaveBackbufferPNG(g_device, g_ctx, g_swap, opt.shot.c_str());
            done = true;
        }
        g_swap->Present(1, 0);
    }

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    CleanupDeviceD3D();
    ::DestroyWindow(hwnd);
    ::UnregisterClassW(wc.lpszClassName, hInst);
    return ok ? 0 : 2;
}
