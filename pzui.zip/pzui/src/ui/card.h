#pragma once
// Nested rounded cards: header row (accent-tinted icon + title + fading
// separator) and a body that clips/scrolls or auto-sizes to its content.
#include "imgui.h"
#include "ui/icons.h"

namespace pz {

// size.x <= 0 : full available width
// size.y == 0 : auto-fit height to the content
// size.y <  0 : fill the remaining height
// size.y >  0 : fixed height (content scrolls if it overflows)
// Always call EndCard(), even when this returns false (card clipped).
bool BeginCard(const char* title, Icon icon, ImVec2 size = ImVec2(0, 0));
void EndCard();

// Header row on its own: use inside popovers or custom containers.
void CardHeader(const char* title, Icon icon);

// Floating card (popup) with a fade/slide-in. Open it with ImGui::OpenPopup(id).
// `anchor` is the screen position of the pivot corner, e.g. pivot (0,1) puts
// the card's bottom-left at `anchor`. Width is unscaled px.
// Only call EndPopover() when this returns true.
bool BeginPopover(const char* id, const char* title, Icon icon, ImVec2 anchor,
                  ImVec2 pivot = ImVec2(0, 0), float width = 248.0f);
void EndPopover();

} // namespace pz
