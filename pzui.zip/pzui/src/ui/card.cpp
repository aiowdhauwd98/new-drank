#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS // ImVec2 operators; must precede imgui.h
#endif
#include "ui/card.h"
#include "ui/anim.h"
#include "ui/controls.h"
#include "ui/theme.h"
#include "imgui_internal.h"

namespace pz {

constexpr float kCardPad     = 10.0f;
constexpr float kHeaderRow   = 18.0f; // icon + title line
constexpr float kSepOffset   = 10.0f; // header row -> separator
constexpr float kSepToBody   = 13.0f; // separator -> first row

static ImVector<ImGuiID> g_cardStack;
static ImGuiStorage      g_cardMem; // last-frame hover + height per card

bool BeginCard(const char* title, Icon icon, ImVec2 size)
{
    const Palette& p = Pal();
    ImGuiWindow* parent = ImGui::GetCurrentWindow();
    const ImGuiID id = parent->GetID(title);
    g_cardStack.push_back(id);

    const ImVec2 avail = ImGui::GetContentRegionAvail();
    const bool autoH = size.y == 0.0f;
    const float w = size.x > 0.0f ? size.x : avail.x;
    const float h = size.y > 0.0f ? size.y : (size.y < 0.0f ? avail.y : g_cardMem.GetFloat(anim::Key(id, "h"), 0.0f));
    const ImVec2 pos = ImGui::GetCursorScreenPos();

    // Hover glow + border tint (hover state is from the previous frame).
    const float hov = anim::To(anim::Key(id, "hov"), g_cardMem.GetBool(id, false) ? 1.0f : 0.0f, 10.0f);
    if (hov > 0.0f && h > 0.0f)
        DrawGlow(parent->DrawList, pos, pos + ImVec2(w, h), p.accent, S(radius::card), S(9), 0.10f * hov);

    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImGui::ColorConvertU32ToFloat4(p.card));
    ImGui::PushStyleColor(ImGuiCol_Border, ImGui::ColorConvertU32ToFloat4(Mix(p.border, Mix(p.border, p.accent, 0.45f), hov)));
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, S(radius::card));
    ImGui::PushStyleVar(ImGuiStyleVar_ChildBorderSize, 1.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(S(kCardPad), S(kCardPad)));
    const ImGuiChildFlags flags = ImGuiChildFlags_Borders | ImGuiChildFlags_AlwaysUseWindowPadding | (autoH ? ImGuiChildFlags_AutoResizeY : 0);
    const bool visible = ImGui::BeginChild(id, ImVec2(w, autoH ? 0.0f : h), flags, ImGuiWindowFlags_None);
    ImGui::PopStyleVar(3);
    ImGui::PopStyleColor(2);

    if (visible)
        CardHeader(title, icon);
    return visible;
}

void EndCard()
{
    IM_ASSERT(!g_cardStack.empty() && "EndCard() without BeginCard()");
    const ImGuiID id = g_cardStack.back();
    g_cardStack.pop_back();
    g_cardMem.SetBool(id, ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows | ImGuiHoveredFlags_AllowWhenBlockedByActiveItem));
    g_cardMem.SetFloat(anim::Key(id, "h"), ImGui::GetWindowHeight());
    ImGui::EndChild();
}

void CardHeader(const char* title, Icon icon)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return;

    const Palette& p = Pal();
    ImDrawList* dl = window->DrawList;
    const ImVec2 pos = window->DC.CursorPos;
    const float width = ImGui::GetContentRegionAvail().x;
    const float cy = pos.y + S(kHeaderRow) * 0.5f;

    float tx = pos.x;
    if (icon != Icon::None)
    {
        DrawIcon(dl, icon, ImVec2(pos.x + S(7), cy), S(15), C(p.accent));
        tx += S(19);
    }
    PushFont(Font::Bold, fontsize::title);
    const char* end = ImGui::FindRenderedTextEnd(title);
    const ImVec2 ts = ImGui::CalcTextSize(title, end);
    dl->AddText(ImVec2(tx, IM_ROUND(cy - ts.y * 0.5f)), C(p.text), title, end);
    PopFont();

    // Separator: small dot, then a hairline that fades out.
    const float ly = IM_ROUND(pos.y + S(kHeaderRow) + S(kSepOffset));
    dl->AddCircleFilled(ImVec2(pos.x + S(2), ly + 0.5f), S(1.8f), C(Mix(p.groupLbl, p.text, 0.25f)));
    const ImU32 line = C(Mix(p.border, p.text, 0.06f)), clear = C(WithAlpha(p.border, 0.0f));
    dl->AddRectFilledMultiColor(ImVec2(pos.x + S(8), ly), ImVec2(pos.x + width * 0.72f, ly + 1.0f), line, clear, clear, line);

    ImGui::Dummy(ImVec2(width, S(kHeaderRow) + S(kSepOffset) + S(kSepToBody) - ImGui::GetStyle().ItemSpacing.y));
}

static ImGuiStorage g_popMem;

bool BeginPopover(const char* id, const char* title, Icon icon, ImVec2 anchor, ImVec2 pivot, float width)
{
    const Palette& p = Pal();
    const ImGuiID pid = ImGui::GetID(id);
    const bool open = ImGui::IsPopupOpen(pid, ImGuiPopupFlags_None);
    const ImGuiID kIn = anim::Key(pid, "in");
    if (!open)
    {
        g_popMem.SetBool(pid, false);
        return false;
    }
    if (!g_popMem.GetBool(pid, false)) // just opened: restart the intro
    {
        g_popMem.SetBool(pid, true);
        g_popMem.SetFloat(kIn, 0.0f);
    }
    float* progress = g_popMem.GetFloatRef(kIn, 0.0f);
    const float t = anim::ReducedMotion() ? 1.0f : *progress;
    *progress = ImMin(1.0f, *progress + ImGui::GetIO().DeltaTime * 7.0f);
    const float e = 1.0f - (1.0f - t) * (1.0f - t); // ease-out

    ImGui::SetNextWindowPos(anchor + ImVec2(0.0f, (1.0f - e) * S(8)), ImGuiCond_Always, pivot);
    ImGui::SetNextWindowSize(ImVec2(S(width), 0.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ImGui::GetStyle().Alpha * e);
    ImGui::PushStyleColor(ImGuiCol_PopupBg, ImGui::ColorConvertU32ToFloat4(p.card));
    ImGui::PushStyleColor(ImGuiCol_Border, ImGui::ColorConvertU32ToFloat4(Mix(p.border, p.text, 0.05f)));
    ImGui::PushStyleVar(ImGuiStyleVar_PopupRounding, S(radius::card));
    ImGui::PushStyleVar(ImGuiStyleVar_PopupBorderSize, 1.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(S(kCardPad), S(kCardPad)));
    const bool visible = ImGui::BeginPopup(id, ImGuiWindowFlags_NoMove);
    ImGui::PopStyleVar(3);
    ImGui::PopStyleColor(2);
    if (!visible)
    {
        ImGui::PopStyleVar(); // Alpha
        return false;
    }
    CardHeader(title, icon);
    return true;
}

void EndPopover()
{
    ImGui::EndPopup();
    ImGui::PopStyleVar(); // Alpha
}

} // namespace pz
