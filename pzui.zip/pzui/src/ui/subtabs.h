#pragma once
// Top chip strip. Active chip: accent-tinted fill + white text, with a highlight
// that slides between chips. Idle chips: outline only.
//
//   pz::BeginSubtabs("##tabs", ImVec2(w, 44));
//   if (pz::Subtab("General", pz::Icon::Crosshair, tab == 0)) tab = 0;
//   ...
//   pz::EndSubtabs();
#include "imgui.h"
#include "ui/icons.h"

namespace pz {

void BeginSubtabs(const char* id, ImVec2 size);
bool Subtab(const char* label, Icon icon, bool selected);
void EndSubtabs();

} // namespace pz
