#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS // ImVec2 operators; must precede imgui.h
#endif
#include "ui/sidebar.h"
#include "ui/anim.h"
#include "ui/controls.h"
#include "ui/theme.h"
#include "imgui_internal.h"

namespace pz {

constexpr float kPadX      = 10.0f;
constexpr float kPadY      = 13.0f;
constexpr float kNavH      = 36.0f;
constexpr float kNavGap    = 15.0f;
constexpr float kUserCardH = 50.0f;
constexpr float kFooterGap = 9.0f;
constexpr float kButtonH   = 35.0f;

// Draw-list channels: idle row backgrounds < sliding highlight < content.
enum { kChBack = 0, kChHighlight = 1, kChFront = 2 };

struct SidebarState
{
    ImGuiID            id = 0;
    ImDrawList*        dl = nullptr;
    ImDrawListSplitter split;
    ImRect             selected;
    bool               hasSelected = false;
    bool               inFooter = false;
};
static SidebarState g_sb;

void BeginSidebar(const char* id, ImVec2 size)
{
    const Palette& p = Pal();
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImGui::ColorConvertU32ToFloat4(p.sidebar));
    ImGui::PushStyleColor(ImGuiCol_Border, ImGui::ColorConvertU32ToFloat4(p.border));
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, S(radius::outer));
    ImGui::PushStyleVar(ImGuiStyleVar_ChildBorderSize, 1.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(S(kPadX), S(kPadY)));
    ImGui::BeginChild(id, size, ImGuiChildFlags_Borders | ImGuiChildFlags_AlwaysUseWindowPadding,
                      ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    ImGui::PopStyleVar(3);
    ImGui::PopStyleColor(2);
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, S(kNavGap)));

    g_sb.id = ImGui::GetID("##pz.sidebar");
    g_sb.dl = ImGui::GetWindowDrawList();
    g_sb.hasSelected = false;
    g_sb.inFooter = false;
    g_sb.split.Split(g_sb.dl, 3);
    g_sb.split.SetCurrentChannel(g_sb.dl, kChFront);
}

// Active pill look shared by the nav highlight and the settings button.
static void DrawActivePill(ImDrawList* dl, const ImRect& r, float glow, bool bar)
{
    const Palette& p = Pal();
    const float rr = S(radius::chip);
    const ImU32 tint = Mix(p.accent, p.text, 0.22f); // the mockup's active fill is a greyed mauve
    if (glow > 0.0f)
        DrawGlow(dl, r.Min, r.Max, p.accent, rr, S(9), 0.20f * glow);

    const int v0 = dl->VtxBuffer.Size;
    dl->AddRectFilled(r.Min, r.Max, C(IM_COL32_WHITE), rr);
    ImGui::ShadeVertsLinearColorGradientKeepAlpha(dl, v0, dl->VtxBuffer.Size, r.Min, ImVec2(r.Max.x, r.Min.y),
                                                  C(Mix(p.sidebar, tint, 0.42f)), C(Mix(p.sidebar, tint, 0.30f)));
    dl->AddRect(r.Min, r.Max, C(Mix(p.sidebar, Mix(p.accentG, p.text, 0.30f), 0.50f)), rr);
    // faint top sheen
    dl->AddLine(ImVec2(r.Min.x + rr, r.Min.y + 1.0f), ImVec2(r.Max.x - rr, r.Min.y + 1.0f), C(WithAlpha(p.text, 0.10f)));
    if (bar)
    {
        const float bw = S(4), inset = S(6);
        dl->AddRectFilled(ImVec2(r.Min.x + S(1), r.Min.y + inset), ImVec2(r.Min.x + S(1) + bw, r.Max.y - inset),
                          C(p.accentG), bw * 0.5f);
    }
}

void EndSidebar()
{
    ImDrawList* dl = g_sb.dl;
    g_sb.split.SetCurrentChannel(dl, kChHighlight);

    // Sliding highlight: animate top/bottom toward the selected row.
    const float vis = anim::To(anim::Key(g_sb.id, "vis"), g_sb.hasSelected ? 1.0f : 0.0f, 12.0f);
    if (g_sb.hasSelected || vis > 0.0f)
    {
        const float y0 = anim::To(anim::Key(g_sb.id, "y0"), g_sb.selected.Min.y, 16.0f);
        const float y1 = anim::To(anim::Key(g_sb.id, "y1"), g_sb.selected.Max.y, 16.0f);
        if (g_sb.hasSelected || vis > 0.01f)
        {
            ImGuiWindow* w = ImGui::GetCurrentWindow();
            dl->PushClipRect(w->Rect().Min, w->Rect().Max, false); // let the glow spill into the padding
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ImGui::GetStyle().Alpha * vis);
            const ImRect r(ImVec2(g_sb.selected.Min.x, y0), ImVec2(g_sb.selected.Max.x, y1));
            DrawActivePill(dl, r, 1.0f, true);
            ImGui::PopStyleVar();
            dl->PopClipRect();
        }
    }

    g_sb.split.Merge(dl);
    ImGui::PopStyleVar(g_sb.inFooter ? 2 : 1); // ItemSpacing (body + footer)
    ImGui::EndChild();
}

bool NavItem(const char* label, Icon icon, bool selected)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    const Palette& p = Pal();
    const ImGuiID id = window->GetID(label);
    const ImVec2 pos = window->DC.CursorPos;
    const ImRect bb(pos, pos + ImVec2(ImGui::GetContentRegionAvail().x, S(kNavH)));
    ImGui::ItemSize(bb.GetSize());
    if (!ImGui::ItemAdd(bb, id))
        return false;

    bool hovered, held;
    const bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);
    const float hov = anim::To(anim::Key(id, "hov"), hovered && !selected ? 1.0f : 0.0f);
    const float act = anim::To(anim::Key(id, "act"), selected ? 1.0f : 0.0f);
    if (selected) { g_sb.selected = bb; g_sb.hasSelected = true; }

    ImDrawList* dl = window->DrawList;
    const float rr = S(radius::chip);

    // Idle pill (below the sliding highlight)
    g_sb.split.SetCurrentChannel(dl, kChBack);
    dl->AddRectFilled(bb.Min, bb.Max, C(Mix(p.raised, Mix(p.raised, p.accent, 0.10f), hov)), rr);
    dl->AddRect(bb.Min, bb.Max, C(Mix(Mix(p.raised, p.border, 0.6f), Mix(p.border, p.accent, 0.35f), hov)), rr);
    g_sb.split.SetCurrentChannel(dl, kChFront);

    // Icon + label
    const ImU32 fg = C(Mix(Mix(p.textSoft, p.text, hov * 0.6f), p.text, act));
    const float iconSz = S(17);
    const ImVec2 iconC(bb.Min.x + S(21), bb.GetCenter().y);
    DrawIcon(dl, icon, iconC, iconSz, fg);

    PushFont(act > 0.5f ? Font::Bold : Font::Medium, fontsize::body);
    const char* end = ImGui::FindRenderedTextEnd(label);
    const ImVec2 ts = ImGui::CalcTextSize(label, end);
    dl->AddText(ImVec2(bb.Min.x + S(39), IM_ROUND(bb.GetCenter().y - ts.y * 0.5f)), fg, label, end);
    PopFont();

    return pressed;
}

void BeginSidebarFooter(float height)
{
    if (height <= 0.0f)
        height = S(kUserCardH) + S(kFooterGap) + S(kButtonH);
    ImGuiWindow* w = ImGui::GetCurrentWindow();
    const float y = w->InnerRect.Max.y - S(kPadY) + S(3) - height; // footer sits slightly closer to the edge
    if (y > w->DC.CursorPos.y)
        ImGui::SetCursorScreenPos(ImVec2(w->DC.CursorPos.x, y));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, S(kFooterGap)));
    g_sb.inFooter = true;
}

void UserCard(const char* name, const char* subtitle, Icon avatar)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return;

    const Palette& p = Pal();
    const ImVec2 pos = window->DC.CursorPos;
    const ImRect bb(pos, pos + ImVec2(ImGui::GetContentRegionAvail().x, S(kUserCardH)));
    ImGui::ItemSize(bb.GetSize());
    if (!ImGui::ItemAdd(bb, 0))
        return;

    ImDrawList* dl = window->DrawList;
    dl->AddRectFilled(bb.Min, bb.Max, C(Mix(p.raised, p.text, 0.015f)), S(radius::card));

    // Avatar tile
    const float t = S(34);
    const ImVec2 a0(bb.Min.x + S(8), IM_ROUND(bb.GetCenter().y - t * 0.5f));
    const ImRect tile(a0, a0 + ImVec2(t, t));
    dl->AddRectFilled(tile.Min, tile.Max, C(Mix(p.raised, p.accent, 0.20f)), S(radius::chip));
    dl->AddRect(tile.Min, tile.Max, C(Mix(p.raised, p.accent, 0.38f)), S(radius::chip));
    DrawIcon(dl, avatar, tile.GetCenter() + ImVec2(0, S(1)), S(19), C(p.accentG));

    // Name + subtitle
    const float tx = tile.Max.x + S(10);
    PushFont(Font::Bold, fontsize::body);
    const float h1 = ImGui::GetFontSize();
    dl->AddText(ImVec2(tx, IM_ROUND(bb.GetCenter().y - h1 + S(1))), C(p.text), name);
    PopFont();
    PushFont(Font::Medium, fontsize::body - 0.5f);
    dl->AddText(ImVec2(tx, IM_ROUND(bb.GetCenter().y + S(1))), C(p.dim), subtitle);
    PopFont();
}

bool SidebarButton(const char* label, Icon icon, bool active)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    const Palette& p = Pal();
    const ImGuiID id = window->GetID(label);
    const ImVec2 pos = window->DC.CursorPos;
    const ImRect bb(pos, pos + ImVec2(ImGui::GetContentRegionAvail().x, S(kButtonH)));
    ImGui::ItemSize(bb.GetSize());
    if (!ImGui::ItemAdd(bb, id))
        return false;

    bool hovered, held;
    const bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);
    const float lit = anim::To(anim::Key(id, "lit"), (hovered || active) ? 1.0f : 0.0f);
    const float press = anim::To(anim::Key(id, "press"), held ? 1.0f : 0.0f, 20.0f);

    ImDrawList* dl = window->DrawList;
    const float rr = S(radius::chip);
    dl->AddRectFilled(bb.Min, bb.Max, C(p.raised), rr);
    dl->AddRect(bb.Min, bb.Max, C(Mix(p.raised, p.border, 0.6f)), rr);
    if (lit > 0.0f)
    {
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ImGui::GetStyle().Alpha * lit);
        dl->PushClipRect(window->Rect().Min, window->Rect().Max, false);
        DrawActivePill(dl, bb, active ? 1.0f : 0.5f, false);
        dl->PopClipRect();
        ImGui::PopStyleVar();
    }
    if (press > 0.0f)
        dl->AddRectFilled(bb.Min, bb.Max, C(WithAlpha(p.backdrop, 0.25f * press)), rr);

    // Centred icon + label
    PushFont(Font::Medium, fontsize::body);
    const char* end = ImGui::FindRenderedTextEnd(label);
    const ImVec2 ts = ImGui::CalcTextSize(label, end);
    const float iconSz = S(17), gap = S(10);
    const float x0 = IM_ROUND(bb.GetCenter().x - (iconSz + gap + ts.x) * 0.5f);
    DrawIcon(dl, icon, ImVec2(x0 + iconSz * 0.5f, bb.GetCenter().y), iconSz, C(Mix(p.textSoft, p.accentG, ImMax(lit, 0.6f))));
    dl->AddText(ImVec2(x0 + iconSz + gap, IM_ROUND(bb.GetCenter().y - ts.y * 0.5f)), C(Mix(p.textSoft, p.text, lit)), label, end);
    PopFont();

    return pressed;
}

} // namespace pz
