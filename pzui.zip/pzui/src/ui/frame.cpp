#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS // ImVec2 operators; must precede imgui.h
#endif
#include "ui/frame.h"
#include "ui/controls.h"
#include "ui/theme.h"
#include "imgui_internal.h"

namespace pz {

static ImRect g_body;
static bool   g_dragging = false;

constexpr float kPad        = 12.0f; // frame edge -> header / body
constexpr float kHeaderH    = 42.0f;
constexpr float kHeaderGap  = 14.0f; // header -> body
constexpr float kSearchW    = 190.0f;

void BeginShell(const char* id, const char* brand, char* search, size_t searchSize, ImVec2 pos, ImVec2 size)
{
    const Palette& p = Pal();
    const ImGuiViewport* vp = ImGui::GetMainViewport();
    if (size.x <= 0.0f || size.y <= 0.0f) { pos = vp->Pos; size = vp->Size; }

    ImGui::SetNextWindowPos(pos);
    ImGui::SetNextWindowSize(size);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(S(kPad), S(kPad)));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, S(radius::outer));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.0f);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImGui::ColorConvertU32ToFloat4(p.bg));
    ImGui::PushStyleColor(ImGuiCol_Border, ImGui::ColorConvertU32ToFloat4(Mix(p.bg, p.text, 0.08f)));
    ImGui::Begin(id, nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
                 ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoDocking);
    ImGui::PopStyleColor(2);
    ImGui::PopStyleVar(3);

    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImVec2 wmin = ImGui::GetWindowPos(), wsize = ImGui::GetWindowSize();

    // Header bar
    const ImRect hdr(wmin + ImVec2(S(kPad), S(kPad)), ImVec2(wmin.x + wsize.x - S(kPad), wmin.y + S(kPad + kHeaderH)));
    const float hr = S(radius::panel);
    dl->AddRectFilled(hdr.Min, hdr.Max, C(Mix(p.sidebar, p.bg, 0.25f)), hr);
    dl->AddRect(hdr.Min, hdr.Max, C(p.border), hr);
    // bright bottom edge that fades out toward both ends
    {
        const float y = hdr.Max.y - 1.0f, x0 = hdr.Min.x + hr, x1 = hdr.Max.x - hr, xm = (x0 + x1) * 0.5f;
        const ImU32 edge = C(Mix(p.border, p.text, 0.16f)), clear = C(WithAlpha(p.border, 0.0f));
        dl->AddRectFilledMultiColor(ImVec2(x0, y), ImVec2(xm, y + 1.0f), clear, edge, edge, clear);
        dl->AddRectFilledMultiColor(ImVec2(xm, y), ImVec2(x1, y + 1.0f), edge, clear, clear, edge);
    }

    // Drag handle behind everything in the header
    ImGui::SetCursorScreenPos(hdr.Min);
    ImGui::SetNextItemAllowOverlap();
    ImGui::InvisibleButton("##pz.shell.drag", hdr.GetSize());
    g_dragging = ImGui::IsItemActive() && ImGui::IsMouseDragging(ImGuiMouseButton_Left, 0.0f);

    // Brand
    PushFont(Font::Bold, fontsize::brand);
    const ImVec2 ts = ImGui::CalcTextSize(brand);
    dl->AddText(ImVec2(hdr.Min.x + S(12), IM_ROUND(hdr.GetCenter().y - ts.y * 0.5f)), C(Mix(p.accent, p.text, 0.30f)), brand);
    PopFont();

    // Search (expands leftward from the magnifier)
    if (search && searchSize > 0)
    {
        const float h = S(28);
        ImGui::SetCursorScreenPos(ImVec2(hdr.Max.x - S(7) - S(kSearchW), IM_ROUND(hdr.GetCenter().y - h * 0.5f)));
        Search("##pz.shell.search", search, searchSize, S(kSearchW), true);
    }

    g_body = ImRect(ImVec2(hdr.Min.x, hdr.Max.y + S(kHeaderGap)), wmin + wsize - ImVec2(S(kPad), S(kPad)));
    ImGui::SetCursorScreenPos(g_body.Min);
}

void EndShell() { ImGui::End(); }

ImVec2 ShellBodyMin() { return g_body.Min; }
ImVec2 ShellBodySize() { return g_body.GetSize(); }
bool   ShellDragging() { return g_dragging; }

void BeginPanel(const char* id, ImVec2 size, float rounding, ImVec2 padding)
{
    const Palette& p = Pal();
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImGui::ColorConvertU32ToFloat4(p.sidebar));
    ImGui::PushStyleColor(ImGuiCol_Border, ImGui::ColorConvertU32ToFloat4(p.border));
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, S(rounding));
    ImGui::PushStyleVar(ImGuiStyleVar_ChildBorderSize, 1.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(S(padding.x), S(padding.y)));
    ImGui::BeginChild(id, size, ImGuiChildFlags_Borders | ImGuiChildFlags_AlwaysUseWindowPadding,
                      ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    ImGui::PopStyleVar(3);
    ImGui::PopStyleColor(2);
}

void EndPanel() { ImGui::EndChild(); }

} // namespace pz
