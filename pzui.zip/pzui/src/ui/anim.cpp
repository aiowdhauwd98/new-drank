#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS // ImVec2 operators; must precede imgui.h
#endif
#include "ui/anim.h"
#include "imgui_internal.h"

#include <cfloat>
#include <cmath>

namespace pz::anim {

static ImGuiStorage g_values;
static bool         g_reduced = false;

float To(ImGuiID id, float target, float speed)
{
    float* v = g_values.GetFloatRef(id, FLT_MAX);
    if (*v == FLT_MAX || g_reduced)
        return *v = target;

    const float k = 1.0f - std::exp(-speed * ImGui::GetIO().DeltaTime);
    *v += (target - *v) * k;
    if (std::fabs(target - *v) < 1e-3f)
        *v = target;
    return *v;
}

ImGuiID Key(ImGuiID id, const char* tag) { return ImHashStr(tag, 0, id); }

void SetReducedMotion(bool on) { g_reduced = on; }
bool ReducedMotion() { return g_reduced; }

} // namespace pz::anim
