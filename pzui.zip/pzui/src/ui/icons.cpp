#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS // ImVec2 operators; must precede imgui.h
#endif
#include "ui/icons.h"
#include "imgui_internal.h"

#include <cmath>

namespace pz {

static inline ImVec2 P(ImVec2 c, float s, float x, float y) { return ImVec2(c.x + x * s, c.y + y * s); }

void DrawCheckmark(ImDrawList* dl, ImVec2 c, float s, ImU32 col, float progress)
{
    if (progress <= 0.0f)
        return;
    const ImVec2 pts[3] = { P(c, s, -0.30f, 0.02f), P(c, s, -0.08f, 0.24f), P(c, s, 0.32f, -0.22f) };
    const float len0 = std::sqrt(ImLengthSqr(pts[1] - pts[0])), len1 = std::sqrt(ImLengthSqr(pts[2] - pts[1]));
    float d = ImSaturate(progress) * (len0 + len1);

    ImVec2 path[3] = { pts[0], pts[1], pts[2] };
    int n = 3;
    if (d < len0) { path[1] = ImLerp(pts[0], pts[1], d / len0); n = 2; }
    else          { path[2] = ImLerp(pts[1], pts[2], (d - len0) / len1); }
    dl->AddPolyline(path, n, col, ImDrawFlags_None, ImMax(1.5f, s * 0.15f));
}

void DrawTriangle(ImDrawList* dl, ImVec2 c, float s, ImU32 col, float angle)
{
    ImVec2 p[3] = { ImVec2(-0.30f, -0.15f), ImVec2(0.30f, -0.15f), ImVec2(0.0f, 0.19f) };
    const float ca = std::cos(angle), sa = std::sin(angle);
    for (ImVec2& v : p)
        v = ImVec2(c.x + (v.x * ca - v.y * sa) * s, c.y + (v.x * sa + v.y * ca) * s);
    dl->AddTriangleFilled(p[0], p[1], p[2], col);
}

// Filled ring with trapezoid teeth and a real hole: the ring is triangulated
// between the toothed outline and the hole circle (no AA), then both edges are
// stroked with a 1px AA line for smooth silhouettes.
void DrawGear(ImDrawList* dl, ImVec2 c, float R, ImU32 col, int teeth)
{
    constexpr int kMaxPts = 128;
    const float rBody = R * 0.74f, rHole = R * 0.34f;
    const float step = IM_PI * 2.0f / (float)teeth;
    const float halfBase = step * 0.30f, halfTop = step * 0.19f;

    float ang[kMaxPts], rad[kMaxPts];
    int n = 0;
    for (int k = 0; k < teeth && n + 6 <= kMaxPts; ++k)
    {
        const float a = k * step - IM_PI * 0.5f;
        ang[n] = a - halfBase; rad[n++] = rBody;
        ang[n] = a - halfTop;  rad[n++] = R;
        ang[n] = a + halfTop;  rad[n++] = R;
        ang[n] = a + halfBase; rad[n++] = rBody;
        // body arc up to the next tooth
        ang[n] = a + step * 0.5f - step * 0.10f; rad[n++] = rBody;
        ang[n] = a + step * 0.5f + step * 0.10f; rad[n++] = rBody;
    }

    ImVec2 outer[kMaxPts], hole[kMaxPts];
    for (int i = 0; i < n; ++i)
    {
        outer[i] = ImVec2(c.x + std::cos(ang[i]) * rad[i], c.y + std::sin(ang[i]) * rad[i]);
        hole[i]  = ImVec2(c.x + std::cos(ang[i]) * rHole, c.y + std::sin(ang[i]) * rHole);
    }

    const ImVec2 uv = dl->_Data->TexUvWhitePixel;
    dl->PrimReserve(n * 6, n * 2);
    const ImDrawIdx base = (ImDrawIdx)dl->_VtxCurrentIdx;
    for (int i = 0; i < n; ++i)
    {
        dl->PrimWriteVtx(outer[i], uv, col);
        dl->PrimWriteVtx(hole[i], uv, col);
    }
    for (int i = 0; i < n; ++i)
    {
        const ImDrawIdx o0 = (ImDrawIdx)(base + i * 2), h0 = (ImDrawIdx)(o0 + 1);
        const ImDrawIdx o1 = (ImDrawIdx)(base + ((i + 1) % n) * 2), h1 = (ImDrawIdx)(o1 + 1);
        dl->PrimWriteIdx(o0); dl->PrimWriteIdx(o1); dl->PrimWriteIdx(h1);
        dl->PrimWriteIdx(o0); dl->PrimWriteIdx(h1); dl->PrimWriteIdx(h0);
    }
    dl->AddPolyline(outer, n, col, ImDrawFlags_Closed, 1.0f);
    dl->AddCircle(c, rHole, col, 0, 1.0f);
}

void DrawIcon(ImDrawList* dl, Icon icon, ImVec2 c, float s, ImU32 col)
{
    const float t = ImMax(1.2f, s * 0.105f); // stroke thickness

    switch (icon)
    {
    case Icon::None:
        break;

    case Icon::Search:
    {
        const ImVec2 cc = P(c, s, -0.07f, -0.07f);
        const float r = s * 0.29f;
        dl->AddCircle(cc, r, col, 0, t * 1.1f);
        const ImVec2 dir(0.7071f, 0.7071f);
        dl->AddLine(cc + dir * (r + t * 0.4f), P(c, s, 0.40f, 0.40f), col, t * 1.35f);
        break;
    }

    case Icon::Crosshair:
    {
        // Thick ring with short outer ticks and a centre quartered by a plus-shaped gap.
        const float r = s * 0.31f;
        dl->AddCircle(c, r, col, 0, s * 0.13f);
        const ImVec2 dirs[4] = { ImVec2(1, 0), ImVec2(-1, 0), ImVec2(0, 1), ImVec2(0, -1) };
        for (const ImVec2& d : dirs)
            dl->AddLine(c + d * (r * 0.95f), c + d * (r * 1.50f), col, s * 0.12f);
        const float q = s * 0.105f, g = s * 0.035f;
        for (int i = 0; i < 4; ++i)
        {
            const float sx = (i & 1) ? 1.0f : -1.0f, sy = (i & 2) ? 1.0f : -1.0f;
            const ImVec2 a(c.x + sx * g, c.y + sy * g), b(c.x + sx * (g + q), c.y + sy * (g + q));
            dl->AddRectFilled(ImMin(a, b), ImMax(a, b), col);
        }
        break;
    }

    case Icon::Eye:
    {
        const float w = s * 0.46f, h = s * 0.30f;
        dl->PathLineTo(P(c, 1, -w, 0));
        dl->PathBezierCubicCurveTo(P(c, 1, -w * 0.45f, -h * 1.3f), P(c, 1, w * 0.45f, -h * 1.3f), P(c, 1, w, 0));
        dl->PathBezierCubicCurveTo(P(c, 1, w * 0.45f, h * 1.3f), P(c, 1, -w * 0.45f, h * 1.3f), P(c, 1, -w, 0));
        dl->PathStroke(col, ImDrawFlags_Closed, t);
        dl->AddCircleFilled(c, s * 0.15f, col);
        break;
    }

    case Icon::Sliders:
    {
        const float knobs[3] = { 0.18f, -0.16f, 0.06f };
        for (int i = 0; i < 3; ++i)
        {
            const float y = c.y + (i - 1) * s * 0.28f;
            dl->AddLine(ImVec2(c.x - s * 0.42f, y), ImVec2(c.x + s * 0.42f, y), col, t);
            dl->AddCircleFilled(ImVec2(c.x + knobs[i] * s, y), s * 0.12f, col);
        }
        break;
    }

    case Icon::Gear:
        DrawGear(dl, c, s * 0.46f, col);
        break;

    case Icon::Gears:
        DrawGear(dl, P(c, s, -0.14f, -0.13f), s * 0.31f, col);
        DrawGear(dl, P(c, s, 0.24f, 0.25f), s * 0.22f, col, 7);
        break;

    case Icon::ChevronDown:
    {
        const ImVec2 pts[3] = { P(c, s, -0.26f, -0.12f), P(c, s, 0.0f, 0.14f), P(c, s, 0.26f, -0.12f) };
        dl->AddPolyline(pts, 3, col, ImDrawFlags_None, t * 1.2f);
        break;
    }

    case Icon::ChevronRight:
    {
        const ImVec2 pts[3] = { P(c, s, -0.12f, -0.26f), P(c, s, 0.14f, 0.0f), P(c, s, -0.12f, 0.26f) };
        dl->AddPolyline(pts, 3, col, ImDrawFlags_None, t * 1.2f);
        break;
    }

    case Icon::TriangleDown:
        DrawTriangle(dl, c, s, col);
        break;

    case Icon::Avatar:
    {
        dl->AddCircleFilled(P(c, s, 0.0f, -0.17f), s * 0.19f, col);
        dl->PathArcTo(P(c, s, 0.0f, 0.40f), s * 0.33f, IM_PI, IM_PI * 2.0f);
        dl->PathFillConvex(col);
        break;
    }

    case Icon::Chat:
    {
        dl->AddRect(P(c, s, -0.42f, -0.34f), P(c, s, 0.42f, 0.20f), col, s * 0.14f, 0, t);
        dl->AddTriangleFilled(P(c, s, -0.22f, 0.18f), P(c, s, 0.0f, 0.18f), P(c, s, -0.26f, 0.42f), col);
        for (int i = -1; i <= 1; ++i)
            dl->AddCircleFilled(P(c, s, i * 0.18f, -0.07f), s * 0.05f, col);
        break;
    }

    case Icon::Keyboard:
    {
        dl->AddRect(P(c, s, -0.46f, -0.30f), P(c, s, 0.46f, 0.30f), col, s * 0.09f, 0, t);
        const float k = s * 0.055f;
        for (int row = 0; row < 2; ++row)
            for (int i = 0; i < 5; ++i)
            {
                const ImVec2 kc = P(c, s, -0.28f + i * 0.14f, -0.13f + row * 0.13f);
                dl->AddRectFilled(kc - ImVec2(k, k), kc + ImVec2(k, k), col);
            }
        dl->AddRectFilled(P(c, s, -0.20f, 0.12f), P(c, s, 0.20f, 0.18f), col);
        break;
    }

    case Icon::Check:
        DrawCheckmark(dl, c, s, col);
        break;

    case Icon::Close:
        dl->AddLine(P(c, s, -0.28f, -0.28f), P(c, s, 0.28f, 0.28f), col, t * 1.2f);
        dl->AddLine(P(c, s, 0.28f, -0.28f), P(c, s, -0.28f, 0.28f), col, t * 1.2f);
        break;

    case Icon::Bolt:
    {
        const ImVec2 pts[6] = { P(c, s, 0.10f, -0.46f), P(c, s, -0.30f, 0.06f), P(c, s, -0.02f, 0.06f),
                                P(c, s, -0.10f, 0.46f), P(c, s, 0.30f, -0.08f), P(c, s, 0.02f, -0.08f) };
        dl->AddConcavePolyFilled(pts, 6, col);
        break;
    }

    case Icon::Palette:
    {
        dl->AddCircle(c, s * 0.40f, col, 0, t);
        dl->AddCircleFilled(P(c, s, -0.15f, -0.13f), s * 0.07f, col);
        dl->AddCircleFilled(P(c, s, 0.12f, -0.17f), s * 0.07f, col);
        dl->AddCircleFilled(P(c, s, 0.18f, 0.08f), s * 0.07f, col);
        dl->AddCircleFilled(P(c, s, -0.08f, 0.17f), s * 0.09f, col);
        break;
    }

    case Icon::Layers:
    {
        const ImVec2 top[4] = { P(c, s, 0.0f, -0.40f), P(c, s, 0.42f, -0.16f), P(c, s, 0.0f, 0.08f), P(c, s, -0.42f, -0.16f) };
        dl->AddPolyline(top, 4, col, ImDrawFlags_Closed, t);
        const ImVec2 mid[3] = { P(c, s, -0.42f, 0.06f), P(c, s, 0.0f, 0.30f), P(c, s, 0.42f, 0.06f) };
        dl->AddPolyline(mid, 3, col, ImDrawFlags_None, t);
        break;
    }
    }
}

} // namespace pz
