#pragma once
// Big rounded sidebar: pill nav rows with a sliding, glowing active highlight,
// plus a footer pinned to the bottom (user card + settings pill).
//
//   pz::BeginSidebar("##nav", ImVec2(170, h));
//   if (pz::NavItem("Combat", pz::Icon::Crosshair, page == 0)) page = 0;
//   ...
//   pz::BeginSidebarFooter();
//   pz::UserCard("Guest", "version dev");
//   if (pz::SidebarButton("Settings", pz::Icon::Gear, prefsOpen)) ...;
//   pz::EndSidebar();
#include "imgui.h"
#include "ui/icons.h"

namespace pz {

void BeginSidebar(const char* id, ImVec2 size);
void EndSidebar();

// Nav row. Returns true when clicked. Exactly one row should be `selected`.
bool NavItem(const char* label, Icon icon, bool selected);

// Moves the cursor so the footer (default: UserCard + SidebarButton) ends at
// the bottom edge. Pass a custom height if you put something else there.
void BeginSidebarFooter(float height = 0.0f);

// Avatar card: rounded avatar tile, bold name, dim subtitle.
void UserCard(const char* name, const char* subtitle, Icon avatar = Icon::Avatar);

// Full-width pill button (centred icon + label). `active` keeps it lit, e.g.
// while the popover it opens is visible. Returns true when clicked.
bool SidebarButton(const char* label, Icon icon, bool active = false);

} // namespace pz
