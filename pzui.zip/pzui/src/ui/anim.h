#pragma once
// Tiny frame-rate independent animation store used by all pz:: widgets.
// Values are keyed by ImGuiID and approach their target exponentially.
#include "imgui.h"

namespace pz::anim {

// Moves the value stored at `id` toward `target` and returns it. The first call
// for an id snaps to the target. `speed` ~ 1/time-constant (14 = ~70 ms).
float To(ImGuiID id, float target, float speed = 14.0f);

// Derive a sub-key (e.g. Key(id, "hover")) so one widget can own several values.
ImGuiID Key(ImGuiID id, const char* tag);

// Global "reduce motion" switch: when on, every value snaps to its target.
void SetReducedMotion(bool on);
bool ReducedMotion();

} // namespace pz::anim
