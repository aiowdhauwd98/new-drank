#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS // ImVec2 operators; must precede imgui.h
#endif
#include "ui/theme.h"
#ifndef PZUI_NO_EMBEDDED_FONTS
#include "ui/fonts/quicksand.h"
#endif

#include <cstdio>
#include <cstdlib>
#include <string>

namespace pz {

static Palette g_palette;
static float   g_scale = 1.0f;
static ImFont* g_fonts[3] = {};
static float   g_faceScale = 1.0f; // fontsize:: is tuned for Quicksand; narrower fallback faces render larger

Palette& Pal() { return g_palette; }
float    Scale() { return g_scale; }

ImU32 Mix(ImU32 a, ImU32 b, float t)
{
    t = t < 0.0f ? 0.0f : (t > 1.0f ? 1.0f : t);
    ImU32 out = 0;
    for (int shift = 0; shift < 32; shift += 8)
    {
        const float ca = (float)((a >> shift) & 0xFF), cb = (float)((b >> shift) & 0xFF);
        out |= (ImU32)(ca + (cb - ca) * t + 0.5f) << shift;
    }
    return out;
}

ImU32 WithAlpha(ImU32 c, float alpha)
{
    alpha = alpha < 0.0f ? 0.0f : (alpha > 1.0f ? 1.0f : alpha);
    return (c & ~IM_COL32_A_MASK) | ((ImU32)(alpha * 255.0f + 0.5f) << IM_COL32_A_SHIFT);
}

ImU32 C(ImU32 c, float alphaMul) { return ImGui::GetColorU32(c, alphaMul); }

ImFont* GetFont(Font f)
{
    ImFont* font = g_fonts[(int)f];
    return font ? font : ImGui::GetFont();
}

void PushFont(Font f, float sizeUnscaled) { ImGui::PushFont(GetFont(f), sizeUnscaled * g_faceScale); }

namespace theme {

static ImVec4 V(ImU32 c) { return ImGui::ColorConvertU32ToFloat4(c); }

void ApplyColors()
{
    const Palette& p = g_palette;
    ImVec4* c = ImGui::GetStyle().Colors;
    const ImU32 none = 0;

    c[ImGuiCol_Text]                      = V(p.text);
    c[ImGuiCol_TextDisabled]              = V(p.dim);
    c[ImGuiCol_WindowBg]                  = V(p.bg);
    c[ImGuiCol_ChildBg]                   = V(none);
    c[ImGuiCol_PopupBg]                   = V(p.card);
    c[ImGuiCol_Border]                    = V(p.border);
    c[ImGuiCol_BorderShadow]              = V(none);
    c[ImGuiCol_FrameBg]                   = V(p.cardInner);
    c[ImGuiCol_FrameBgHovered]            = V(Mix(p.cardInner, p.accent, 0.08f));
    c[ImGuiCol_FrameBgActive]             = V(Mix(p.cardInner, p.accent, 0.14f));
    c[ImGuiCol_TitleBg]                   = V(p.sidebar);
    c[ImGuiCol_TitleBgActive]             = V(p.sidebar);
    c[ImGuiCol_TitleBgCollapsed]          = V(p.sidebar);
    c[ImGuiCol_MenuBarBg]                 = V(p.sidebar);
    c[ImGuiCol_ScrollbarBg]               = V(none);
    c[ImGuiCol_ScrollbarGrab]             = V(p.borderHi);
    c[ImGuiCol_ScrollbarGrabHovered]      = V(Mix(p.borderHi, p.accent, 0.4f));
    c[ImGuiCol_ScrollbarGrabActive]       = V(p.accent);
    c[ImGuiCol_CheckMark]                 = V(p.text);
    c[ImGuiCol_CheckboxSelectedBg]        = V(p.accent);
    c[ImGuiCol_SliderGrab]                = V(p.accent);
    c[ImGuiCol_SliderGrabActive]          = V(p.accentG);
    c[ImGuiCol_Button]                    = V(p.cardInner);
    c[ImGuiCol_ButtonHovered]             = V(Mix(p.cardInner, p.accent, 0.18f));
    c[ImGuiCol_ButtonActive]              = V(Mix(p.cardInner, p.accent, 0.30f));
    c[ImGuiCol_Header]                    = V(Mix(p.card, p.accent, 0.20f));
    c[ImGuiCol_HeaderHovered]             = V(Mix(p.card, p.accent, 0.12f));
    c[ImGuiCol_HeaderActive]              = V(Mix(p.card, p.accent, 0.28f));
    c[ImGuiCol_Separator]                 = V(p.border);
    c[ImGuiCol_SeparatorHovered]          = V(Mix(p.border, p.accent, 0.5f));
    c[ImGuiCol_SeparatorActive]           = V(p.accent);
    c[ImGuiCol_ResizeGrip]                = V(WithAlpha(p.accent, 0.15f));
    c[ImGuiCol_ResizeGripHovered]         = V(WithAlpha(p.accent, 0.45f));
    c[ImGuiCol_ResizeGripActive]          = V(WithAlpha(p.accent, 0.80f));
    c[ImGuiCol_InputTextCursor]           = V(p.text);
    c[ImGuiCol_TabHovered]                = V(Mix(p.raised, p.accent, 0.20f));
    c[ImGuiCol_Tab]                       = V(p.raised);
    c[ImGuiCol_TabSelected]               = V(Mix(p.raised, p.accent, 0.30f));
    c[ImGuiCol_TabSelectedOverline]       = V(p.accent);
    c[ImGuiCol_TabDimmed]                 = V(p.sidebar);
    c[ImGuiCol_TabDimmedSelected]         = V(p.raised);
    c[ImGuiCol_TabDimmedSelectedOverline] = V(WithAlpha(p.accent, 0.5f));
    c[ImGuiCol_DockingPreview]            = V(WithAlpha(p.accent, 0.45f));
    c[ImGuiCol_DockingEmptyBg]            = V(p.backdrop);
    c[ImGuiCol_PlotLines]                 = V(p.accent);
    c[ImGuiCol_PlotLinesHovered]          = V(p.accentG);
    c[ImGuiCol_PlotHistogram]             = V(p.accent);
    c[ImGuiCol_PlotHistogramHovered]      = V(p.accentG);
    c[ImGuiCol_TableHeaderBg]             = V(p.raised);
    c[ImGuiCol_TableBorderStrong]         = V(p.borderHi);
    c[ImGuiCol_TableBorderLight]          = V(p.border);
    c[ImGuiCol_TableRowBg]                = V(none);
    c[ImGuiCol_TableRowBgAlt]             = V(WithAlpha(p.text, 0.03f));
    c[ImGuiCol_TextLink]                  = V(p.accentG);
    c[ImGuiCol_TextSelectedBg]            = V(WithAlpha(p.accent, 0.35f));
    c[ImGuiCol_TreeLines]                 = V(p.border);
    c[ImGuiCol_DragDropTarget]            = V(p.accentG);
    c[ImGuiCol_DragDropTargetBg]          = V(WithAlpha(p.accent, 0.10f));
    c[ImGuiCol_UnsavedMarker]             = V(p.accentG);
    c[ImGuiCol_NavCursor]                 = V(p.accent);
    c[ImGuiCol_NavWindowingHighlight]     = V(WithAlpha(p.text, 0.70f));
    c[ImGuiCol_NavWindowingDimBg]         = V(WithAlpha(p.backdrop, 0.50f));
    c[ImGuiCol_ModalWindowDimBg]          = V(WithAlpha(p.backdrop, 0.55f));
}

void Apply(float scale)
{
    g_scale = scale > 0.0f ? scale : 1.0f;

    ImGuiStyle& st = ImGui::GetStyle();
    st = ImGuiStyle(); // reset so repeated calls don't compound ScaleAllSizes()

    st.WindowPadding     = ImVec2(12, 12);
    st.FramePadding      = ImVec2(10, 5);
    st.ItemSpacing       = ImVec2(8, 8);
    st.ItemInnerSpacing  = ImVec2(8, 6);
    st.CellPadding       = ImVec2(8, 4);
    st.IndentSpacing     = 16;
    st.ScrollbarSize     = 6;
    st.GrabMinSize       = 10;

    st.WindowBorderSize  = 1;
    st.ChildBorderSize   = 1;
    st.PopupBorderSize   = 1;
    st.FrameBorderSize   = 1;
    st.TabBorderSize     = 0;

    st.WindowRounding    = radius::outer;
    st.ChildRounding     = radius::card;
    st.FrameRounding     = radius::small;
    st.PopupRounding     = radius::small;
    st.ScrollbarRounding = radius::small;
    st.GrabRounding      = radius::small;
    st.TabRounding       = radius::chip;

    st.WindowTitleAlign  = ImVec2(0.0f, 0.5f);
    st.ButtonTextAlign   = ImVec2(0.5f, 0.5f);
    st.FontSizeBase      = fontsize::body * g_faceScale;

    ApplyColors();
    st.ScaleAllSizes(g_scale);
    st.FontScaleDpi = g_scale;
}

void SetAccent(ImU32 accent)
{
    g_palette.accent  = accent | IM_COL32_A_MASK;
    g_palette.accentG = Mix(g_palette.accent, Hex(0xFFFFFF), 0.28f);
    ApplyColors();
}

static bool FileExists(const std::string& path)
{
    FILE* f = nullptr;
    if (fopen_s(&f, path.c_str(), "rb") != 0 || !f)
        return false;
    fclose(f);
    return true;
}

// First existing file among candidates, searched in the per-user and system font folders.
static std::string FindFont(const char* const* candidates, int count)
{
    std::string dirs[2];
    char* env = nullptr;
    size_t len = 0;
    if (_dupenv_s(&env, &len, "LOCALAPPDATA") == 0 && env) { dirs[0] = std::string(env) + "\\Microsoft\\Windows\\Fonts\\"; free(env); }
    env = nullptr;
    if (_dupenv_s(&env, &len, "WINDIR") == 0 && env) { dirs[1] = std::string(env) + "\\Fonts\\"; free(env); }
    else dirs[1] = "C:\\Windows\\Fonts\\";

    for (int i = 0; i < count; ++i)
        for (const std::string& d : dirs)
            if (!d.empty() && FileExists(d + candidates[i]))
                return d + candidates[i];
    return {};
}

bool LoadFonts(const char* regularTtf, const char* mediumTtf, const char* boldTtf)
{
    // Per slot: explicit path > embedded Quicksand > installed Quicksand / Segoe UI > ImGui default.
    // The embedded set has Medium + Bold only; Regular uses Medium (Quicksand Regular is
    // too thin on dark backgrounds at UI sizes).
    static const char* const kInstalled[3][2] = {
        { "Quicksand-Medium.ttf", "segoeui.ttf" },
        { "Quicksand-Medium.ttf", "seguisb.ttf" },
        { "Quicksand-Bold.ttf", "segoeuib.ttf" },
    };
    // Merged under each face for glyphs Quicksand lacks (it covers Latin only).
    static const char* const kFallback[3] = { "segoeui.ttf", "seguisb.ttf", "segoeuib.ttf" };
    const char* const custom[3] = { regularTtf, mediumTtf, boldTtf };

    ImGuiIO& io = ImGui::GetIO();
    bool allLoaded = true, quicksand = false;
    for (int i = 0; i < 3; ++i)
    {
        ImFontConfig cfg;
        cfg.OversampleH = 2;
        cfg.OversampleV = 2;
        cfg.RasterizerMultiply = 1.08f; // stb_truetype renders slightly thin on dark backgrounds

        ImFont* f = nullptr;
        std::string path = custom[i] ? custom[i] : "";
#ifndef PZUI_NO_EMBEDDED_FONTS
        if (path.empty())
        {
            const std::string b85 = fonts::QuicksandBase85(i == (int)Font::Bold ? fonts::Quicksand::Bold : fonts::Quicksand::Medium);
            f = io.Fonts->AddFontFromMemoryCompressedBase85TTF(b85.c_str(), 0.0f, &cfg);
            if (f && i == (int)Font::Medium)
                quicksand = true;
        }
#endif
        if (!f && path.empty())
            path = FindFont(kInstalled[i], IM_ARRAYSIZE(kInstalled[i]));
        if (!f && !path.empty() && FileExists(path))
        {
            f = io.Fonts->AddFontFromFileTTF(path.c_str(), 0.0f, &cfg);
            if (f && i == (int)Font::Medium)
                quicksand = path.find("Quicksand") != std::string::npos;
        }
        if (!f)
        {
            allLoaded = false;
            g_fonts[i] = io.Fonts->AddFontDefaultVector(&cfg);
            continue;
        }

        const std::string fallback = FindFont(&kFallback[i], 1);
        if (!fallback.empty() && fallback != path)
        {
            ImFontConfig merge = cfg;
            merge.MergeMode = true;
            io.Fonts->AddFontFromFileTTF(fallback.c_str(), 0.0f, &merge);
        }
        g_fonts[i] = f;
    }
    io.FontDefault = g_fonts[(int)Font::Medium];

    // fontsize:: is tuned for Quicksand. Segoe UI gets the factor that equalizes cap height
    // (Quicksand cap/line = 0.560, Segoe UI = 0.526).
    g_faceScale = quicksand ? 1.0f : 1.064f;
    ImGui::GetStyle().FontSizeBase = fontsize::body * g_faceScale;
    return allLoaded;
}

} // namespace theme
} // namespace pz
