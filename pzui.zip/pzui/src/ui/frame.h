#pragma once
// Outer chrome: the rounded root frame, its header bar (brand + search) and
// recessed panels used to lay out the body.
#include "imgui.h"

namespace pz {

// Root window covering `pos`/`size` (defaults: the main viewport). Draws the
// rounded frame and a header bar with `brand` on the left and, when `search`
// is non-null, an expanding pz::Search field on the right.
// Always pair with EndShell().
void BeginShell(const char* id, const char* brand, char* search = nullptr, size_t searchSize = 0,
                ImVec2 pos = ImVec2(0, 0), ImVec2 size = ImVec2(0, 0));
void EndShell();

// Body area under the header, in screen space (valid between Begin/EndShell).
ImVec2 ShellBodyMin();
ImVec2 ShellBodySize();

// True while the user drags the header's empty area. Host apps with a
// borderless OS window move it while this is true (see demo/main.cpp).
bool ShellDragging();

// Recessed rounded container (content area, etc). Child window: content is
// clipped and scrolls if it overflows. Always pair with EndPanel().
void BeginPanel(const char* id, ImVec2 size, float rounding = 16.0f, ImVec2 padding = ImVec2(10, 10));
void EndPanel();

} // namespace pz
