#pragma once
// pzui theme: palette, metrics, fonts and ImGuiStyle setup.
// Every pz:: widget reads its colors from pz::Pal() at draw time, so changing
// the palette (or calling SetAccent) restyles the whole UI on the next frame.
#include "imgui.h"

namespace pz {

// 0xRRGGBB (+ alpha) -> packed ImU32 usable with ImDrawList.
constexpr ImU32 Hex(unsigned rgb, unsigned a = 0xFF)
{
    return ((ImU32)a << IM_COL32_A_SHIFT) | (((rgb >> 16) & 0xFFu) << IM_COL32_R_SHIFT) |
           (((rgb >> 8) & 0xFFu) << IM_COL32_G_SHIFT) | ((rgb & 0xFFu) << IM_COL32_B_SHIFT);
}

// Colors sampled from the reference mockup. Layering, darkest to lightest:
// backdrop < sidebar (recessed panels) < card < bg (outer frame).
struct Palette
{
    ImU32 backdrop  = Hex(0x090D13); // behind the outer frame (clear color)
    ImU32 bg        = Hex(0x131A27); // outer frame fill
    ImU32 sidebar   = Hex(0x0D151E); // recessed panels: header, sidebar, chip strip, content
    ImU32 card      = Hex(0x111B28); // nested cards, popovers
    ImU32 cardInner = Hex(0x0D1520); // fields inside cards: combo, input, button, track
    ImU32 raised    = Hex(0x121A25); // idle pills on panels: nav rows, user card
    ImU32 border    = Hex(0x1B2430); // panel / card outlines
    ImU32 borderHi  = Hex(0x2A3341); // control outlines (combo, checkbox, button)
    ImU32 accent    = Hex(0xC48ACB); // pink / lavender
    ImU32 accentG   = Hex(0xDDA8E0); // glow / hover
    ImU32 text      = Hex(0xECEEF4);
    ImU32 textSoft  = Hex(0x9AA1AB); // idle labels, nav text
    ImU32 dim       = Hex(0x7A828D); // value readouts, subtitles
    ImU32 groupLbl  = Hex(0x565E6A); // section labels, separators dots
};
Palette& Pal();

// Corner radii (unscaled px).
namespace radius {
constexpr float outer = 16.0f; // outer frame, sidebar, content panel
constexpr float panel = 12.0f; // header bar, chip strip
constexpr float card  = 10.0f; // cards, popovers
constexpr float chip  = 8.0f;  // chips, nav pills, buttons
constexpr float small = 6.0f;  // combos, inputs, popup lists
constexpr float tiny  = 4.0f;  // checkbox box, color swatch
}

// Font sizes (unscaled px), tuned for the embedded Quicksand. If LoadFonts()
// falls back to the narrower Segoe UI it applies a size factor automatically.
namespace fontsize {
constexpr float body  = 18.0f;
constexpr float title = 18.5f;
constexpr float small = 13.5f;
constexpr float brand = 19.0f;
}

enum class Font { Regular, Medium, Bold };

namespace theme {
// Writes ImGuiStyle sizes + colors from Pal() and sets the global UI scale
// (pass the monitor DPI scale, e.g. ImGui_ImplWin32_GetDpiScaleForHwnd).
void Apply(float scale = 1.0f);
// Re-maps only ImGuiStyle colors from Pal() (cheap; call after editing Pal()).
void ApplyColors();
// Changes the accent and derives the glow color from it, then ApplyColors().
void SetAccent(ImU32 accent);
// Loads Regular / Medium / Bold faces. nullptr = the embedded Quicksand (SIL OFL,
// src/ui/fonts), or installed Quicksand / Segoe UI if built with
// PZUI_NO_EMBEDDED_FONTS. Segoe UI is merged in for glyphs Quicksand lacks.
// Call once after ImGui::CreateContext(), before the first NewFrame().
bool LoadFonts(const char* regularTtf = nullptr, const char* mediumTtf = nullptr, const char* boldTtf = nullptr);
} // namespace theme

float   Scale();
inline float S(float px) { return px * Scale(); }
ImFont* GetFont(Font f);
void    PushFont(Font f, float sizeUnscaled = fontsize::body);
inline void PopFont() { ImGui::PopFont(); }

// Color helpers.
ImU32 Mix(ImU32 a, ImU32 b, float t);   // lerp all four channels
ImU32 WithAlpha(ImU32 c, float alpha);  // replace alpha (0..1)
ImU32 C(ImU32 c, float alphaMul = 1.0f); // apply style.Alpha (fades) + extra multiplier

} // namespace pz
