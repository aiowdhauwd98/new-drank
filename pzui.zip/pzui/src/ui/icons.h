#pragma once
// Vector icons drawn with ImDrawList: resolution independent, tinted per call.
#include "imgui.h"

namespace pz {

enum class Icon
{
    None,
    Search,
    Crosshair,
    Eye,
    Sliders,
    Gear,
    Gears,
    ChevronDown,
    ChevronRight,
    TriangleDown,
    Avatar,
    Chat,
    Keyboard,
    Check,
    Close,
    Bolt,
    Palette,
    Layers,
};

// Draws `icon` centred on `center`, fitting a `size` x `size` box.
void DrawIcon(ImDrawList* dl, Icon icon, ImVec2 center, float size, ImU32 col);

// Building blocks, exposed for custom widgets.
void DrawCheckmark(ImDrawList* dl, ImVec2 center, float size, ImU32 col, float progress = 1.0f);
void DrawGear(ImDrawList* dl, ImVec2 center, float outerRadius, ImU32 col, int teeth = 8);
void DrawTriangle(ImDrawList* dl, ImVec2 center, float size, ImU32 col, float angleRad = 0.0f); // points down at 0

} // namespace pz
