#pragma once
// Umbrella header for the pzui theme + widget pack.
#include "ui/theme.h"
#include "ui/anim.h"
#include "ui/icons.h"
#include "ui/frame.h"
#include "ui/sidebar.h"
#include "ui/subtabs.h"
#include "ui/card.h"
#include "ui/controls.h"
