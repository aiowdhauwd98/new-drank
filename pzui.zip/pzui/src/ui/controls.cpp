#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS // ImVec2 operators; must precede imgui.h
#endif
#include "ui/controls.h"
#include "ui/anim.h"
#include "ui/theme.h"
#include "imgui_internal.h"

#include <cmath>
#include <cstdio>
#include <cstring>

namespace pz {

constexpr float kRowH    = 20.0f; // checkbox / swatch row
constexpr float kBox     = 16.0f; // checkbox box
constexpr float kFieldH  = 24.0f; // combo field
constexpr float kInputH  = 26.0f; // text input
constexpr float kButtonH = 26.0f;
constexpr float kTrackH  = 7.0f;
constexpr float kThumbR  = 5.5f;

static ImGuiStorage g_mem; // last-frame focus / open flags

static ImVec4 V(ImU32 c) { return ImGui::ColorConvertU32ToFloat4(c); }

void DrawGlow(ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 col, float rounding, float radius, float intensity)
{
    if (intensity <= 0.0f || radius <= 0.0f)
        return;
    constexpr int kSteps = 8;
    for (int i = kSteps; i >= 1; --i)
    {
        const float t = (float)i / kSteps; // 1 = outermost layer
        const float e = radius * t;
        const float alpha = intensity * (2.0f / kSteps) * (1.0f - t + 1.0f / kSteps);
        dl->AddRectFilled(a - ImVec2(e, e), b + ImVec2(e, e), C(WithAlpha(col, alpha)), rounding + e);
    }
}

// Visible label drawn on its own line above a field.
static void RowLabel(const char* label, const char* end)
{
    PushFont(Font::Medium, fontsize::body);
    ImGui::PushStyleColor(ImGuiCol_Text, V(Mix(Pal().textSoft, Pal().text, 0.25f)));
    ImGui::TextUnformatted(label, end);
    ImGui::PopStyleColor();
    PopFont();
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() - ImGui::GetStyle().ItemSpacing.y + S(4));
}

// ---------------------------------------------------------------------------
// Checkbox
// ---------------------------------------------------------------------------
bool Checkbox(const char* label, bool* v)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    const Palette& p = Pal();
    const ImGuiID id = window->GetID(label);
    const char* end = ImGui::FindRenderedTextEnd(label);

    PushFont(*v ? Font::Bold : Font::Medium, fontsize::body); // checked rows read bold, as in the mockup
    const ImVec2 ts = ImGui::CalcTextSize(label, end);
    const float box = S(kBox);
    const ImVec2 pos = window->DC.CursorPos;
    const ImRect bb(pos, pos + ImVec2(box + (ts.x > 0.0f ? S(9) + ts.x : 0.0f), S(kRowH)));
    ImGui::ItemSize(bb.GetSize());
    if (!ImGui::ItemAdd(bb, id))
    {
        PopFont();
        return false;
    }

    bool hovered, held;
    const bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);
    if (pressed)
    {
        *v = !*v;
        ImGui::MarkItemEdited(id);
    }
    const float on  = anim::To(anim::Key(id, "on"), *v ? 1.0f : 0.0f, 16.0f);
    const float hov = anim::To(anim::Key(id, "hov"), hovered ? 1.0f : 0.0f);

    ImDrawList* dl = window->DrawList;
    const ImVec2 b0(pos.x, IM_ROUND(bb.GetCenter().y - box * 0.5f));
    const ImRect b(b0, b0 + ImVec2(box, box));
    const float rr = S(radius::tiny);

    dl->AddRectFilled(b.Min, b.Max, C(Mix(p.cardInner, p.accent, 0.06f * hov)), rr);
    if (on > 0.0f)
    {
        DrawGlow(dl, b.Min, b.Max, p.accent, rr, S(4), 0.08f * on);
        dl->AddRectFilled(b.Min, b.Max, C(Mix(p.accent, Mix(p.accent, p.textSoft, 0.5f), 0.22f), on), rr);
    }
    const ImU32 border = Mix(Mix(p.borderHi, Mix(p.borderHi, p.accent, 0.55f), hov), p.accentG, on);
    dl->AddRect(b.Min, b.Max, C(border), rr);
    DrawCheckmark(dl, b.GetCenter() + ImVec2(0, S(0.5f)), box, C(Hex(0xFFFFFF)), on);

    if (ts.x > 0.0f)
    {
        const ImU32 col = Mix(Mix(p.textSoft, p.text, hov * 0.5f), p.text, on);
        dl->AddText(ImVec2(b.Max.x + S(9), IM_ROUND(bb.GetCenter().y - ts.y * 0.5f)), C(col), label, end);
    }
    PopFont();
    return pressed;
}

// ---------------------------------------------------------------------------
// Slider
// ---------------------------------------------------------------------------
// Shared layout/interaction on a normalized value; `format` writes the readout.
template <typename Format>
static bool SliderCore(const char* label, float* t, Format&& format)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    const Palette& p = Pal();
    const ImGuiID id = window->GetID(label);
    const char* end = ImGui::FindRenderedTextEnd(label);
    const float w = ImGui::GetContentRegionAvail().x;

    PushFont(Font::Medium, fontsize::body);
    const float lineH = ImGui::GetFontSize();
    const ImVec2 pos = window->DC.CursorPos;
    const float rowH = S(12), rowY = pos.y + lineH + S(8);
    const ImRect total(pos, ImVec2(pos.x + w, rowY + rowH + S(8))); // bottom pad: sliders breathe more than rows
    const ImRect grab(ImVec2(pos.x, rowY - S(3)), ImVec2(pos.x + w, rowY + rowH + S(3)));
    ImGui::ItemSize(total.GetSize());
    if (!ImGui::ItemAdd(total, id))
    {
        PopFont();
        return false;
    }

    bool hovered, held;
    ImGui::ButtonBehavior(grab, id, &hovered, &held);

    const float r = S(kThumbR);
    const ImRect track(ImVec2(pos.x, rowY + (rowH - S(kTrackH)) * 0.5f), ImVec2(pos.x + w, rowY + (rowH + S(kTrackH)) * 0.5f));
    const float x0 = track.Min.x + r, x1 = track.Max.x - r;

    bool changed = false;
    if (held && x1 > x0)
    {
        const float nt = ImSaturate((ImGui::GetIO().MousePos.x - x0) / (x1 - x0));
        if (nt != *t)
        {
            *t = nt;
            changed = true;
            ImGui::MarkItemEdited(id);
        }
    }
    const float ta  = anim::To(anim::Key(id, "t"), *t, held ? 40.0f : 18.0f);
    const float hov = anim::To(anim::Key(id, "hov"), hovered ? 1.0f : 0.0f);
    const float act = anim::To(anim::Key(id, "act"), held ? 1.0f : 0.0f, 18.0f);

    ImDrawList* dl = window->DrawList;

    // Label + readout
    char readout[64];
    format(*t, readout, (int)sizeof(readout));
    dl->AddText(pos, C(Mix(p.textSoft, p.text, 0.25f + 0.5f * ImMax(hov, act))), label, end);
    const ImVec2 rs = ImGui::CalcTextSize(readout);
    dl->AddText(ImVec2(pos.x + w - rs.x, pos.y), C(Mix(p.dim, p.text, act * 0.6f)), readout);

    // Track, fill, thumb
    const float tr = S(kTrackH) * 0.5f;
    dl->AddRectFilled(track.Min, track.Max, C(Mix(p.cardInner, p.backdrop, 0.5f)), tr);
    dl->AddRect(track.Min, track.Max, C(Mix(p.borderHi, p.border, 0.3f)), tr);
    const float tx = x0 + (x1 - x0) * ta;
    const int v0 = dl->VtxBuffer.Size;
    dl->AddRectFilled(track.Min, ImVec2(tx, track.Max.y), C(IM_COL32_WHITE), tr);
    ImGui::ShadeVertsLinearColorGradientKeepAlpha(dl, v0, dl->VtxBuffer.Size, track.Min, ImVec2(ImMax(tx, track.Min.x + 1.0f), track.Min.y),
                                                  C(Mix(p.accent, p.card, 0.18f)), C(p.accent));

    const ImVec2 tc(tx, track.GetCenter().y);
    const float rt = r * (1.0f + 0.15f * ImMax(hov, act));
    DrawGlow(dl, tc - ImVec2(rt, rt), tc + ImVec2(rt, rt), p.accent, rt, S(5), 0.20f + 0.40f * act);
    dl->AddCircleFilled(tc, rt, C(Hex(0xF4F7FC)));

    PopFont();
    return changed;
}

bool SliderFloat(const char* label, float* v, float vMin, float vMax, const char* fmt)
{
    const float range = vMax - vMin;
    float t = range != 0.0f ? ImSaturate((*v - vMin) / range) : 0.0f;
    const bool changed = SliderCore(label, &t, [&](float tt, char* buf, int n) {
        std::snprintf(buf, (size_t)n, fmt, (double)(vMin + tt * range));
    });
    if (changed)
        *v = vMin + t * range;
    return changed;
}

bool SliderInt(const char* label, int* v, int vMin, int vMax, const char* fmt)
{
    const float range = (float)(vMax - vMin);
    float t = range != 0.0f ? ImSaturate((float)(*v - vMin) / range) : 0.0f;
    auto toInt = [&](float tt) { return vMin + (int)std::lround(tt * range); };
    const bool changed = SliderCore(label, &t, [&](float tt, char* buf, int n) { std::snprintf(buf, (size_t)n, fmt, toInt(tt)); });
    if (changed)
    {
        const int nv = toInt(t);
        if (nv == *v)
            return false;
        *v = nv;
    }
    return changed;
}

// ---------------------------------------------------------------------------
// Combo
// ---------------------------------------------------------------------------
static bool ComboBegin(const char* label, const char* preview)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    const Palette& p = Pal();
    const char* end = ImGui::FindRenderedTextEnd(label);
    if (end != label)
        RowLabel(label, end);

    const ImGuiID id = window->GetID(label);
    const float w = ImGui::GetContentRegionAvail().x, h = S(kFieldH);
    const ImVec2 pos = window->DC.CursorPos;
    const ImRect bb(pos, pos + ImVec2(w, h));
    ImGui::ItemSize(bb.GetSize());
    if (!ImGui::ItemAdd(bb, id))
        return false;

    const ImGuiID popupId = ImHashStr("##pz.combo", 0, id);
    bool open = ImGui::IsPopupOpen(popupId, ImGuiPopupFlags_None);
    bool hovered, held;
    if (ImGui::ButtonBehavior(bb, id, &hovered, &held) && !open)
    {
        ImGui::OpenPopupEx(popupId, ImGuiPopupFlags_None);
        open = true;
    }
    const float hov = anim::To(anim::Key(id, "hov"), hovered ? 1.0f : 0.0f);
    const float opn = anim::To(anim::Key(id, "open"), open ? 1.0f : 0.0f, 16.0f);

    ImDrawList* dl = window->DrawList;
    const float rr = S(radius::small);
    dl->AddRectFilled(bb.Min, bb.Max, C(Mix(p.cardInner, p.accent, 0.04f * hov)), rr);
    dl->AddRect(bb.Min, bb.Max, C(Mix(p.borderHi, Mix(p.borderHi, p.accent, 0.6f), ImMax(hov * 0.6f, opn))), rr);

    const float bw = S(22), sx = IM_ROUND(bb.Max.x - bw);
    dl->AddLine(ImVec2(sx, bb.Min.y + S(5)), ImVec2(sx, bb.Max.y - S(5)), C(p.borderHi));
    DrawTriangle(dl, ImVec2(sx + bw * 0.5f, bb.GetCenter().y + S(0.5f)), S(14), C(Mix(p.text, p.accentG, opn)), opn * IM_PI);

    PushFont(Font::Medium, fontsize::body);
    const ImVec2 ts = ImGui::CalcTextSize(preview);
    dl->PushClipRect(bb.Min, ImVec2(sx - S(4), bb.Max.y), true);
    dl->AddText(ImVec2(bb.Min.x + S(8), IM_ROUND(bb.GetCenter().y - ts.y * 0.5f)), C(Mix(p.textSoft, p.text, 0.15f + 0.3f * hov)), preview);
    dl->PopClipRect();
    PopFont();

    if (!open)
        return false;

    ImGui::PushStyleColor(ImGuiCol_PopupBg, V(Mix(p.card, p.cardInner, 0.35f)));
    ImGui::PushStyleColor(ImGuiCol_Border, V(p.borderHi));
    ImGui::PushStyleVar(ImGuiStyleVar_PopupRounding, S(radius::small));
    ImGui::PushStyleVar(ImGuiStyleVar_PopupBorderSize, 1.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(S(4), S(4)));
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(S(4), ImGui::GetStyle().FramePadding.y)); // popup x-padding
    const bool ok = ImGui::BeginComboPopup(popupId, bb, ImGuiComboFlags_None);
    ImGui::PopStyleVar(4);
    ImGui::PopStyleColor(2);
    if (ok)
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, S(2)));
    return ok;
}

static void ComboEnd()
{
    ImGui::PopStyleVar();
    ImGui::EndCombo();
}

static bool ComboItem(const char* text, bool selected, bool multi)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    const Palette& p = Pal();
    const ImGuiID id = window->GetID(text);
    const ImVec2 pos = window->DC.CursorPos;
    const ImRect bb(pos, pos + ImVec2(ImGui::GetContentRegionAvail().x, S(24)));
    ImGui::ItemSize(bb.GetSize());
    if (!ImGui::ItemAdd(bb, id))
        return false;

    bool hovered, held;
    const bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);
    const float hov = anim::To(anim::Key(id, "hov"), hovered ? 1.0f : 0.0f, 20.0f);

    ImDrawList* dl = window->DrawList;
    if (hov > 0.0f)
        dl->AddRectFilled(bb.Min, bb.Max, C(Mix(p.card, p.accent, 0.16f), hov), S(radius::tiny));

    PushFont(Font::Medium, fontsize::body);
    const ImVec2 ts = ImGui::CalcTextSize(text);
    const ImU32 col = selected ? p.accentG : Mix(p.textSoft, p.text, hov);
    dl->AddText(ImVec2(bb.Min.x + S(8), IM_ROUND(bb.GetCenter().y - ts.y * 0.5f)), C(col), text);
    PopFont();

    const ImVec2 rc(bb.Max.x - S(13), bb.GetCenter().y);
    if (multi)
    {
        const float bs = S(12);
        const ImRect b(rc - ImVec2(bs, bs) * 0.5f, rc + ImVec2(bs, bs) * 0.5f);
        if (selected)
        {
            dl->AddRectFilled(b.Min, b.Max, C(p.accent), S(3));
            DrawCheckmark(dl, rc, bs, C(Hex(0xFFFFFF)));
        }
        else
            dl->AddRect(b.Min, b.Max, C(p.borderHi), S(3));
    }
    else if (selected)
        DrawIcon(dl, Icon::Check, rc, S(13), C(p.accentG));
    return pressed;
}

bool Combo(const char* label, int* current, const char* const items[], int count)
{
    const char* preview = (*current >= 0 && *current < count) ? items[*current] : "";
    if (!ComboBegin(label, preview))
        return false;

    bool changed = false;
    for (int i = 0; i < count; ++i)
    {
        ImGui::PushID(i);
        if (ComboItem(items[i], i == *current, false))
        {
            changed = *current != i;
            *current = i;
            ImGui::CloseCurrentPopup();
        }
        ImGui::PopID();
    }
    ComboEnd();
    return changed;
}

bool MultiCombo(const char* label, bool* selected, const char* const items[], int count, const char* emptyText)
{
    char preview[256] = {};
    for (int i = 0; i < count; ++i)
        if (selected[i])
        {
            if (preview[0])
                strncat_s(preview, ", ", _TRUNCATE);
            strncat_s(preview, items[i], _TRUNCATE);
        }
    if (!ComboBegin(label, preview[0] ? preview : emptyText))
        return false;

    bool changed = false;
    for (int i = 0; i < count; ++i)
    {
        ImGui::PushID(i);
        if (ComboItem(items[i], selected[i], true))
        {
            selected[i] = !selected[i];
            changed = true;
        }
        ImGui::PopID();
    }
    ComboEnd();
    return changed;
}

// ---------------------------------------------------------------------------
// Button
// ---------------------------------------------------------------------------
bool Button(const char* label, ImVec2 size)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    const Palette& p = Pal();
    const ImGuiID id = window->GetID(label);
    const ImVec2 pos = window->DC.CursorPos;
    const ImRect bb(pos, pos + ImVec2(size.x > 0.0f ? size.x : ImGui::GetContentRegionAvail().x, size.y > 0.0f ? size.y : S(kButtonH)));
    ImGui::ItemSize(bb.GetSize());
    if (!ImGui::ItemAdd(bb, id))
        return false;

    bool hovered, held;
    const bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);
    const float hov = anim::To(anim::Key(id, "hov"), hovered ? 1.0f : 0.0f);
    const float prs = anim::To(anim::Key(id, "prs"), held ? 1.0f : 0.0f, 22.0f);

    ImDrawList* dl = window->DrawList;
    const float rr = S(radius::chip);
    DrawGlow(dl, bb.Min, bb.Max, p.accent, rr, S(7), 0.12f * hov);
    const ImU32 base = Mix(p.cardInner, p.card, 0.6f);
    dl->AddRectFilled(bb.Min, bb.Max, C(Mix(Mix(base, Mix(base, p.accent, 0.16f), hov), Mix(base, p.accent, 0.28f), prs)), rr);
    dl->AddRect(bb.Min, bb.Max, C(Mix(p.borderHi, Mix(p.borderHi, p.accentG, 0.55f), hov)), rr);

    PushFont(Font::Medium, fontsize::body);
    const char* end = ImGui::FindRenderedTextEnd(label);
    const ImVec2 ts = ImGui::CalcTextSize(label, end);
    dl->AddText(ImVec2(IM_ROUND(bb.GetCenter().x - ts.x * 0.5f), IM_ROUND(bb.GetCenter().y - ts.y * 0.5f)),
                C(Mix(Mix(p.textSoft, p.text, 0.25f), p.text, hov)), label, end);
    PopFont();
    return pressed;
}

// ---------------------------------------------------------------------------
// Text fields
// ---------------------------------------------------------------------------
static void PushFieldStyle(float height, ImU32 bg, ImU32 border)
{
    ImGui::PushStyleColor(ImGuiCol_FrameBg, V(bg));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, V(bg));
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive, V(bg));
    ImGui::PushStyleColor(ImGuiCol_Border, V(border));
    ImGui::PushStyleColor(ImGuiCol_TextDisabled, V(Pal().dim));
    ImGui::PushStyleColor(ImGuiCol_NavCursor, V(0)); // focus is shown by the accent border instead
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, S(radius::small));
    ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, (border >> IM_COL32_A_SHIFT) ? 1.0f : 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(S(8), ImMax(0.0f, IM_ROUND((height - ImGui::GetFontSize()) * 0.5f))));
}

static void PopFieldStyle()
{
    ImGui::PopStyleVar(3);
    ImGui::PopStyleColor(6);
}

bool InputText(const char* label, char* buf, size_t bufSize, const char* hint)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    const Palette& p = Pal();
    const char* end = ImGui::FindRenderedTextEnd(label);
    if (end != label)
        RowLabel(label, end);

    const ImGuiID key = window->GetID(label);
    const float hovT = anim::To(anim::Key(key, "hov"), g_mem.GetBool(anim::Key(key, "hov"), false) ? 1.0f : 0.0f);
    const float focus = anim::To(anim::Key(key, "focus"), g_mem.GetBool(key, false) ? 1.0f : 0.0f);
    const ImU32 border = Mix(Mix(p.borderHi, Mix(p.borderHi, p.accent, 0.4f), hovT), Mix(p.borderHi, p.accent, 0.8f), focus);

    PushFont(Font::Medium, fontsize::body);
    PushFieldStyle(S(kInputH), Mix(p.cardInner, p.accent, 0.03f * hovT), border);
    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
    ImGui::PushID(label);
    const bool changed = ImGui::InputTextWithHint("##v", hint ? hint : "", buf, bufSize);
    ImGui::PopID();
    g_mem.SetBool(key, ImGui::IsItemActive());
    g_mem.SetBool(anim::Key(key, "hov"), ImGui::IsItemHovered());
    PopFieldStyle();
    PopFont();
    return changed;
}

bool Search(const char* id, char* buf, size_t bufSize, float width, bool collapsible)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    const Palette& p = Pal();
    const ImGuiID sid = window->GetID(id);
    const ImGuiID kOpen = anim::Key(sid, "open"), kFocus = anim::Key(sid, "focus"), kActive = anim::Key(sid, "active");
    const float W = width > 0.0f ? width : ImGui::GetContentRegionAvail().x;
    const float h = S(28);
    const ImVec2 pos = window->DC.CursorPos;

    const bool open = !collapsible || buf[0] != 0 || g_mem.GetBool(kOpen, false);
    const float e = collapsible ? anim::To(anim::Key(sid, "e"), open ? 1.0f : 0.0f, 16.0f) : 1.0f;
    const float act = anim::To(anim::Key(sid, "act"), g_mem.GetBool(kActive, false) ? 1.0f : 0.0f);
    const ImRect fr(ImVec2(IM_ROUND(pos.x + W - ImLerp(h, W, e)), pos.y), ImVec2(pos.x + W, pos.y + h));
    ImDrawList* dl = window->DrawList;
    bool changed = false, iconHovered = false;

    ImGui::BeginGroup();
    if (e > 0.01f)
    {
        dl->AddRectFilled(fr.Min, fr.Max, C(p.cardInner, e), S(radius::chip));
        dl->AddRect(fr.Min, fr.Max, C(Mix(p.borderHi, Mix(p.borderHi, p.accent, 0.7f), act), e), S(radius::chip));
    }

    if (!open)
    {
        ImGui::SetCursorScreenPos(fr.Min);
        if (ImGui::InvisibleButton(id, fr.GetSize()))
        {
            g_mem.SetBool(kOpen, true);
            g_mem.SetBool(kFocus, true);
        }
        iconHovered = ImGui::IsItemHovered();
    }
    else if (e > 0.5f)
    {
        const float x = fr.Min.x + h - S(4);
        ImGui::SetCursorScreenPos(ImVec2(x, fr.Min.y));
        PushFont(Font::Medium, fontsize::body);
        PushFieldStyle(h, 0, 0);
        ImGui::SetNextItemWidth(ImMax(S(10), fr.Max.x - x - S(8)));
        if (g_mem.GetBool(kFocus, false))
        {
            ImGui::SetKeyboardFocusHere();
            g_mem.SetBool(kFocus, false);
        }
        ImGui::PushID(id);
        changed = ImGui::InputTextWithHint("##q", "Search...", buf, bufSize);
        ImGui::PopID();
        g_mem.SetBool(kActive, ImGui::IsItemActive());
        if (collapsible && ImGui::IsItemDeactivated() && buf[0] == 0)
            g_mem.SetBool(kOpen, false);
        PopFieldStyle();
        PopFont();
    }

    const float ih = anim::To(anim::Key(sid, "ih"), iconHovered ? 1.0f : 0.0f);
    const ImVec2 ic(ImLerp(fr.Max.x - h * 0.5f, fr.Min.x + h * 0.5f, e), fr.GetCenter().y);
    DrawIcon(dl, Icon::Search, ic, S(17), C(Mix(Mix(p.textSoft, p.text, ih), p.dim, e)));

    ImGui::SetCursorScreenPos(pos);
    ImGui::Dummy(ImVec2(W, h));
    ImGui::EndGroup();
    return changed;
}

// ---------------------------------------------------------------------------
// Color swatch
// ---------------------------------------------------------------------------
bool ColorSwatch(const char* label, ImVec4* color)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    const Palette& p = Pal();
    const ImGuiID id = window->GetID(label);
    const char* end = ImGui::FindRenderedTextEnd(label);
    const ImVec2 pos = window->DC.CursorPos;
    const ImRect bb(pos, pos + ImVec2(ImGui::GetContentRegionAvail().x, S(kRowH) + S(2)));
    ImGui::ItemSize(bb.GetSize());
    if (!ImGui::ItemAdd(bb, id))
        return false;

    bool hovered, held;
    const bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);
    const float hov = anim::To(anim::Key(id, "hov"), hovered ? 1.0f : 0.0f);

    ImDrawList* dl = window->DrawList;
    const ImU32 swatch = ImGui::ColorConvertFloat4ToU32(ImVec4(color->x, color->y, color->z, 1.0f));
    const float sz = S(18);
    const ImRect sb(ImVec2(bb.Max.x - sz - S(1), IM_ROUND(bb.GetCenter().y - sz * 0.5f)), ImVec2(bb.Max.x - S(1), IM_ROUND(bb.GetCenter().y + sz * 0.5f)));
    const float rr = S(radius::tiny) + S(1);
    DrawGlow(dl, sb.Min, sb.Max, swatch, rr, S(6), 0.30f + 0.20f * hov);
    dl->AddRectFilled(sb.Min, sb.Max, C(swatch), rr);
    dl->AddRect(sb.Min, sb.Max, C(Mix(swatch, Hex(0xFFFFFF), 0.35f)), rr);

    PushFont(Font::Medium, fontsize::body);
    const ImVec2 ts = ImGui::CalcTextSize(label, end);
    dl->AddText(ImVec2(bb.Min.x + S(1), IM_ROUND(bb.GetCenter().y - ts.y * 0.5f)), C(Mix(Mix(p.textSoft, p.text, 0.8f), p.text, hov)), label, end);
    PopFont();

    const ImGuiID popupId = ImHashStr("##pz.color", 0, id);
    if (pressed)
        ImGui::OpenPopupEx(popupId, ImGuiPopupFlags_None);

    bool changed = false;
    ImGui::SetNextWindowPos(ImVec2(sb.Max.x, sb.Max.y + S(6)), ImGuiCond_Appearing, ImVec2(1.0f, 0.0f));
    ImGui::PushStyleColor(ImGuiCol_PopupBg, V(p.card));
    ImGui::PushStyleColor(ImGuiCol_Border, V(Mix(p.border, p.text, 0.05f)));
    ImGui::PushStyleVar(ImGuiStyleVar_PopupRounding, S(radius::card));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(S(10), S(10)));
    const bool open = ImGui::BeginPopupEx(popupId, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoSavedSettings);
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor(2);
    if (open)
    {
        ImGui::SetNextItemWidth(S(190));
        changed = ImGui::ColorPicker4("##picker", &color->x,
                                      ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_NoAlpha | ImGuiColorEditFlags_PickerHueBar |
                                      ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_DisplayHex);
        ImGui::EndPopup();
    }
    return changed;
}

// ---------------------------------------------------------------------------
// Misc
// ---------------------------------------------------------------------------
bool RowIconButton(const char* id, Icon icon)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    const Palette& p = Pal();
    ImGuiContext& g = *GImGui;
    const ImRect last = g.LastItemData.Rect;
    const ImGuiID bid = window->GetID(id);
    const float sz = S(18);
    const ImVec2 c(window->WorkRect.Max.x - sz * 0.5f, last.GetCenter().y);
    const ImRect bb(c - ImVec2(sz, sz) * 0.5f, c + ImVec2(sz, sz) * 0.5f);
    if (!ImGui::ItemAdd(bb, bid))
        return false;

    bool hovered, held;
    const bool pressed = ImGui::ButtonBehavior(bb, bid, &hovered, &held);
    const float hov = anim::To(anim::Key(bid, "hov"), hovered ? 1.0f : 0.0f);
    DrawIcon(window->DrawList, icon, c, S(14), C(Mix(Mix(p.textSoft, p.dim, 0.5f), p.accentG, hov)));
    return pressed;
}

void GroupLabel(const char* text)
{
    PushFont(Font::Bold, fontsize::small);
    ImGui::PushStyleColor(ImGuiCol_Text, V(Pal().groupLbl));
    ImGui::TextUnformatted(text);
    ImGui::PopStyleColor();
    PopFont();
}

} // namespace pz
