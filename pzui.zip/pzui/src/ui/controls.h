#pragma once
// pz:: widgets. Same conventions as ImGui: labels are IDs, "##" hides the rest
// of the label, functions return true when the value changed / was clicked.
// Widgets take the full available width of the current window/card.
#include "imgui.h"
#include "ui/icons.h"

namespace pz {

// Filled accent box + animated checkmark when on, hollow outline when off.
bool Checkbox(const char* label, bool* v);

// Label on the left, value readout on the right, accent track + glowing thumb below.
// `fmt` formats the readout, e.g. "%.1f", "%d px", "%.0f deg".
bool SliderFloat(const char* label, float* v, float vMin, float vMax, const char* fmt = "%.1f");
bool SliderInt(const char* label, int* v, int vMin, int vMax, const char* fmt = "%d");

// Dark field + divider + chevron. A visible label is drawn above the field;
// use "##id" for the label-less look of the mockup.
bool Combo(const char* label, int* current, const char* const items[], int count);
// Multi-select variant: preview joins the selected names with ", ".
bool MultiCombo(const char* label, bool* selected, const char* const items[], int count, const char* emptyText = "None");

// Pill button. size.x <= 0 -> full width, size.y <= 0 -> default height.
bool Button(const char* label, ImVec2 size = ImVec2(0, 0));

// Search field with a magnifier icon. `width` <= 0 -> full width.
// collapsible: shows just the icon until clicked (or while empty and unfocused);
// the field then expands leftward to `width`.
bool Search(const char* id, char* buf, size_t bufSize, float width = 0.0f, bool collapsible = false);

// Styled single-line text field with placeholder. Visible label goes above.
bool InputText(const char* label, char* buf, size_t bufSize, const char* hint = nullptr);

// Label on the left, glowing color chip on the right; click opens a picker.
bool ColorSwatch(const char* label, ImVec4* color);

// Small icon button placed at the right edge of the previous item's row
// (e.g. a gear next to a checkbox). Does not affect layout.
bool RowIconButton(const char* id, Icon icon);

// Small dim section label.
void GroupLabel(const char* text);

// Soft glow around a rounded rect (stacked translucent fills).
void DrawGlow(ImDrawList* dl, ImVec2 min, ImVec2 max, ImU32 col, float rounding, float radius, float intensity);

} // namespace pz
