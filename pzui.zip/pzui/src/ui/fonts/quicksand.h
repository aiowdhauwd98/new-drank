#pragma once
// Embedded Quicksand faces (SIL OFL 1.1, see OFL.txt) so pzui looks the same on
// every machine without installing fonts.
#include <string>

namespace pz::fonts {

enum class Quicksand { Medium, Bold };

// Base85 data for ImFontAtlas::AddFontFromMemoryCompressedBase85TTF().
std::string QuicksandBase85(Quicksand weight);

} // namespace pz::fonts
