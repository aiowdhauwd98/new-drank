#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS // ImVec2 operators; must precede imgui.h
#endif
#include "ui/subtabs.h"
#include "ui/anim.h"
#include "ui/controls.h"
#include "ui/theme.h"
#include "imgui_internal.h"

namespace pz {

constexpr float kStripPadX = 9.0f;
constexpr float kChipH     = 32.0f;
constexpr float kChipPadX  = 14.0f;
constexpr float kChipGap   = 10.0f;
constexpr float kIconSz    = 16.0f;
constexpr float kIconGap   = 9.0f;

enum { kChBack = 0, kChHighlight = 1, kChFront = 2 };

struct SubtabState
{
    ImGuiID            id = 0;
    ImDrawList*        dl = nullptr;
    ImDrawListSplitter split;
    ImRect             selected;
    bool               hasSelected = false;
    bool               first = true;
};
static SubtabState g_st;

void BeginSubtabs(const char* id, ImVec2 size)
{
    const Palette& p = Pal();
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImGui::ColorConvertU32ToFloat4(p.sidebar));
    ImGui::PushStyleColor(ImGuiCol_Border, ImGui::ColorConvertU32ToFloat4(p.border));
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, S(radius::panel));
    ImGui::PushStyleVar(ImGuiStyleVar_ChildBorderSize, 1.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(S(kStripPadX), ImMax(0.0f, IM_ROUND((size.y - S(kChipH)) * 0.5f))));
    ImGui::BeginChild(id, size, ImGuiChildFlags_Borders | ImGuiChildFlags_AlwaysUseWindowPadding,
                      ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    ImGui::PopStyleVar(3);
    ImGui::PopStyleColor(2);

    g_st.id = ImGui::GetID("##pz.subtabs");
    g_st.dl = ImGui::GetWindowDrawList();
    g_st.hasSelected = false;
    g_st.first = true;
    g_st.split.Split(g_st.dl, 3);
    g_st.split.SetCurrentChannel(g_st.dl, kChFront);
}

void EndSubtabs()
{
    ImDrawList* dl = g_st.dl;
    g_st.split.SetCurrentChannel(dl, kChHighlight);
    if (g_st.hasSelected)
    {
        const Palette& p = Pal();
        const float x0 = anim::To(anim::Key(g_st.id, "x0"), g_st.selected.Min.x, 16.0f);
        const float x1 = anim::To(anim::Key(g_st.id, "x1"), g_st.selected.Max.x, 16.0f);
        const ImRect r(ImVec2(x0, g_st.selected.Min.y), ImVec2(x1, g_st.selected.Max.y));
        const float rr = S(radius::chip);

        ImGuiWindow* w = ImGui::GetCurrentWindow();
        dl->PushClipRect(w->Rect().Min, w->Rect().Max, false);
        DrawGlow(dl, r.Min, r.Max, p.accent, rr, S(7), 0.16f);
        const ImU32 tint = Mix(p.accent, p.text, 0.22f);
        const int v0 = dl->VtxBuffer.Size;
        dl->AddRectFilled(r.Min, r.Max, C(IM_COL32_WHITE), rr);
        ImGui::ShadeVertsLinearColorGradientKeepAlpha(dl, v0, dl->VtxBuffer.Size, r.Min, ImVec2(r.Min.x, r.Max.y),
                                                      C(Mix(p.sidebar, tint, 0.38f)), C(Mix(p.sidebar, tint, 0.28f)));
        dl->AddRect(r.Min, r.Max, C(Mix(p.sidebar, Mix(p.accentG, p.text, 0.30f), 0.48f)), rr);
        dl->AddLine(ImVec2(r.Min.x + rr, r.Min.y + 1.0f), ImVec2(r.Max.x - rr, r.Min.y + 1.0f), C(WithAlpha(p.text, 0.10f)));
        dl->PopClipRect();
    }
    g_st.split.Merge(dl);
    ImGui::EndChild();
}

bool Subtab(const char* label, Icon icon, bool selected)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;
    if (!g_st.first)
        ImGui::SameLine(0.0f, S(kChipGap));
    g_st.first = false;

    const Palette& p = Pal();
    const ImGuiID id = window->GetID(label);
    const char* end = ImGui::FindRenderedTextEnd(label);

    PushFont(Font::Bold, fontsize::body); // measure with the widest weight so chips don't jump
    const ImVec2 ts = ImGui::CalcTextSize(label, end);
    PopFont();
    const float iconW = icon != Icon::None ? S(kIconSz) + S(kIconGap) : 0.0f;
    const ImVec2 pos = window->DC.CursorPos;
    const ImRect bb(pos, pos + ImVec2(IM_ROUND(S(kChipPadX) * 2 + iconW + ts.x), S(kChipH)));
    ImGui::ItemSize(bb.GetSize());
    if (!ImGui::ItemAdd(bb, id))
        return false;

    bool hovered, held;
    const bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);
    const float hov = anim::To(anim::Key(id, "hov"), hovered && !selected ? 1.0f : 0.0f);
    const float act = anim::To(anim::Key(id, "act"), selected ? 1.0f : 0.0f);
    if (selected) { g_st.selected = bb; g_st.hasSelected = true; }

    ImDrawList* dl = window->DrawList;
    const float rr = S(radius::chip);

    // Idle chip: outline only (hover adds a faint fill)
    g_st.split.SetCurrentChannel(dl, kChBack);
    if (hov > 0.0f)
        dl->AddRectFilled(bb.Min, bb.Max, C(Mix(p.raised, p.accent, 0.06f), hov), rr);
    dl->AddRect(bb.Min, bb.Max, C(Mix(Mix(p.sidebar, p.border, 0.9f), Mix(p.border, p.accent, 0.35f), hov)), rr);
    g_st.split.SetCurrentChannel(dl, kChFront);

    const ImU32 fg = C(Mix(Mix(p.textSoft, p.text, hov * 0.6f), p.text, act));
    float x = bb.Min.x + S(kChipPadX);
    if (icon != Icon::None)
    {
        DrawIcon(dl, icon, ImVec2(x + S(kIconSz) * 0.5f, bb.GetCenter().y), S(kIconSz), fg);
        x += iconW;
    }
    PushFont(act > 0.5f ? Font::Bold : Font::Medium, fontsize::body);
    const ImVec2 ts2 = ImGui::CalcTextSize(label, end);
    dl->AddText(ImVec2(x + IM_ROUND((ts.x - ts2.x) * 0.5f), IM_ROUND(bb.GetCenter().y - ts2.y * 0.5f)), fg, label, end);
    PopFont();

    return pressed;
}

} // namespace pz
